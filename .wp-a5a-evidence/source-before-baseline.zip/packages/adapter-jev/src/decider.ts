import {
  ClassifierNoulResponseSchema,
  ClassifierScoreResponseSchema,
  type JsonValue,
} from '@graphgoblin/contracts';
import { validatePrimitiveAnswer } from '@graphgoblin/domain';
import {
  describeError,
  type ChoiceRequest,
  type ChoiceResult,
  type ClassifierNoulResult,
  type ClassifierPort,
  type Logger,
  type SecretsPort,
  type NoulRequest,
  type ScoreRequest,
  type ScoreResult,
} from '@graphgoblin/engine';
import {
  APIConnectionError,
  APIError,
  APIUserAbortError,
  TypeSafeClient,
  choice,
  noul,
  score,
  type EntryType,
  type Fetch,
  type RetryPolicy,
} from '@typesafe-ai/sdk';
import { z } from 'zod';

/**
 * `ClassifierPort` (`id: 'jev'`) over TypeSafe's hosted Jev model through `@typesafe-ai/sdk`
 * (MIT, no dependencies). All primitives go through `POST /v1/systemone`:
 *
 * - `choose` asks one `choice` question whose criteria are the route labels and descriptions, and
 *   returns the chosen label, its confidence, and every other label with its probability.
 * - `classifyNoul` returns raw true probability for explicitly authored sides.
 * - `score` returns a fractional rubric index and actual provider evidence.
 *
 * See docs/research/jev.md for the verified request and response shapes.
 */

export const DEFAULT_BASE_URL = 'https://api.typesafe.ai';
export const DEFAULT_MODEL = 'jev-latest';

const sdkLogRouting = {
  debug: ['debug', 'jev: SDK debug event'],
  info: ['debug', 'jev: SDK information event'],
  warn: ['warn', 'jev: SDK warning'],
  error: ['warn', 'jev: SDK error'],
} as const;

function forwardSdkLog(logger: Logger, level: keyof typeof sdkLogRouting): void {
  const [method, message] = sdkLogRouting[level];
  logger[method]({}, message);
}

export interface JevDeciderOptions {
  secrets: SecretsPort;
  /** Secret holding the API key. Default `jev-api-key`. */
  secretName?: string;
  /** Transport override for tests or proxies. Default: global `fetch`. */
  fetch?: Fetch;
  /** API root. Default `https://api.typesafe.ai`; never read from the environment. */
  baseUrl?: string;
  /** Jev model. Default `jev-latest`. */
  model?: string;
  /** Per-attempt timeout in milliseconds. Default 10 000 (the SDK default). */
  timeoutMs?: number;
  /** Retry overrides passed to the SDK. Default: the SDK's (2 retries on 408, 429, 5xx). */
  retry?: Partial<RetryPolicy>;
  logger?: Logger;
}

const ChoiceAnswerSchema = z.object({
  type: z.literal('choice'),
  choice: z.string(),
  confidence: z.number().min(0).max(1).optional(),
  probabilities: z.record(z.string(), z.number().min(0).max(1)),
});

const resultSchema = <T extends z.ZodType>(answer: T) =>
  z.object({ model: z.string().optional(), answers: z.object({ answer }) });

const ChoiceResultSchema = resultSchema(ChoiceAnswerSchema);

/** An error carrying a code the engine and logs can key off. */
export class JevError extends Error {
  constructor(
    readonly code:
      | 'DECIDER_UNAVAILABLE'
      | 'DECIDER_NOT_AUTHENTICATED'
      | 'DECIDER_RATE_LIMITED'
      | 'DECIDER_HTTP_ERROR'
      | 'DECIDER_UNREACHABLE'
      | 'DECIDER_INVALID_CONFIGURATION'
      | 'DECIDER_INVALID_RESPONSE',
    message: string,
    readonly status?: number,
  ) {
    super(message);
    this.name = 'JevError';
  }
}

/** The SDK accepts text, JSON objects or arrays, or null as state; wrap scalars. */
function toState(context: JsonValue): EntryType {
  if (context === null || typeof context === 'string' || typeof context === 'object') {
    return context;
  }
  return { value: context };
}

function mapError(error: unknown): Error {
  if (error instanceof JevError) return error;
  if (error instanceof APIUserAbortError) {
    return new DOMException('The Jev request was aborted', 'AbortError');
  }
  if (error instanceof APIError) {
    if (error.status === 401 || error.status === 403) {
      return new JevError(
        'DECIDER_NOT_AUTHENTICATED',
        `Jev rejected the API key (${error.status})`,
        error.status,
      );
    }
    if (error.status === 429) {
      return new JevError('DECIDER_RATE_LIMITED', 'Jev rate limit exceeded', error.status);
    }
    return new JevError('DECIDER_HTTP_ERROR', `Jev request failed (${error.status})`, error.status);
  }
  if (error instanceof APIConnectionError) {
    return new JevError('DECIDER_UNREACHABLE', 'Jev is unreachable');
  }
  return new JevError('DECIDER_HTTP_ERROR', 'Jev request failed');
}

export class JevDecider implements ClassifierPort {
  readonly id = 'jev' as const;
  private client: TypeSafeClient | undefined;
  private readonly ready: Promise<void>;

  /**
   * `available()` must be synchronous and cheap, but the key lives behind the async `SecretsPort`.
   * The decider therefore resolves the key once at construction (in the background) and caches a
   * client; `init()` awaits that first resolution, and `refresh()` re-reads the secret after it
   * changes. Until the first resolution finishes, `available()` is false and the engine reports
   * unavailable; the selected evaluation does not fall back to another method.
   */
  constructor(private readonly options: JevDeciderOptions) {
    this.ready = this.refresh().catch(() => undefined);
  }

  /** Wait for the key resolution started at construction. Never throws. */
  init(): Promise<void> {
    return this.ready;
  }

  /** Re-read the API key secret and rebuild the client; the decider is unavailable without one. */
  async refresh(): Promise<void> {
    let key: string | undefined;
    try {
      key = (await this.options.secrets.resolve(this.options.secretName ?? 'jev-api-key'))?.trim();
    } catch (error) {
      this.options.logger?.warn(
        { err: describeError(error) },
        'jev: could not read the API key secret',
      );
      key = undefined;
    }
    this.client = key ? this.createClient(key) : undefined;
  }

  available(): boolean {
    return this.client !== undefined;
  }

  private createClient(apiKey: string): TypeSafeClient {
    const logger = this.options.logger;
    return new TypeSafeClient({
      apiKey,
      baseURL: this.options.baseUrl ?? DEFAULT_BASE_URL,
      defaultModel: this.options.model ?? DEFAULT_MODEL,
      ...(this.options.timeoutMs !== undefined ? { timeout: this.options.timeoutMs } : {}),
      ...(this.options.retry ? { retry: this.options.retry } : {}),
      ...(this.options.fetch ? { fetch: this.options.fetch } : {}),
      // SDK messages can include response headers, bodies or transport text. Keep fixed summaries.
      logLevel: logger ? 'debug' : 'off',
      ...(logger
        ? {
            logger: {
              debug: forwardSdkLog.bind(null, logger, 'debug'),
              info: forwardSdkLog.bind(null, logger, 'info'),
              warn: forwardSdkLog.bind(null, logger, 'warn'),
              error: forwardSdkLog.bind(null, logger, 'error'),
            },
          }
        : {}),
    });
  }

  private requireClient(): TypeSafeClient {
    if (!this.client) {
      throw new JevError('DECIDER_UNAVAILABLE', 'Jev API key is unavailable');
    }
    return this.client;
  }

  async choose(request: ChoiceRequest, signal: AbortSignal): Promise<ChoiceResult> {
    const client = this.requireClient();
    const criteria = Object.fromEntries(request.options.map((o) => [o.id, o.criteria]));
    let body: unknown;
    try {
      body = await client.systemOne(
        {
          state: toState(request.context),
          questions: { answer: choice(request.question, criteria) },
        },
        { signal },
      );
    } catch (error) {
      throw mapError(error);
    }
    const parsed = ChoiceResultSchema.safeParse(body);
    if (!parsed.success) {
      throw new JevError('DECIDER_INVALID_RESPONSE', 'Unexpected Jev choice response');
    }
    const { choice: label, confidence, probabilities } = parsed.data.answers.answer;
    const labels = new Set(request.options.map((option) => option.id));
    const probabilityLabels = Object.keys(probabilities);
    if (
      !labels.has(label) ||
      probabilityLabels.length !== labels.size ||
      probabilityLabels.some((key) => !labels.has(key))
    ) {
      throw new JevError('DECIDER_INVALID_RESPONSE', 'Unexpected Jev choice response');
    }
    return {
      type: 'choice',
      optionId: label,
      confidence: confidence ?? probabilities[label]!,
      probabilities,
    };
  }

  async classifyNoul(request: NoulRequest, signal: AbortSignal): Promise<ClassifierNoulResult> {
    signal.throwIfAborted();
    const client = this.requireClient();
    let body: unknown;
    try {
      body = await client.systemOne(
        {
          state: toState(request.context),
          questions: { answer: noul(request.question, request.criteria) },
        },
        { signal, retry: { maxRetries: 0 } },
      );
    } catch (error) {
      throw mapError(error);
    }
    const parsed = ClassifierNoulResponseSchema.safeParse(body);
    if (!parsed.success)
      throw new JevError('DECIDER_INVALID_RESPONSE', 'Unexpected Jev Noul response');
    return { type: 'noul', trueProbability: parsed.data.answers.answer.noul };
  }

  async score(request: ScoreRequest, signal: AbortSignal): Promise<ScoreResult> {
    signal.throwIfAborted();
    const [first, second, ...rest] = request.anchors;
    if (first === undefined || second === undefined)
      throw new JevError(
        'DECIDER_INVALID_CONFIGURATION',
        'Score requires at least two rubric anchors',
      );
    const client = this.requireClient();
    let body: unknown;
    try {
      body = await client.systemOne(
        {
          state: toState(request.context),
          questions: { answer: score(request.question, [first, second, ...rest]) },
        },
        { signal, retry: { maxRetries: 0 } },
      );
    } catch (error) {
      throw mapError(error);
    }
    const parsed = ClassifierScoreResponseSchema.safeParse(body);
    if (!parsed.success)
      throw new JevError('DECIDER_INVALID_RESPONSE', 'Unexpected Jev Score response');
    const answer = parsed.data.answers.answer;
    const result: ScoreResult = {
      ...answer,
      confidence: answer.confidence ?? null,
      probabilities: answer.probabilities ?? null,
    };
    const invalid = validatePrimitiveAnswer({ type: 'score', anchors: request.anchors }, result);
    if (invalid !== null) throw new JevError('DECIDER_INVALID_RESPONSE', invalid);
    return result;
  }
}

export function createJevDecider(options: JevDeciderOptions): JevDecider {
  return new JevDecider(options);
}
