#Requires -Version 7.0
# Root-invoked wrapper for one admitted #438 correction QA run. Derived from the qualified
# supplemental launch.ps1 (sha256 83514dd7b19d8bc298c287bcec75d8cf157f220a81fe9590741f1274b2922177):
# same admission digest gate, raw stream receipts and no-signal 30-minute deadline. Changes: the
# admission schema and driver path, a create-new invocation directory named by the admission, and
# an explicit driver environment allowlist instead of the inherited environment.
param(
    [Parameter(Mandatory)][string]$Admission,
    [Parameter(Mandatory)][ValidatePattern('^[a-f0-9]{64}$')][string]$Sha256
)

$ErrorActionPreference = 'Stop'
if (!$IsWindows) { throw 'Windows only' }
$batch = Split-Path -Parent $PSScriptRoot
$user = Split-Path -Parent (Split-Path -Parent $batch)
$projectNode = Join-Path $user '.claude/codex-runs/GraphGoblin/runtime/node-v22.23.4-win-x64/node.exe'
if (![IO.Path]::IsPathFullyQualified($Admission)) { throw 'Admission must be absolute' }
$Admission = [IO.Path]::GetFullPath($Admission)
if (!$Admission.StartsWith($batch + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Admission must be inside the QA batch'
}
if ((Get-FileHash -LiteralPath $Admission -Algorithm SHA256).Hash.ToLowerInvariant() -cne $Sha256) { throw 'Admission digest changed' }
$admitted = Get-Content -LiteralPath $Admission -Raw | ConvertFrom-Json
if ($admitted.schema -cne 'gg438-correction-qa-admission/v2' -or $admitted.state -cne 'root-admitted') {
    throw 'Wrong execution admission'
}
foreach ($file in @('launch.ps1', 'fixtures/common.mjs', 'fixtures/driver.mjs')) {
    $actual = (Get-FileHash -LiteralPath (Join-Path $PSScriptRoot $file) -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -cne $admitted.scripts.$file) { throw ('Module digest changed: ' + $file) }
}
$systemRoot = [Environment]::GetEnvironmentVariable('SystemRoot')
if (![IO.Path]::IsPathFullyQualified($systemRoot)) { throw 'SystemRoot must be absolute' }
$output = [IO.Path]::GetFullPath([string]$admitted.invocationDir)
if ([IO.Path]::GetDirectoryName($output) -ine $batch) { throw 'Invocation directory must be a direct child of the QA batch' }
New-Item -ItemType Directory -Path $output | Out-Null
if (([IO.File]::GetAttributes($output) -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Unsafe receipt root' }
$driverTemp = Join-Path $output 'driver-temp'
New-Item -ItemType Directory -Path $driverTemp | Out-Null

function Save-Receipt($Name, $Data) {
    $file = [IO.File]::Open((Join-Path $output $Name), [IO.FileMode]::CreateNew, [IO.FileAccess]::Write)
    try {
        $bytes = [Text.UTF8Encoding]::new($false).GetBytes(($Data | ConvertTo-Json -Depth 12) + "`n")
        $file.Write($bytes)
    } finally { $file.Dispose() }
}

$info = [Diagnostics.ProcessStartInfo]::new($projectNode)
$info.WorkingDirectory = $PSScriptRoot
$info.UseShellExecute = $false
$info.CreateNoWindow = $true
$info.RedirectStandardOutput = $true
$info.RedirectStandardError = $true
# Explicit allowlist: no ambient HOME, profile, provider credential, proxy, NODE_OPTIONS or GG_* value.
$info.Environment.Clear()
$info.Environment['SystemRoot'] = $systemRoot
$info.Environment['WINDIR'] = $systemRoot
$info.Environment['PATH'] = (Split-Path -Parent $projectNode) + ';' + (Join-Path $systemRoot 'System32') + ';' + $systemRoot
$info.Environment['TEMP'] = $driverTemp
$info.Environment['TMP'] = $driverTemp
foreach ($arg in @((Join-Path $PSScriptRoot 'fixtures/driver.mjs'), $Admission, $Sha256)) { $info.ArgumentList.Add($arg) }
$stdout = [IO.File]::Open((Join-Path $output 'stdout.raw'), [IO.FileMode]::CreateNew, [IO.FileAccess]::Write)
$stderr = [IO.File]::Open((Join-Path $output 'stderr.raw'), [IO.FileMode]::CreateNew, [IO.FileAccess]::Write)
$child = $null
$code = $null
try {
    Save-Receipt 'requested.json' @{ executable = $projectNode; arguments = $info.ArgumentList; environment = $info.Environment; at = [DateTime]::UtcNow.ToString('o') }
    $child = [Diagnostics.Process]::Start($info)
    $outCopy = $child.StandardOutput.BaseStream.CopyToAsync($stdout)
    $errCopy = $child.StandardError.BaseStream.CopyToAsync($stderr)
    $created = try { $child.StartTime.ToUniversalTime().ToString('o') } catch { $null }
    Save-Receipt 'launch.json' @{ pid = $child.Id; creationUtc = $created }
    $deadline = [DateTime]::UtcNow.AddMinutes(30)
    do { $finished = $child.WaitForExit(10000) } until ($finished -or [DateTime]::UtcNow -ge $deadline)
    if (!$finished) {
        Save-Receipt 'timeout.json' @{ pid = $child.Id; creationUtc = $created; at = [DateTime]::UtcNow.ToString('o') }
        throw 'Runner disposition requires exact owned process readback'
    }
    $code = $child.ExitCode
    Save-Receipt 'exit.json' @{ pid = $child.Id; exitCode = $code; at = [DateTime]::UtcNow.ToString('o') }
    if (![Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($outCopy, $errCopy), 5000)) { throw 'Runner stream close ambiguous' }
    Save-Receipt 'capture.json' @{ stdoutBytes = $stdout.Length; stderrBytes = $stderr.Length }
} finally {
    $stdout.Dispose()
    $stderr.Dispose()
    if ($null -ne $child) { $child.Dispose() }
}
exit $code
