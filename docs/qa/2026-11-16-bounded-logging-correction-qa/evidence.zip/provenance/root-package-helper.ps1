$ErrorActionPreference = 'Stop'
$batch = 'C:\Users\98jak\graphgoblin-qa\2026-11-13-aidlc-batch'
$planPath = Join-Path $batch 'launcher-438-correction-qa-publication-preparation-01\archive-plan.json'
$utf8 = [Text.UTF8Encoding]::new($false)
function Sha([byte[]]$bytes) { [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant() }
function Physical([string]$path, [bool]$directory) {
    $full = [IO.Path]::GetFullPath($path)
    if (!$full.StartsWith($batch + '\', [StringComparison]::OrdinalIgnoreCase) -and $full -ne $batch) { throw "Outside batch: $full" }
    $current = $full
    while ($current.Length -ge $batch.Length) {
        $item = Get-Item -LiteralPath $current -Force
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Reparse point: $current" }
        $current = Split-Path -Parent $current
    }
    $item = Get-Item -LiteralPath $full -Force
    if ($item.PSIsContainer -ne $directory) { throw "Unexpected kind: $full" }
    return $full
}
function SafeMember([string]$name) {
    if ($name -cnotmatch '\A[A-Za-z0-9_.\-/]+\z' -or ($name.Split('/') | Where-Object { $_ -in @('', '.', '..') })) { throw "Unsafe ZIP member: $name" }
    return $name
}
function WriteNew([string]$path, [byte[]]$bytes) {
    $stream = [IO.File]::Open($path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write)
    try { $stream.Write($bytes,0,$bytes.Length) } finally { $stream.Dispose() }
}
function JsonNew([string]$path, $data) { WriteNew $path ($utf8.GetBytes(($data | ConvertTo-Json -Depth 18) + "`n")) }
$planBytes = [IO.File]::ReadAllBytes((Physical $planPath $false))
if ((Sha $planBytes) -ne '62794b9aa7df89e1a9982e89f42e0cad0b3767d0d592ccbe5b6d17fc26bf8c25') { throw 'Plan drift' }
$plan = $utf8.GetString($planBytes) | ConvertFrom-Json
if ($plan.state -ne 'ready-for-root-review-no-archive-created' -or $plan.pendingInputs.Count -ne 0) { throw 'Plan not ready' }
$rows = [Collections.Generic.List[object]]::new()
$names = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
function AddFile([string]$source, [string]$member, [string]$expectedHash = '', $expectedBytes = $null) {
    $source = Physical $source $false
    $member = SafeMember $member
    if (!$names.Add($member)) { throw "Duplicate member: $member" }
    $item = Get-Item -LiteralPath $source
    if ($item.Length -gt 16777216) { throw "Unexpected oversized evidence: $source" }
    $bytes = [IO.File]::ReadAllBytes($source)
    $hash = Sha $bytes
    if ($expectedHash -and $hash -ne $expectedHash) { throw "Source hash mismatch: $source" }
    if ($null -ne $expectedBytes -and $bytes.Length -ne $expectedBytes) { throw "Source length mismatch: $source" }
    $rows.Add([pscustomobject]@{ source=$source; member=$member; bytes=$bytes.Length; sha256=$hash })
}
foreach ($row in $plan.fixedCopies) { AddFile (Join-Path $batch $row.source) $row.zipPath $row.sha256 $row.bytes }
foreach ($reference in $plan.sourceReferences) {
    $bytes=[IO.File]::ReadAllBytes((Physical (Join-Path $batch $reference.source) $false))
    if ((Sha $bytes) -ne $reference.sha256 -or ($null -ne $reference.bytes -and $bytes.Length -ne $reference.bytes)) { throw 'External reference drift' }
}
foreach ($set in $plan.caseSets) {
    if ($set.label -notin @('baseline','candidate')) { throw 'Unexpected case set' }
    $summary = Get-Content -Raw -LiteralPath (Physical (Join-Path $batch $set.summary) $false) | ConvertFrom-Json
    if ($summary.status -ne 'complete' -or $summary.results.Count -ne $set.expectedCaseCount -or $summary.remaining.Count -ne 0) { throw 'Incomplete summary' }
    $caseCount = 0; $caseBytes = 0
    foreach ($case in $set.caseEvidence) {
        if ($case.caseId -cnotmatch '\A[a-z0-9-]+\z') { throw 'Invalid case ID' }
        $expected = Join-Path $batch ('launcher-438-native-preparation-v3\' + $set.label + '-correction-revision04-fixture-01\cases\' + $case.caseId + '\evidence')
        if ($case.sourcePath -cne $expected) { throw 'Case source differs from exact selected evidence directory' }
        $matched = @($summary.results | Where-Object { $_.id -ceq $case.caseId -and $_.evidence -ceq $expected -and $_.cleanupComplete -eq $true })
        if ($matched.Count -ne 1) { throw 'Case summary mismatch' }
        foreach ($file in Get-ChildItem -LiteralPath (Physical $expected $true) -Force) {
            if ($file.PSIsContainer) { throw 'Unexpected nested case evidence directory' }
            AddFile $file.FullName ('runs/' + $set.label + '/cases/' + $case.caseId + '/' + $file.Name)
            $caseCount++; $caseBytes += $file.Length
        }
    }
    if ($caseCount -ne $set.expectedEvidenceFiles -or $caseBytes -ne $set.expectedEvidenceBytes) { throw 'Case file inventory changed' }
    $driver = Join-Path $batch ('launcher-438-correction-qa-rev04-' + $set.label + '-output-01\driver-evidence')
    $driverFiles = @(Get-ChildItem -LiteralPath (Physical $driver $true) -Force)
    if ($driverFiles.Count -ne 10) { throw 'Unexpected driver evidence count' }
    foreach ($file in $driverFiles) { AddFile $file.FullName ('runs/' + $set.label + '/driver-evidence/' + $file.Name) }
}
AddFile $planPath 'provenance/archive-plan.json'
AddFile $PSCommandPath 'provenance/root-package-helper.ps1'
$packet = Join-Path $batch 'proposed\docs\qa\2026-11-16-bounded-logging-correction-qa'
$null = Physical (Split-Path -Parent $packet) $true
if (Test-Path -LiteralPath $packet) { throw 'Output packet already exists' }
New-Item -ItemType Directory -Path $packet | Out-Null
$zipPath=Join-Path $packet 'evidence.zip'
$zipFile=[IO.File]::Open($zipPath,[IO.FileMode]::CreateNew,[IO.FileAccess]::ReadWrite)
$zip=[IO.Compression.ZipArchive]::new($zipFile,[IO.Compression.ZipArchiveMode]::Create,$false)
try {
    foreach ($row in $rows) {
        $bytes=[IO.File]::ReadAllBytes((Physical $row.source $false))
        if ($bytes.Length -ne $row.bytes -or (Sha $bytes) -ne $row.sha256) { throw 'Source changed during archive creation' }
        $entry=$zip.CreateEntry($row.member,[IO.Compression.CompressionLevel]::Optimal)
        $stream=$entry.Open()
        try { $stream.Write($bytes,0,$bytes.Length) } finally { $stream.Dispose() }
    }
} finally { $zip.Dispose(); $zipFile.Dispose() }
$zip=[IO.Compression.ZipFile]::OpenRead($zipPath)
try {
    if ($zip.Entries.Count -ne $rows.Count) { throw 'ZIP entry count mismatch' }
    foreach ($row in $rows) {
        $entry=$zip.GetEntry($row.member)
        if (!$entry -or $entry.Length -ne $row.bytes) { throw 'ZIP member size mismatch' }
        $stream=$entry.Open(); $memory=[IO.MemoryStream]::new()
        try { $stream.CopyTo($memory); if ((Sha $memory.ToArray()) -ne $row.sha256) { throw 'ZIP member hash mismatch' } } finally { $memory.Dispose(); $stream.Dispose() }
    }
} finally { $zip.Dispose() }
JsonNew (Join-Path $packet 'source-member-map.json') @{ schema='gg438-correction-qa-lossless-archive/v1'; members=$rows; referencesRetainedExternally=$plan.sourceReferences; excludes=@('All fixture siblings, stores, master keys, SQLite bytes, profiles and junction targets','Provider events.jsonl, result.json, latest.md and private session streams') }
foreach ($pair in @(@('launcher-438-correction-opus-execution-01\full-report.md','full-report.md.txt'),@('launcher-438-correction-root-qa-acceptance-01.md','root-qa-acceptance.md.txt'),@('launcher-438-correction-opus-execution-01\evidence-inventory.json','evidence-inventory.json'),@('launcher-438-correction-opus-execution-01\provider-final-message.md','provider-final-message.md.txt'))) {
    $source=Physical (Join-Path $batch $pair[0]) $false
    $row=@($rows | Where-Object { $_.source -eq $source })
    if ($row.Count -ne 1) { throw 'Readable copy missing from archive mapping' }
    $bytes=[IO.File]::ReadAllBytes($source)
    if ((Sha $bytes) -ne $row[0].sha256) { throw 'Readable copy drift' }
    WriteNew (Join-Path $packet $pair[1]) $bytes
}
$summary=@{ memberCount=$rows.Count; uncompressedBytes=($rows | Measure-Object bytes -Sum).Sum; zipBytes=(Get-Item -LiteralPath $zipPath).Length; zipSha256=(Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash.ToLowerInvariant(); exactMemberReadback=$true; baselineCaseFiles=359; candidateCaseFiles=431; driverEvidenceFiles=20; createdAt=[DateTime]::UtcNow.ToString('o') }
JsonNew (Join-Path $packet 'archive-verification.json') $summary
$summary | ConvertTo-Json -Compress
