// #438 RC1 controlled receipt: loaded only through `node --import` in the controlled direct child.
// It records, read-only, each Node HTTP 'clientError' event the gateway's server actually emits
// (the parser event that reaches Fastify's clientErrorHandler) and then delegates unchanged.
// The receipt keeps digests and canary booleans, never the raw packet. Node built-ins only.
import { createHash } from 'node:crypto';
import { appendFileSync } from 'node:fs';
import http from 'node:http';

const receiptPath = process.env.QA438_RECEIPT_PATH;
let canaries = {};
try { canaries = JSON.parse(process.env.QA438_CANARIES_JSON ?? '{}'); } catch { canaries = {}; }
// Never inherited by providers, Script work or any other child.
delete process.env.QA438_RECEIPT_PATH;
delete process.env.QA438_CANARIES_JSON;

let sequence = 0;
const original = http.Server.prototype.emit;
http.Server.prototype.emit = function emit(name, ...args) {
  if (name === 'clientError' && receiptPath) {
    try {
      const [error, socket] = args;
      const raw = error?.rawPacket;
      const descriptor = error ? Object.getOwnPropertyDescriptor(error, 'rawPacket') : undefined;
      const bytes = raw instanceof Uint8Array ? Buffer.from(raw.buffer, raw.byteOffset, raw.byteLength) : undefined;
      const found = {};
      for (const [key, value] of Object.entries(canaries)) found[key] = bytes ? bytes.includes(Buffer.from(String(value))) : false;
      appendFileSync(receiptPath, JSON.stringify({
        seq: ++sequence, at: Date.now(), pid: process.pid, event: 'clientError', listeners: this.listenerCount('clientError'),
        name: error?.name, code: error?.code, enumerableKeys: error ? Object.keys(error) : [],
        rawPacket: bytes ? { enumerable: descriptor?.enumerable === true, length: bytes.length,
          sha256: createHash('sha256').update(bytes).digest('hex'), canaries: found } : null,
        socketWritable: socket?.writable === true, socketDestroyed: socket?.destroyed === true,
      }) + '\n');
    } catch {
      // A receipt never changes the server's behavior.
    }
  }
  return original.call(this, name, ...args);
};
