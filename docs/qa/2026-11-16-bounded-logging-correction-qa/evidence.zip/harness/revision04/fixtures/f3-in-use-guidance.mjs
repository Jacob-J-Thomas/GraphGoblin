// #438 F3 (RC3): destination-in-use guidance, both branches, exact admitted text.
// Native tier. The admitted launcher (--ensure-gateway, quiet, no dialog) refuses a private root
// whose pipe reservation (child exit 70) or legacy gateway.log handle (parent sharing deadline, no
// child exit) is held by a finite same-user holder from the reused qualified supplemental hold. The
// oracle is exact text equality, never a phrase ban: the baseline admission carries the frozen
// unqualified text and the candidate admission carries the root-reviewed destination-in-use text
// (which may say "another GraphGoblin gateway" conditionally). stderr and the structured record
// must both equal it. The holder stays untouched; a positive start follows only after the holder's
// exit, close, both EOFs and raw-birth absence are proven.
// The candidate-only legacy-writer control starts the admitted, retained e21c predecessor build
// (exact binding, new root/store/ports/tokens) as the live legacy writer, as the qualified
// supplemental predecessor case did; no original admission, invocation or token is reused.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readdir, readFile, realpath, stat, writeFile } from 'node:fs/promises';
import net from 'node:net';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import {
  bootLauncher, drainOwned, health, holdExact, launch, launcherRecords, lockNamesPresent, prove, sha256,
} from './common.mjs';

export function guidance(stderr) {
  const [message, ...rest] = stderr.split(/\r?\n\r?\n/u);
  const lines = rest.join('\n\n');
  const folder = /Log folder: (.*)/u.exec(lines)?.[1]?.trim() ?? null;
  const configuration = /Configuration: (.*)/u.exec(lines)?.[1]?.trim() ?? null;
  return {
    message: message?.trim() ?? '',
    statesNoProcessStopped: /no process was stopped/iu.test(message ?? ''),
    statesNoLogChanged: /no log file was changed/iu.test(message ?? ''),
    controlCharacters: /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f-\u009f]/u.test(stderr),
    logFolder: folder, configuration,
    renderedLengthsWithinCap: [folder, configuration].every((value) => value === null || value.length <= 260),
  };
}

/** The documented root key, computed independently and checked against the admitted built module. */
async function pipeNameFor(session, root) {
  const canonical = await realpath(root);
  const info = await stat(canonical, { bigint: true });
  const digest = createHash('sha256').update(`graphgoblin-gateway-log-root/v1\0dev=${info.dev}\0ino=${info.ino}`).digest('hex');
  const independent = '\\\\.\\pipe\\GraphGoblin.GatewayLog.' + digest.slice(0, 40);
  const rel = 'apps/api/dist/windows-log/managed-root.js';
  const file = join(session.checkout, ...rel.split('/'));
  assert.equal(sha256(await readFile(file)), session.build.files[rel], 'managed-root.js digest');
  const built = await import(pathToFileURL(file).href);
  const resolved = await built.resolveLogRoot(root);
  assert.equal(resolved.pipeName, independent, 'built pipe key differs from the documented formula');
  return { pipeName: independent, dev: String(info.dev), ino: String(info.ino), canonical };
}

function probePipe(pipeName) {
  return new Promise((done) => {
    const server = net.createServer();
    server.once('error', (error) => done({ bindable: false, code: error.code }));
    // A successful probe bind means the holder lost the reservation: release it immediately.
    server.listen(pipeName, () => server.close(() => done({ bindable: true })));
  });
}

/** Contender store: no lease or reclaim name; entries recorded (the parent route never starts a child). */
async function lockAndEntries(store) {
  return { entries: (await readdir(store)).sort(), locks: await lockNamesPresent(store) };
}

const lastRecord = async (root) => (await launcherRecords(root)).filter((row) => row.value).at(-1)?.value ?? null;

function textPredicates(session, refusal, record, expectedChildExit) {
  const expected = session.admission.rc3.expectedInUseText;
  const shown = guidance(refusal.stderr);
  return {
    shown,
    predicates: {
      'rc3-refusal-reached': {
        status: refusal.exit.code === 1 && record?.code === 'destination-in-use' && record?.childExit === expectedChildExit &&
          shown.message === record?.message ? 'pass' : 'fail',
        detail: { exit: refusal.exit.code, code: record?.code ?? null, childExit: record?.childExit ?? null,
          expectedChildExit: expectedChildExit ?? null, stderrMatchesRecord: shown.message === record?.message },
      },
      'rc3-text-exact': {
        status: shown.message === expected && record?.message === expected ? 'pass' : 'fail',
        detail: { textSource: session.admission.rc3.textSource, expected, stderrMessage: shown.message, recordMessage: record?.message ?? null },
      },
      'rc3-presentation-bounds': {
        status: !shown.controlCharacters && shown.renderedLengthsWithinCap && shown.logFolder !== null ? 'pass' : 'fail',
        detail: { logFolder: shown.logFolder, configuration: shown.configuration, stdoutBytes: refusal.stdoutBytes, stderrBytes: refusal.stderrBytes },
      },
      'rc3-facts-retained': { status: 'informational',
        detail: { statesNoProcessStopped: shown.statesNoProcessStopped, statesNoLogChanged: shown.statesNoLogChanged } },
    },
  };
}

async function route(ctx, kind) {
  const { session } = ctx.qa;
  const { sup } = session.lib;
  const { refused } = session.lib.native;
  const root = await ctx.privateDir('log-root');
  const evidence = { kind };
  const store = await ctx.store('contender');
  const port = await ctx.port();
  // The legacy-sharing probe waits until the startup deadline, so the refusal uses a short one.
  const config = ctx.config({ dataDir: store, port, startup: kind === 'file' ? 3 : 20 });
  const configPath = await ctx.writeConfig(root, 'qa438-' + kind, config);
  const positiveConfig = ctx.config({ dataDir: await ctx.store('positive'), port: await ctx.port(), startup: 30 });
  const positivePath = await ctx.writeConfig(root, 'qa438-' + kind + '-positive', positiveConfig);
  evidence.key = await pipeNameFor(session, root);
  const active = join(root, 'gateway.log');
  const previous = join(root, 'gateway.log.1');
  if (kind === 'file') {
    await writeFile(active, '{"level":30,"msg":"qa438 rc3 seed one"}\n{"level":30,"msg":"qa438 rc3 seed two"}\n', { flag: 'wx' });
  }
  evidence.before = { active: await sup.fileState(active), previous: await sup.fileState(previous) };
  // Reused qualified holders: a plain Node pipe server, or a PowerShell handle with write access
  // and read/write/delete sharing (the launcher's read-without-write-sharing probe then sees error 32).
  const spec = kind === 'pipe'
    ? { kind: 'pipe', name: 'rc3-pipe', pipe: evidence.key.pipeName, seconds: 120 }
    : { kind: 'file', name: 'rc3-file', paths: [active], access: 'ReadWrite', share: 'ReadWrite, Delete', seconds: 120 };
  const held = await holdExact(ctx, spec, async (holder) => {
    const refusal = await launch(ctx, 'refusal', session.launcher, configPath, { expect: 1 });
    const record = await lastRecord(root);
    const after = await ctx.native.cim(holder.pid);
    return {
      refusal: { exit: refusal.exit, close: refusal.close, stdoutBytes: refusal.stdoutBytes, stderrBytes: refusal.stderrBytes, stderr: refusal.stderr },
      record,
      holderBirthUnchanged: after.creationFileTime === holder.identity.creationFileTime,
      pipeProbe: kind === 'pipe' ? await probePipe(evidence.key.pipeName) : null,
      slots: { active: await sup.fileState(active), previous: await sup.fileState(previous) },
      contender: { ...(await lockAndEntries(store)), portRefused: await refused(port) },
    };
  });
  Object.assign(evidence, held.result, { holder: held.holder });
  // Positive control only after the exact holder's exit, close, EOFs and raw-birth absence.
  const positive = await bootLauncher(ctx, 'positive', session.launcher, positivePath, positiveConfig, { cwd: session.checkout });
  evidence.positiveDrain = await drainOwned(ctx, positive);
  await ctx.put('evidence.json', evidence);
  const unchanged = kind === 'pipe'
    ? !evidence.slots.active.exists && !evidence.slots.previous.exists
    : evidence.slots.active.id === evidence.before.active.id && evidence.slots.active.sha256 === evidence.before.active.sha256 &&
      !evidence.slots.previous.exists;
  const text = textPredicates(session, held.result.refusal, evidence.record, kind === 'pipe' ? 70 : undefined);
  return {
    tier: 'native',
    route: kind === 'pipe' ? 'child reservation refusal (70)' : 'parent legacy-sharing refusal (no child exit)',
    predicates: {
      ...text.predicates,
      'rc3-holder-untouched': {
        // No contender lease or listener on both routes; the parent route (no child) also leaves the store empty.
        status: evidence.holderBirthUnchanged && unchanged && evidence.contender.locks.length === 0 && evidence.contender.portRefused &&
          (kind === 'pipe' ? evidence.pipeProbe?.code === 'EADDRINUSE' : evidence.contender.entries.length === 0) ? 'pass' : 'fail',
        detail: { holderBirthUnchanged: evidence.holderBirthUnchanged, managedNamesUnchanged: unchanged, pipeProbe: evidence.pipeProbe,
          contenderStoreEntries: evidence.contender.entries, contenderLocks: evidence.contender.locks, contenderPortRefused: evidence.contender.portRefused },
      },
      'rc3-holder-released-before-positive': { status: 'pass', detail: evidence.holder },
      'positive-after-release': { status: evidence.positiveDrain?.leasesAbsent ? 'pass' : 'fail',
        detail: { pid: evidence.positiveDrain?.pid, birth: evidence.positiveDrain?.birth } },
    },
  };
}

export const runPipe = (ctx) => route(ctx, 'pipe');
export const runFile = (ctx) => route(ctx, 'file');

// ------------------------------------------------------------------ n-f3-legacy-writer (candidate only)

/** Immutable predecessor proof (the qualified supplemental verifyPredecessor steps). */
async function verifyPredecessor(session, baseline) {
  const { sup, artifacts } = session.lib;
  for (const ref of [baseline.launcher, baseline.launcherBuildReceipt, baseline.launcherBuildExit, baseline.buildReceipt,
    baseline.buildLog, baseline.buildExit, baseline.node, baseline.git]) await sup.readBound(ref);
  const opening = sup.gitReadback(baseline);
  assert.deepEqual([opening.status, opening.head, opening.tree], ['', baseline.head, baseline.tree], 'predecessor checkout');
  assert.equal(sha256(await readFile(opening.index)), baseline.indexSha256, 'predecessor index changed');
  const files = opening.git('ls-files', '-z').split('\0').filter(Boolean);
  assert.equal(files.length, Object.keys(baseline.sourceFiles).length, 'predecessor tracked file count');
  for (const file of files) assert.equal(sha256(await readFile(join(baseline.checkout, file))), baseline.sourceFiles[file], file);
  assert.deepEqual(await artifacts.collectArtifacts(baseline.checkout), baseline.artifacts, 'predecessor build artifacts');
  const closing = sup.gitReadback(baseline);
  assert.deepEqual([closing.status, closing.head, closing.tree], ['', baseline.head, baseline.tree]);
  return { head: closing.head, tree: closing.tree, sourceFiles: files.length, artifactInventorySha256: baseline.artifacts.inventorySha256,
    launcherSha256: baseline.launcher.sha256 };
}

export async function runLegacyWriter(ctx) {
  const { session } = ctx.qa;
  const { sup } = session.lib;
  const { observe, refused } = session.lib.native;
  const baseline = session.legacy;
  assert(baseline && session.admission.label === 'candidate', 'legacy-writer control is candidate-only');
  const opening = await verifyPredecessor(session, baseline);
  const root = await ctx.privateDir('legacy-root');
  const active = join(root, 'gateway.log');
  const predecessorConfig = ctx.config({ repo: baseline.checkout, dataDir: await ctx.store('predecessor'), port: await ctx.port() });
  const predecessorPath = await ctx.writeConfig(root, 'predecessor', predecessorConfig);
  const mainRel = 'apps/api/dist/main.js';
  assert.equal(sha256(await readFile(join(baseline.checkout, ...mainRel.split('/')))), baseline.artifacts.outputFiles[mainRel], 'predecessor main.js');
  const predecessor = await bootLauncher(ctx, 'predecessor', baseline.launcher.path, predecessorPath, predecessorConfig, { cwd: baseline.checkout });
  const sentinel = 'qa438-legacy-writer-sentinel-' + sha256(String(predecessor.proof.health.pid)).slice(0, 8);
  await health(session, predecessor.port, '/healthz?' + sentinel + '=1');
  await observe('predecessor appended its access line', async () => (await readFile(active)).includes(sentinel), 5000);
  const before = await observe('predecessor log quiescent', async () => {
    const first = await sup.fileState(active);
    await new Promise((done) => setTimeout(done, 400));
    const second = await sup.fileState(active);
    return first.size === second.size && first.id === second.id ? second : false;
  }, 8000);
  const contenderConfig = ctx.config({ dataDir: await ctx.store('candidate-contender'), port: await ctx.port(), startup: 2 });
  const contenderPath = await ctx.writeConfig(root, 'candidate-contender', contenderConfig);
  const refusal = await launch(ctx, 'candidate-contender', session.launcher, contenderPath, { expect: 1 });
  const record = await lastRecord(root);
  const held = await sup.fileState(active);
  const prefixUnchanged = sha256((await readFile(active)).subarray(0, before.size)) === before.sha256;
  const contender = { ...(await lockAndEntries(contenderConfig.DataDir)), portRefused: await refused(contenderConfig.Port) };
  assert.deepEqual(await prove(ctx, predecessor), predecessor.proof, 'predecessor identity, birth or leases changed');
  const drained = await drainOwned(ctx, predecessor);
  const closing = await verifyPredecessor(session, baseline);
  const evidence = { opening, closing, before, held, prefixUnchanged, contender, record,
    refusal: { exit: refusal.exit, stdoutBytes: refusal.stdoutBytes, stderrBytes: refusal.stderrBytes, stderr: refusal.stderr }, drained };
  await ctx.put('evidence.json', evidence);
  const text = textPredicates(session, refusal, record, undefined);
  return {
    tier: 'native',
    route: 'parent legacy-sharing refusal against the live retained e21c predecessor gateway',
    predicates: {
      ...text.predicates,
      'rc3-legacy-writer-untouched': {
        status: held.id === before.id && prefixUnchanged && contender.entries.length === 0 && contender.locks.length === 0 && contender.portRefused &&
          JSON.stringify(opening) === JSON.stringify(closing) ? 'pass' : 'fail',
        detail: { activeId: held.id, prefixUnchanged, contender, predecessorBindingStable: JSON.stringify(opening) === JSON.stringify(closing) },
      },
      'predecessor-drained': { status: drained.leasesAbsent ? 'pass' : 'fail', detail: { pid: drained.pid, birth: drained.birth } },
    },
  };
}
