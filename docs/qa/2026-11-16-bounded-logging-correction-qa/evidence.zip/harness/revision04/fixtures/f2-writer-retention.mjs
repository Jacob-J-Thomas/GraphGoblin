// #438 F2 (RC2): retained encoded payload of the built production gateway writer across awaited I/O.
// Controlled tier. The exact built `gateway-log-writer.js` runs with real files; only its documented
// `fs` seam (wrapping the exported nodeLogFileSystem), `observe` and, for faults, `schedule` are
// supplied. Every reached file operation is held at the seam. At each hold the child leaves the
// current job, forces full GC (--expose-gc) and samples, as separate quantities:
//   logical      writer.pendingBytes (the writer's own counter)
//   measured     nonoverlapping payload lines (run-tagged records and the fixed writer markers)
//                inside live tracked views, merged per backing allocation; simultaneous copies in
//                distinct allocations count again (root decision on the 256 KiB cap)
//   copies       per record id, the number of distinct live allocations with a tagged range
//   full copies  exact 65,536-byte records (including LF) for scenario A, per live backing
//   unattributed tagged lines of dead tracked views whose non-pool backing allocation is still
//                alive (an untracked derived view may retain them): a measurement gap
//   poolResidue  the same inside Node's shared Buffer pool: allocator overhead, reported only
//   backing      whole live backing allocations that hold measured lines, reported only
//   process      process.memoryUsage() deltas, reported only
// Tracking keeps weak references to views and backings plus scalar offset/length metadata; the
// only strong references across a sample are those production holds itself (including the write
// argument the seam passes through). No product debug API is used.
import assert from 'node:assert/strict';
import { createHash, randomBytes } from 'node:crypto';
import { mkdirSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import { readFile } from 'node:fs/promises';
import { basename, join } from 'node:path';
import { performance } from 'node:perf_hooks';
import { setImmediate as tick } from 'node:timers/promises';
import { fileURLToPath, pathToFileURL } from 'node:url';

const SLOT = 4 * 1024 * 1024;
const RECORD = 64 * 1024;
const PENDING = 256 * 1024;
const SEED_BYTES = 3_600_000;
const PRESSURE_BUDGET = 2 * 1024 * 1024;
const MARKERS = ['gateway log record omitted', 'gateway log records dropped'];
const TRACKED = ['Buffer.from(', 'Buffer.concat(', 'Buffer.alloc(', 'Buffer.allocUnsafe(', 'Buffer.allocUnsafeSlow(', 'TextEncoder'];
const UNTRACKED = ['new Uint8Array', 'new ArrayBuffer', 'Buffer.copyBytesFrom', 'new SharedArrayBuffer', 'encodeInto', 'new DataView', 'Buffer.of('];
const DERIVED = ['.subarray(', '.slice('];

// ------------------------------------------------------------------ driver side

export async function run(ctx) {
  const { session } = ctx.qa;
  const rel = 'apps/api/dist/windows-log/gateway-log-writer.js';
  const root = await ctx.dir('f2');
  const specPath = join(ctx.evidence, 'f2-spec.json');
  const spec = {
    writerPath: join(session.checkout, ...rel.split('/')), writerSha256: session.build.files[rel], root,
    outPath: join(ctx.evidence, 'f2-child-result.json'), tag: 'qa438f2' + randomBytes(5).toString('hex'), seed: 438,
    seedBytes: SEED_BYTES, pressureBudget: PRESSURE_BUDGET,
  };
  assert(spec.writerSha256, 'writer not in the admitted build');
  await ctx.put('f2-spec.json', spec);
  // Reused V4 run: receipts, bounded raw streams, clean case environment. A controlled child is
  // never terminated: on timeout it is retained and the case close reports incomplete cleanup.
  const call = await ctx.native.run('f2-child', session.node,
    ['--expose-gc', fileURLToPath(import.meta.url), '--child', specPath], root, { childEnv: ctx.env, timeout: 240_000 });
  assert.equal(call.stdoutEnd?.bytes, call.stdoutBytes, 'f2 child stdout EOF');
  assert.equal(call.stderrEnd?.bytes, call.stderrBytes, 'f2 child stderr EOF');
  if (call.exit.code !== 0) return { status: 'error', tier: 'controlled', error: { childExit: call.exit.code, stderr: call.stderr.slice(0, 4000) } };
  return evaluate(JSON.parse(await readFile(spec.outPath, 'utf8')));
}

const status = (ok, reached = true) => (!reached ? 'not-reached' : ok ? 'pass' : 'fail');

/** The decisive old-build witness: the 196,608-byte following write (or its held pre-write
 * transition) with two live copies of each of the three backlog records, over the cap. */
export function decisiveWitness(a) {
  const first = (a.points ?? []).find((point) => point.label === 'first-write-held-with-backlog');
  if (!first) return { observed: false, reason: 'backlog hold not reached' };
  const ids = ['retention-a-1', 'retention-a-2', 'retention-a-3'];
  const rows = a.points.filter((point) => point.index > first.index &&
    (point.writeLength === 3 * RECORD || (point.op === 'lstat' && point.nextWriteLength === 3 * RECORD)) &&
    ids.every((id) => (point.fullRecordCopies?.[id] ?? 0) >= 2) && point.measuredTagged > PENDING);
  return { observed: rows.length > 0, ids, points: rows.slice(0, 4).map((point) => ({ index: point.index, op: point.op, opSeq: point.opSeq,
    writeLength: point.writeLength, nextWriteLength: point.nextWriteLength, logicalPending: point.logicalPending,
    measuredTagged: point.measuredTagged, copies: point.copies, fullRecordCopies: point.fullRecordCopies })) };
}

export function evaluate(result) {
  const scenarios = result.scenarios;
  const names = Object.keys(scenarios);
  const errors = names.filter((name) => scenarios[name].error).map((name) => ({ scenario: name, error: scenarios[name].error }));
  const points = names.flatMap((name) => scenarios[name].points ?? []);
  const max = (key) => Math.max(0, ...points.map((point) => point[key] ?? 0));
  const a = scenarios['retention-a'] ?? {};
  const p = scenarios.pressure ?? {};
  const backlogReached = Boolean(a.checks && a.checks.firstWriteLength === RECORD && a.checks.backlogAccepted?.every(Boolean) &&
    a.checks.backlogPending === 4 * RECORD && a.checks.completedWrites >= 2);
  const head = (a.points ?? []).find((point) => point.label === 'first-write-held-with-backlog');
  const fullHeadCopies = head?.fullRecordCopies?.['retention-a-0'] ?? 0;
  const headCaptured = head?.op === 'handle.write' && head.writeLength === RECORD &&
    head.writeMatchesExpectedHead === true && fullHeadCopies > 0;
  const over = points.filter((point) => point.measuredTagged > PENDING);
  const gapOver = points.filter((point) => point.measuredTagged + point.unattributedTagged > PENDING);
  const untracked = result.coverage?.untrackedUsed ?? ['unknown'];
  const witness = decisiveWitness(a);
  let retained = 'pass';
  if (errors.length) retained = 'error';
  else if (!backlogReached) retained = 'not-reached';
  else if (!headCaptured) retained = 'inconclusive';
  else if (over.length) retained = 'fail';
  else if (gapOver.length || untracked.length) retained = 'inconclusive';
  const invariantRows = names.map((name) => ({ scenario: name, ...(scenarios[name].invariants ?? {}) }));
  const invariantFailures = invariantRows.filter((row) => Object.entries(row).some(([key, ok]) => key !== 'scenario' && ok !== true));
  const fault = (name) => {
    const row = scenarios[name];
    if (!row || row.error) return { status: 'error', detail: row?.error ?? 'missing' };
    const c = row.checks;
    const reached = c.headCommitted === true && c.faultReached === true;
    const ok = ['headCommitted', 'faultReached', 'rollback', 'scheduling', 'queueRelease', 'ackFalse', 'oneOp'].every((key) => c[key] === true);
    return { status: status(ok, reached), detail: c };
  };
  return {
    tier: 'controlled',
    predicates: {
      'rc2-logical-cap': { status: errors.length ? 'error' : status(points.length > 0 && points.every((point) => point.logicalPending <= PENDING), points.length > 0),
        detail: { maxLogical: max('logicalPending'), points: points.length } },
      'rc2-backlog-reached': { status: errors.length ? 'error' : status(true, backlogReached),
        detail: { checks: a.checks ?? null, note: 'Same accepted backlog on both builds: a held 65,536-byte first write and three accepted 65,536-byte records behind it; writes may split.' } },
      'rc2-retained-cap': {
        status: retained,
        detail: {
          cap: PENDING, maxMeasured: max('measuredTagged'), maxUnattributed: max('unattributedTagged'),
          headCapture: { observed: headCaptured, fullCopies: fullHeadCopies, opSeq: head?.opSeq ?? null,
            writeMatchesExpectedHead: head?.writeMatchesExpectedHead ?? null },
          decisiveWitness: witness,
          over: over.slice(0, 10).map(({ scenario, index, op, opSeq, writeLength, nextWriteLength, logicalPending, measuredTagged, copies }) =>
            ({ scenario, index, op, opSeq, writeLength, nextWriteLength, logicalPending, measuredTagged, copies })),
          gapPoints: gapOver.slice(0, 10).map(({ scenario, index, measuredTagged, unattributedTagged }) => ({ scenario, index, measuredTagged, unattributedTagged })),
          untrackedPrimitives: untracked,
          reading: 'Distinct live encoded payload lines per backing allocation; simultaneous encoded copies count (root decision). Transient encoding and allocator overhead are separate.',
          qualification: 'A measured value is a lower bound of live tracked payload: over the cap rejects. A pass means tracked samples support the targeted correction; complete accounting rests on the implementation invariant and source data-flow review, not on a whole-heap inference.',
        },
      },
      'rc2-rotation-reached': { status: errors.length ? 'error' : status(true, Boolean(p.checks?.seedExact && p.checks?.rotationReached && p.checks?.seedInPreviousAtFirstRotation?.ok)),
        detail: { seed: p.seed ?? null, checks: p.checks ?? null } },
      'writer-invariants': { status: errors.length ? 'error' : invariantFailures.length === 0 && invariantRows.length > 0 ? 'pass' : 'fail',
        detail: { invariants: invariantRows } },
      'rc2-fault-short': fault('fault-short'),
      'rc2-fault-enospc': fault('fault-enospc'),
      'released-after-close': { status: names.length > 0 && names.every((name) => scenarios[name].afterClose?.measuredTagged === 0) ? 'pass' : 'fail',
        detail: Object.fromEntries(names.map((name) => [name, scenarios[name].afterClose ?? null])) },
      'transient-allocation': { status: 'informational', detail: Object.fromEntries(names.map((name) => [name, scenarios[name].allocation ?? null])) },
      'backing-allocation': { status: 'informational', detail: { maxBackingBytes: max('backingBytes'), maxPoolResidue: max('poolResidue') } },
      'whole-process-memory': { status: 'informational', detail: { maxArrayBuffersDelta: max('arrayBuffersDelta'), maxHeapUsedDelta: max('heapUsedDelta') } },
      'measurement-coverage': { status: 'informational', detail: { ...result.coverage,
        gaps: ['Queued JS strings or other non-Buffer representations are invisible to view tracking (heapUsed delta only).',
          'Payload created through an untracked primitive listed in untrackedUsed is invisible unless a tracked view shares its backing.',
          'Lines inside a live view count even when the writer no longer needs them (for example a reused buffer); this can over-count but never under-count tracked views.',
          'Dead-view lines in a live non-pool backing are reported as unattributed and decide inconclusive only when they could cross the cap.'] } },
    },
    errors,
    exports: result.exports,
  };
}

// ------------------------------------------------------------------ child side

const sha = (value) => createHash('sha256').update(value).digest('hex');

function sourceCoverage(text) {
  const count = (list) => Object.fromEntries(list.map((name) => [name, text.split(name).length - 1]));
  const untracked = count(UNTRACKED);
  return { tracked: count(TRACKED), untracked, derivedViews: count(DERIVED),
    untrackedUsed: UNTRACKED.filter((name) => untracked[name] > 0) };
}

function createTracker(tag) {
  const tagPattern = Buffer.from('"' + tag + '":"', 'latin1');
  const markerPatterns = MARKERS.map((marker) => Buffer.from(marker, 'latin1'));
  const original = { from: Buffer.from, concat: Buffer.concat, alloc: Buffer.alloc, allocUnsafe: Buffer.allocUnsafe,
    allocUnsafeSlow: Buffer.allocUnsafeSlow, encode: TextEncoder.prototype.encode };
  const entries = [];
  const seen = new WeakSet();
  let enabled = false;
  let scenario = null;
  let sequence = 0;
  let allocatedSince = 0;
  const viaCounts = {};
  const capture = (value, via) => {
    try {
      if (enabled && value instanceof Uint8Array && !seen.has(value)) {
        seen.add(value);
        entries.push({ view: new WeakRef(value), backing: new WeakRef(value.buffer), offset: value.byteOffset,
          length: value.byteLength, via, scenario, seq: ++sequence });
        allocatedSince += value.byteLength;
        viaCounts[via] = (viaCounts[via] ?? 0) + 1;
      }
    } catch { /* tracking never affects the writer */ }
    return value;
  };
  Buffer.from = function from(...args) { return capture(original.from.apply(this, args), 'Buffer.from'); };
  Buffer.concat = function concat(...args) { return capture(original.concat.apply(this, args), 'Buffer.concat'); };
  Buffer.alloc = function alloc(...args) { return capture(original.alloc.apply(this, args), 'Buffer.alloc'); };
  Buffer.allocUnsafe = function allocUnsafe(...args) { return capture(original.allocUnsafe.apply(this, args), 'Buffer.allocUnsafe'); };
  Buffer.allocUnsafeSlow = function allocUnsafeSlow(...args) { return capture(original.allocUnsafeSlow.apply(this, args), 'Buffer.allocUnsafeSlow'); };
  TextEncoder.prototype.encode = function encode(...args) { return capture(original.encode.apply(this, args), 'TextEncoder.encode'); };

  /** Payload lines inside one tracked range: each LF-delimited line carrying the run tag or a fixed marker. */
  const scan = (backing, offset, length, expectedFullRecords) => {
    const bytes = original.from.call(Buffer, backing, offset, length);
    const lines = new Map();
    const add = (hit, id, marker) => {
      const start = hit === 0 ? 0 : bytes.lastIndexOf(10, hit - 1) + 1;
      const newline = bytes.indexOf(10, hit);
      const end = newline < 0 ? bytes.length : newline + 1;
      if (lines.has(start)) return;
      const expected = expectedFullRecords?.get(id);
      const full = expected !== undefined && newline >= 0 && end - start === RECORD &&
        sha(bytes.subarray(start, end)) === expected;
      lines.set(start, { start: offset + start, end: offset + end, id, marker, full });
    };
    for (let at = bytes.indexOf(tagPattern); at >= 0; at = bytes.indexOf(tagPattern, at + 1)) {
      const from = at + tagPattern.length;
      const close = bytes.indexOf(34, from);
      add(at, close < 0 ? null : bytes.toString('latin1', from, close), null);
    }
    markerPatterns.forEach((pattern, index) => {
      for (let at = bytes.indexOf(pattern); at >= 0; at = bytes.indexOf(pattern, at + 1)) add(at, null, MARKERS[index]);
    });
    return [...lines.values()];
  };
  const merge = (ranges) => {
    const sorted = [...ranges].sort((x, y) => x.start - y.start);
    const merged = [];
    for (const range of sorted) {
      const last = merged.at(-1);
      if (last && range.start < last.end) {
        last.end = Math.max(last.end, range.end);
        if (range.id) last.ids.add(range.id);
        if (range.marker) last.markers++;
      } else merged.push({ start: range.start, end: range.end, ids: new Set(range.id ? [range.id] : []), markers: range.marker ? 1 : 0 });
    }
    return merged;
  };
  const outside = (range, covered) => {
    let bytes = range.end - range.start;
    for (const live of covered) bytes -= Math.max(0, Math.min(range.end, live.end) - Math.max(range.start, live.start));
    return Math.max(0, bytes);
  };

  return {
    capture,
    get enabled() { return enabled; },
    set enabled(value) { enabled = value; },
    set scenario(value) { scenario = value; },
    takeAllocated() { const value = allocatedSince; allocatedSince = 0; return value; },
    viaCounts,
    entryCount: () => entries.length,
    restore() {
      Object.assign(Buffer, { from: original.from, concat: original.concat, alloc: original.alloc,
        allocUnsafe: original.allocUnsafe, allocUnsafeSlow: original.allocUnsafeSlow });
      TextEncoder.prototype.encode = original.encode;
    },
    /** Leave the current job (WeakRef KeepDuringJob), collect fully, then sample live payload lines. */
    async measure(current, expectedFullRecords) {
      await tick();
      await tick();
      globalThis.gc();
      globalThis.gc();
      const wasEnabled = enabled;
      enabled = false;
      try {
        const live = new Map();
        const dead = new Map();
        const vias = {};
        let liveViews = 0;
        for (let index = entries.length - 1; index >= 0; index--) {
          const entry = entries[index];
          const backing = entry.backing.deref();
          if (backing === undefined) { entries.splice(index, 1); continue; }
          const view = entry.view.deref();
          const lines = scan(backing, entry.offset, entry.length, view === undefined ? undefined : expectedFullRecords);
          if (lines.length === 0) { if (view === undefined) entries.splice(index, 1); continue; }
          let target;
          if (view !== undefined) {
            target = live;
            liveViews++;
            vias[entry.via] = (vias[entry.via] ?? 0) + 1;
          } else if (entry.scenario === current) target = dead;
          else { entries.splice(index, 1); continue; }
          if (!target.has(backing)) target.set(backing, { ranges: [], byteLength: backing.byteLength, pool: backing.byteLength === Buffer.poolSize });
          target.get(backing).ranges.push(...lines);
        }
        let tagged = 0;
        let markerLines = 0;
        let backingBytes = 0;
        const copies = {};
        const fullRecordCopies = {};
        const mergedLive = new Map();
        for (const [backing, group] of live) {
          const merged = merge(group.ranges);
          mergedLive.set(backing, merged);
          backingBytes += group.byteLength;
          const ids = new Set();
          const fullIds = new Set();
          for (const range of merged) {
            tagged += range.end - range.start;
            markerLines += range.markers;
            for (const id of range.ids) ids.add(id);
          }
          for (const range of group.ranges) {
            if (range.full) fullIds.add(range.id);
          }
          for (const id of ids) copies[id] = (copies[id] ?? 0) + 1;
          for (const id of fullIds) fullRecordCopies[id] = (fullRecordCopies[id] ?? 0) + 1;
        }
        let unattributed = 0;
        let poolResidue = 0;
        for (const [backing, group] of dead) {
          const covered = mergedLive.get(backing) ?? [];
          for (const range of merge(group.ranges)) {
            const bytes = outside(range, covered);
            if (group.pool) poolResidue += bytes; else unattributed += bytes;
          }
        }
        const usage = process.memoryUsage();
        return { tagged, markerLines, copies, fullRecordCopies, unattributed, poolResidue, backingBytes, liveViews, vias,
          arrayBuffers: usage.arrayBuffers, heapUsed: usage.heapUsed, entries: entries.length };
      } finally { enabled = wasEnabled; }
    },
  };
}

function createSeam(real, tracker, plan) {
  const ops = [];
  let inFlight = 0;
  let maxInFlight = 0;
  let writes = 0;
  let held = null;
  let stepping = false;
  const step = async (op, detail, work) => {
    const row = { seq: ops.length + 1, op, ...detail };
    ops.push(row);
    inFlight++;
    maxInFlight = Math.max(maxInFlight, inFlight);
    try {
      if (stepping) await new Promise((release) => { held = { row, release }; });
      const value = await work(row);
      row.ok = true;
      return value;
    } catch (error) {
      row.ok = false;
      row.code = error?.code;
      throw error;
    } finally {
      inFlight--;
    }
  };
  const wrap = (handle, path) => ({
    stat: () => step('handle.stat', { path }, () => handle.stat()),
    read: (buffer, offset, length, position) => step('handle.read', { path, length, position }, () => handle.read(buffer, offset, length, position)),
    write: (buffer, offset, length, position) => {
      tracker.capture(buffer, 'io.write');
      const n = ++writes;
      const headSha256 = plan.proveHead && n === 1 && length === RECORD
        ? sha(buffer.subarray(offset, offset + length)) : null;
      return step('handle.write', { path, n, length, position, preWriteFits: position + length <= SLOT, headSha256 }, async (row) => {
        // The fault decision is taken only when the held operation is actually released and reached.
        const fault = plan.write?.(row);
        if (fault) row.injected = fault;
        if (fault === 'enospc') throw Object.assign(new Error('qa438 injected ENOSPC'), { code: 'ENOSPC' });
        const actual = fault === 'short' ? length - 7 : length;
        const result = await handle.write(buffer, offset, actual, position);
        row.bytesWritten = result.bytesWritten;
        return { bytesWritten: result.bytesWritten };
      });
    },
    truncate: (length) => step('handle.truncate', { path, length }, () => handle.truncate(length)),
    close: () => step('handle.close', { path }, () => handle.close()),
  });
  const fs = {
    lstat: (path) => step('lstat', { path: basename(path) }, () => real.lstat(path)),
    open: (path, mode) => step('open', { path: basename(path), mode }, async () => wrap(await real.open(path, mode), basename(path))),
    rename: (from, to) => step('rename', { path: basename(from), to: basename(to) }, () => real.rename(from, to)),
  };
  return {
    fs, ops,
    get maxInFlight() { return maxInFlight; },
    get inFlight() { return inFlight; },
    get held() { return held; },
    take() { const value = held; held = null; return value; },
    set stepping(value) { stepping = value; },
  };
}

function prng(seed) {
  let state = seed >>> 0;
  return () => {
    state = (state + 0x6d2b79f5) >>> 0;
    let value = state;
    value = Math.imul(value ^ (value >>> 15), value | 1);
    value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
  };
}

/** One JSON record of exactly `total` UTF-8 bytes including LF; every record carries the run tag. */
function record(total, tag, id, tail = '') {
  const prefix = `{"level":30,"${tag}":"${id}","pad":"`;
  const suffix = '"}\n';
  const count = total - Buffer.byteLength(prefix + tail + suffix);
  assert(count >= 0, 'record too short');
  const text = prefix + 'a'.repeat(count) + tail + suffix;
  assert.equal(Buffer.byteLength(text), total);
  return text;
}

async function until(predicate, timeoutMs) {
  const deadline = performance.now() + timeoutMs;
  while (performance.now() < deadline) {
    if (predicate()) return true;
    await tick();
  }
  return predicate();
}

const within = (promise, ms, fallback) => Promise.race([promise, new Promise((done) => setTimeout(() => done(fallback), ms))]);

function lines(path) {
  let bytes;
  try { bytes = readFileSync(path); } catch (error) { if (error.code === 'ENOENT') return []; throw error; }
  const rows = [];
  let offset = 0;
  const decoder = new TextDecoder('utf-8', { fatal: true });
  while (offset < bytes.length) {
    const end = bytes.indexOf(10, offset);
    if (end < 0) { rows.push({ incomplete: true, length: bytes.length - offset }); break; }
    const line = bytes.subarray(offset, end + 1);
    let value;
    try { value = JSON.parse(decoder.decode(line)); } catch { value = undefined; }
    rows.push({ length: line.length, value, sha: sha(line) });
    offset = end + 1;
  }
  return rows;
}

/** Seed arithmetic kept from preparation 01, plus the exact byte-size readback. */
function writeSeed(path, seedBytes) {
  const parts = [];
  let size = 0;
  for (let index = 0; size < seedBytes; index++) {
    const width = Math.min(1024, seedBytes - size);
    const head = `{"msg":"qa438seed","i":${index},"p":"`;
    const pad = width - head.length - 3;
    if (pad < 1) break;
    const line = head + 's'.repeat(pad) + '"}\n';
    assert.equal(Buffer.byteLength(line), width);
    parts.push(line);
    size += width;
  }
  const text = parts.join('');
  writeFileSync(path, text, { flag: 'wx' });
  const info = statSync(path, { bigint: true });
  assert.equal(Number(info.size), seedBytes, 'exact seed byte size');
  return { bytes: Number(info.size), requested: seedBytes, lines: parts.length, sha256: sha(text), id: info.dev + ':' + info.ino };
}

async function child(specPath) {
  assert.equal(typeof globalThis.gc, 'function', 'run with --expose-gc');
  const spec = JSON.parse(readFileSync(specPath, 'utf8'));
  const source = readFileSync(spec.writerPath);
  assert.equal(sha(source), spec.writerSha256, 'writer digest');
  const coverage = sourceCoverage(source.toString('utf8'));
  const W = await import(pathToFileURL(spec.writerPath).href);
  const exportsSeen = { openGatewayLog: typeof W.openGatewayLog, nodeLogFileSystem: typeof W.nodeLogFileSystem,
    PENDING: W.GATEWAY_LOG_PENDING_BYTES, RECORD: W.GATEWAY_LOG_RECORD_BYTES, SLOT: W.GATEWAY_LOG_SLOT_BYTES };
  assert.deepEqual([exportsSeen.openGatewayLog, exportsSeen.nodeLogFileSystem, exportsSeen.PENDING, exportsSeen.RECORD, exportsSeen.SLOT],
    ['function', 'object', PENDING, RECORD, SLOT], 'writer API differs from the admitted contract');
  const tracker = createTracker(spec.tag);
  const random = prng(spec.seed);
  const scenarios = {};
  let active = null;

  /** Pause tracking around harness-only file reads; nothing read here is kept across a sample. */
  const quiet = (work) => {
    const was = tracker.enabled;
    tracker.enabled = false;
    try { return work(); } finally { tracker.enabled = was; }
  };

  async function openScenario(name, { seedBytes = 0, schedule, plan = {} } = {}) {
    const root = join(spec.root, name);
    mkdirSync(root);
    const seed = seedBytes > 0 ? writeSeed(join(root, 'gateway.log'), seedBytes) : null;
    tracker.scenario = name;
    const events = [];
    const seam = createSeam(W.nodeLogFileSystem, tracker, plan);
    const writer = await W.openGatewayLog({ root, fs: seam.fs, observe: (event) => events.push({ ...event, afterOp: seam.ops.length }),
      ...(schedule ? { schedule } : {}) });
    const s = { name, root, seed, events, seam, writer, schedule, accepted: [], acks: [], points: [], checks: {} };
    active = s;
    s.base = await tracker.measure(name);
    tracker.enabled = true;
    tracker.takeAllocated();
    seam.stepping = true;
    const drops = () => events.filter((event) => event.type === 'drop').length;
    s.put = (size, { kind = 'tagged', ack = false } = {}) => {
      const id = `${name}-${s.accepted.length}`;
      const text = record(size, spec.tag, id, kind === 'multibyte' ? String.fromCodePoint(0x20ac, 0xe9) : '');
      const entry = { id, size, kind, marker: size > RECORD, sha: size > RECORD ? null : sha(text) };
      const before = drops();
      if (ack) {
        const promise = writer.writeAcknowledged(text).then((written) => ({ id, written,
          presentAtAck: written ? quiet(() => [...lines(join(root, 'gateway.log')), ...lines(join(root, 'gateway.log.1'))].some((row) => row.sha === entry.sha)) : null }));
        if (drops() !== before) return false;
        s.acks.push({ id, promise });
      } else if (!writer.write(text)) return false;
      s.accepted.push(entry);
      return true;
    };
    s.next = async () => {
      const reached = await until(() => seam.held !== null || (writer.pendingBytes === 0 && seam.inFlight === 0), 10_000);
      assert(reached, name + ': writer neither reached an operation nor became idle');
      return seam.held;
    };
    s.measure = async (label) => {
      const gate = seam.held;
      const expectedFullRecords = name === 'retention-a'
        ? new Map(s.accepted.map(({ id, sha: digest }) => [id, digest])) : undefined;
      const m = await tracker.measure(name, expectedFullRecords);
      const own = Object.entries(m.copies).filter(([id]) => id.startsWith(name + '-'));
      const point = { scenario: name, label, index: s.points.length, op: gate ? gate.row.op : 'idle', opSeq: gate ? gate.row.seq : null,
        path: gate?.row.path ?? null, writeLength: gate?.row.op === 'handle.write' ? gate.row.length : null, position: gate?.row.position ?? null,
        logicalPending: writer.pendingBytes, state: writer.state, measuredTagged: m.tagged, markerLines: m.markerLines,
        unattributedTagged: m.unattributed, poolResidue: m.poolResidue, backingBytes: m.backingBytes, liveTaggedViews: m.liveViews, vias: m.vias,
        copies: name.startsWith('retention') ? Object.fromEntries(own) : { maxCopies: Math.max(0, ...own.map(([, n]) => n)), multiCopyIds: own.filter(([, n]) => n > 1).length },
        ...(expectedFullRecords ? { fullRecordCopies: m.fullRecordCopies,
          writeMatchesExpectedHead: gate?.row.headSha256 != null && gate.row.headSha256 === s.accepted[0]?.sha } : {}),
        foreignLiveIds: Object.keys(m.copies).length - own.length,
        transientAllocated: tracker.takeAllocated(), arrayBuffersDelta: m.arrayBuffers - s.base.arrayBuffers, heapUsedDelta: m.heapUsed - s.base.heapUsed };
      s.points.push(point);
      return point;
    };
    s.release = () => { const held = seam.take(); assert(held, name + ': nothing held'); held.release(); };
    s.advanceTo = async (predicate, label) => {
      for (let count = 0; count < 64; count++) {
        const gate = await s.next();
        if (!gate) throw new Error(name + ': idle before ' + label);
        if (predicate(gate.row)) return gate;
        await s.measure('before-' + label);
        s.release();
      }
      throw new Error(name + ': ' + label + ' not reached');
    };
    s.drainAll = async (maxSteps, onHold) => {
      for (let count = 0; count < maxSteps; count++) {
        const gate = await s.next();
        if (!gate) return count;
        if (onHold) await onHold(gate);
        await s.measure('hold');
        s.release();
      }
      throw new Error(name + ': step cap ' + maxSteps);
    };
    s.readActive = () => quiet(() => {
      const path = join(root, 'gateway.log');
      const bytes = readFileSync(path);
      return { size: bytes.length, sha256: sha(bytes) };
    });
    s.finish = async () => {
      seam.stepping = false;
      const held = seam.take();
      if (held) held.release();
      tracker.enabled = false;
      const stateAtEnd = writer.state;
      const pendingAtEnd = writer.pendingBytes;
      const settled = schedule ? null : await within(writer.settle(5000), 8000, false);
      const acks = await within(Promise.all(s.acks.map((item) => item.promise)), 8000, null);
      const closed = await within(writer.close().then(() => true), 10_000, false);
      const after = await tracker.measure(name);
      const writes = seam.ops.filter((row) => row.op === 'handle.write');
      for (const point of s.points) {
        const next = point.opSeq === null ? undefined : writes.find((row) => row.seq >= point.opSeq);
        point.nextWriteLength = next?.length ?? null;
      }
      const files = { previous: lines(join(root, 'gateway.log.1')), active: lines(join(root, 'gateway.log')) };
      const all = [...files.previous, ...files.active];
      const committed = all.filter((row) => row.value?.msg !== 'qa438seed')
        .map((row) => (row.value?.[spec.tag] ?? (MARKERS.some((marker) => String(row.value?.msg ?? '').startsWith(marker)) ? 'MARKER' : 'OTHER')));
      const expected = s.accepted.map((item) => (item.marker ? 'MARKER' : item.id));
      const dropEvents = events.filter((event) => event.type === 'drop');
      const completedWrites = events.filter((event) => event.type === 'write' && event.result === 'complete').length;
      Object.assign(s.result = {}, {
        root, seed, stateAtEnd, pendingAtEnd, settled, closed, points: s.points,
        afterClose: { measuredTagged: after.tagged, unattributedTagged: after.unattributed, poolResidue: after.poolResidue },
        allocation: { trackedBytes: s.points.reduce((sum, point) => sum + point.transientAllocated, 0),
          maxPerStep: Math.max(0, ...s.points.map((point) => point.transientAllocated)), cumulativeViaCounts: { ...tracker.viaCounts } },
        ops: seam.ops.length, maxInFlight: seam.maxInFlight,
        writes: writes.map((row) => ({ seq: row.seq, n: row.n, length: row.length, position: row.position, bytesWritten: row.bytesWritten,
          ok: row.ok, code: row.code, injected: row.injected ?? null })),
        events: events.map(({ type, step, result, reason, bytes, records, bytesWritten, size, faults, delayMs, code, afterOp }) =>
          ({ type, step, result, reason, bytes, records, bytesWritten, size, faults, delayMs, code, afterOp })),
        acks,
        files: { activeBytes: files.active.reduce((sum, row) => sum + (row.length ?? 0), 0),
          previousBytes: files.previous.reduce((sum, row) => sum + (row.length ?? 0), 0),
          activeLines: files.active.length, previousLines: files.previous.length },
        accepted: s.accepted.map(({ id, size, kind, marker }) => ({ id, size, kind, marker })),
        committed: { count: committed.length, expectedCount: expected.length, firstMismatch: committed.findIndex((value, index) => value !== expected[index]) },
        checks: s.checks,
      });
      s.result.invariants = {
        oneOpInFlight: seam.ops.length > 0 && seam.maxInFlight === 1,
        preWriteFits: writes.length > 0 && writes.every((row) => row.preWriteFits),
        completeRecords: all.length > 0 && all.every((row) => !row.incomplete && row.value !== undefined && row.length <= RECORD),
        slotCaps: s.result.files.activeBytes <= SLOT && s.result.files.previousBytes <= SLOT,
        closed: closed === true,
      };
      s.committedEqualsAccepted = committed.length === expected.length && committed.every((value, index) => value === expected[index]);
      s.dropEvents = dropEvents;
      s.completedWrites = completedWrites;
      s.files = files;
      active = null;
      return s.result;
    };
    return s;
  }

  async function guarded(name, work) {
    try { scenarios[name] = await work(); } catch (error) {
      scenarios[name] = { error: { message: error.message, stack: error.stack } };
      if (active) {
        active.seam.stepping = false;
        active.seam.take()?.release();
        tracker.enabled = false;
        await within(active.writer.close(), 5000, null).catch(() => undefined);
        active = null;
      }
    }
  }

  // A: a held 65,536-byte first write and three accepted 65,536-byte records behind it (the second
  // acknowledged), then every following operation held. The defective build reaches a 196,608-byte
  // coalesced write; a corrected build may split it.
  await guarded('retention-a', async () => {
    const s = await openScenario('retention-a', { plan: { proveHead: true } });
    assert(s.put(RECORD), 'head refused');
    const first = await s.advanceTo((row) => row.op === 'handle.write', 'first-write');
    s.checks.firstWriteLength = first.row.length;
    s.checks.backlogAccepted = [s.put(RECORD), s.put(RECORD, { ack: true }), s.put(RECORD)];
    s.checks.backlogPending = s.writer.pendingBytes;
    await s.measure('first-write-held-with-backlog');
    s.release();
    await s.drainAll(200);
    const result = await s.finish();
    s.checks.completedWrites = s.completedWrites;
    const ack = result.acks?.[0];
    Object.assign(result.invariants, {
      committedInOrder: s.committedEqualsAccepted && result.committed.count === 4,
      noDrops: s.dropEvents.length === 0,
      ackSucceeded: Array.isArray(result.acks) && result.acks.length === 1 && ack.written === true && ack.presentAtAck === true,
    });
    return result;
  });

  // B (supporting): a 300-byte held head, then the queue filled to the logical cap behind it.
  await guarded('retention-b', async () => {
    const s = await openScenario('retention-b');
    assert(s.put(300), 'head refused');
    const first = await s.advanceTo((row) => row.op === 'handle.write', 'first-write');
    s.checks.firstWriteLength = first.row.length;
    const sizes = [];
    for (let k = 0; k < 4; k++) {
      const size = Math.min(RECORD, PENDING - s.writer.pendingBytes);
      if (size < 1024) break;
      assert(s.put(size), 'backlog refused within logical capacity');
      sizes.push(size);
    }
    s.checks.backlogSizes = sizes;
    s.checks.backlogPending = s.writer.pendingBytes;
    await s.measure('first-write-held-with-backlog');
    s.release();
    await s.drainAll(200);
    const result = await s.finish();
    Object.assign(result.invariants, { committedInOrder: s.committedEqualsAccepted && result.committed.count === 1 + sizes.length,
      noDrops: s.dropEvents.length === 0 });
    return result;
  });

  // P: an exactly sized 3,600,000-byte seeded active slot, mixed sizes, multi-byte tails and
  // oversized markers, topped up within logical capacity at every hold, through exactly one
  // successful rotation whose previous slot must start with the seed.
  await guarded('pressure', async () => {
    const s = await openScenario('pressure', { seedBytes: spec.seedBytes });
    s.checks.seedExact = s.seed.bytes === spec.seedBytes;
    const mixed = () => {
      const pick = random();
      return pick < 0.35 ? RECORD : pick < 0.6 ? 16_384 : pick < 0.85 ? 5_000 : pick < 0.95 ? 9_001 : 70_000;
    };
    let injected = 0;
    let nextAck = 5;
    assert(s.put(RECORD), 'first record refused');
    injected += RECORD;
    await s.drainAll(1500, async () => {
      if (!s.checks.seedInPreviousAtFirstRotation &&
        s.events.some((event) => event.type === 'rotate' && event.step === 'rename' && event.result === 'complete')) {
        s.checks.seedInPreviousAtFirstRotation = quiet(() => {
          const path = join(s.root, 'gateway.log.1');
          const info = statSync(path, { bigint: true });
          const bytes = readFileSync(path);
          const prefix = sha(bytes.subarray(0, s.seed.bytes));
          const id = info.dev + ':' + info.ino;
          return { ok: prefix === s.seed.sha256 && id === s.seed.id && bytes.length >= s.seed.bytes,
            previousBytes: bytes.length, prefixMatches: prefix === s.seed.sha256, idMatches: id === s.seed.id };
        });
      }
      while (injected < spec.pressureBudget) {
        const want = mixed();
        if (s.writer.pendingBytes + Math.min(want, RECORD) > PENDING) break;
        const kind = want > RECORD ? 'oversized' : random() < 0.15 ? 'multibyte' : 'tagged';
        // Acknowledged records are never oversized: an oversized record is committed as the fixed marker.
        const ack = kind !== 'oversized' && s.accepted.length >= nextAck;
        assert(s.put(want, { kind, ack }), 'top-up refused within logical capacity');
        if (ack) nextAck = s.accepted.length + 39;
        injected += want;
      }
    });
    const result = await s.finish();
    const steps = (step) => s.events.filter((event) => event.type === 'rotate' && event.step === step && event.result === 'complete').length;
    s.checks.rotationSteps = { close: steps('close'), rename: steps('rename'), create: steps('create') };
    s.checks.rotationReached = steps('close') >= 1 && steps('rename') >= 1 && steps('create') >= 1;
    s.checks.exactlyOneRotation = steps('rename') === 1;
    s.checks.injectedBytes = injected;
    const acks = result.acks ?? [];
    Object.assign(result.invariants, {
      seedExact: s.checks.seedExact,
      rotationReached: s.checks.rotationReached && s.checks.seedInPreviousAtFirstRotation?.ok === true,
      exactlyOneRotation: s.checks.exactlyOneRotation,
      committedInOrder: s.committedEqualsAccepted,
      noDrops: s.dropEvents.length === 0,
      ackSucceeded: acks.length > 0 && acks.some((ack) => ack.written === true) && acks.every((ack) => ack.written !== true || ack.presentAtAck === true),
    });
    return result;
  });

  // F: the head (300 B) is committed first; the second reached write faults (short or ENOSPC)
  // whatever batch shape the build chose. Rollback, scheduling, queue release and the failed
  // acknowledgement are separate checks.
  for (const kind of ['short', 'enospc']) {
    await guarded('fault-' + kind, async () => {
      const scheduled = [];
      const injectedAt = [];
      let writeCalls = 0;
      const s = await openScenario('fault-' + kind, {
        schedule: (_callback, ms) => { scheduled.push(ms); return { cancel() {} }; },
        plan: { write: (row) => { writeCalls++; if (writeCalls === 2) { injectedAt.push({ n: row.n, seq: row.seq, length: row.length }); return kind; } return undefined; } },
      });
      assert(s.put(300), 'head refused');
      const first = await s.advanceTo((row) => row.op === 'handle.write', 'first-write');
      s.checks.firstWriteLength = first.row.length;
      s.checks.backlogAccepted = [s.put(RECORD), s.put(RECORD, { ack: true }), s.put(RECORD)];
      await s.measure('head-write-held-with-backlog');
      s.release();
      const next = await s.next();
      s.checks.afterHead = s.readActive();
      s.checks.headWriteEvent = s.events.find((event) => event.type === 'write') ?? null;
      if (next) { await s.measure('after-head-commit'); s.release(); }
      await s.drainAll(200);
      const result = await s.finish();
      const head = s.accepted[0];
      const writesSeen = s.events.filter((event) => event.type === 'write');
      const faulted = writesSeen[1];
      const finalActive = s.files.active;
      const drops = s.dropEvents;
      Object.assign(s.checks, {
        injectedAt, scheduled,
        headCommitted: s.checks.firstWriteLength === 300 && s.checks.headWriteEvent?.result === 'complete' &&
          s.checks.headWriteEvent?.bytes === 300 && s.checks.headWriteEvent?.records === 1 &&
          s.checks.afterHead.size === 300 && s.checks.afterHead.sha256 === head.sha,
        faultReached: injectedAt.length === 1 && injectedAt[0].n === 2 && faulted !== undefined &&
          (kind === 'short' ? faulted.result === 'partial' && faulted.bytesWritten === faulted.bytes - 7
            : faulted.result === 'failed' && faulted.code === 'ENOSPC'),
        rollback: finalActive.length === 1 && finalActive[0].sha === head.sha && result.files.activeBytes === 300 &&
          (kind === 'short' ? s.events.some((event) => event.type === 'rollback' && event.result === 'complete' && event.size === 300)
            : !s.events.some((event) => event.type === 'rollback' && event.result === 'failed')),
        scheduling: s.events.some((event) => event.type === 'suspend' && event.faults === 1 && event.delayMs === 1000) &&
          scheduled.includes(1000) && result.stateAtEnd === 'suspended',
        queueRelease: result.pendingAtEnd === 0 && drops.reduce((sum, event) => sum + event.records, 0) === 3 &&
          drops.every((event) => ['fault', 'suspended'].includes(event.reason)),
        ackFalse: Array.isArray(result.acks) && result.acks.length === 1 && result.acks[0].written === false,
        oneOp: result.invariants.oneOpInFlight,
      });
      return result;
    });
  }
  tracker.restore();
  writeFileSync(spec.outPath, JSON.stringify({ schema: 'gg438-f2-child/v2', node: process.version, exports: exportsSeen, coverage,
    tag: spec.tag, scenarios }, null, 2) + '\n', { flag: 'wx' });
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href && process.argv[2] === '--child') {
  child(process.argv[3]).then(() => process.exit(0), (error) => {
    process.stderr.write(String(error?.stack ?? error) + '\n');
    process.exit(1);
  });
}
