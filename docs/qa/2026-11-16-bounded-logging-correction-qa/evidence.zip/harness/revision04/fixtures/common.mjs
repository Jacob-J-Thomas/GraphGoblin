// #438 correction QA preparation 02: shared harness layer.
// Process supervision, case directories, the isolated case environment, holders, store/fixture
// cleanup readback and Windows process identity are the qualified helpers, imported by exact
// SHA-256 (REUSED). This module adds only the admission, the full-argv ownership proof (same
// approach as the supplemental proof, extended to the F1 read-only preload argv), API drain with
// re-proof before token GET and before POST, and the quiescent case close. Importing it performs
// read-only hashing and realpath reads only. It never deletes, signals a gateway or launcher,
// changes permissions or touches ports 4747/4748.
import assert from 'node:assert/strict';
import { createHash, randomBytes } from 'node:crypto';
import { createRequire } from 'node:module';
import { lstat, mkdir, readdir, readFile, realpath } from 'node:fs/promises';
import net from 'node:net';
import { basename, dirname, isAbsolute, join, resolve, sep } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

export const ADMISSION_SCHEMA = 'gg438-correction-qa-admission/v2';
export const RESULT_SCHEMA = 'gg438-correction-qa-result/v2';
export const SLOT = 4 * 1024 * 1024;
export const RECORD = 64 * 1024;
export const PENDING = 256 * 1024;
export const LOCK_NAMES = ['graphgoblin.lock', 'graphgoblin.db.graphgoblin.lock'];
export const CASES = ['s-source', 'c-f2-writer', 'c-f1-logger-err', 'c-f1-client-error',
  'n-f1-trace-launcher', 'n-f3-pipe-holder', 'n-f3-file-holder', 'n-f3-legacy-writer'];
export const HEX64 = /^[a-f0-9]{64}$/u;
export const PLACEHOLDER = '<ROOT-SUPPLIES';
export const fixturesDir = dirname(fileURLToPath(import.meta.url));
export const preparationDir = dirname(fixturesDir);
export const batchDir = dirname(preparationDir);

// Sealed, root-reviewed helper bytes reused unchanged (paths relative to the batch). Each digest is
// checked here and again against the admission before anything is imported.
export const REUSED = {
  'launcher-438-supplemental-qa-preparation/common.mjs': '3a8e52c0b306543b903c4806705ada9e6215b9a2e84dc285ce982e169b7a7373',
  'launcher-438-candidate-qa-preparation/native.mjs': '19bf2a8a953eea6538f6515704aaace45ed832773528cca53862440e20bde837',
  'launcher-438-candidate-qa-preparation/controls.mjs': '07b4670201aa225ed787fcfc549c4a6bc18f6498691317df66f212dff533b69e',
  'launcher-438-native-preparation-v3/workload.mjs': '4419c0577ac7c0bc2a2d94986ca018c8c162065e8e0036c3b86520ede17acb8d',
  'launcher-438-native-preparation-v3/windows.mjs': 'f9cfdf993c15f7e53db1caf6837b29b3073c533804623fa08c77c6f5e3a20cd5',
  // Static import of windows.mjs (path helper `under`).
  'launcher-438-native-preparation-v3/binding.mjs': 'd807d1f993f126684362f3764fd38987822ea793b0d735af47fb01beb38dd3fb',
  // Predecessor artifact readback for the candidate-only legacy-writer control.
  'runtime-410-build-preparation/artifacts.mjs': '479b4a723e12f7d11da926d99c83ced2ab9e26e5eedffc7dd74000c65a806226',
  // Static import of artifacts.mjs.
  'runtime-410-build-preparation/common.mjs': '54f0a901a702eb78de69a6f0df7f9293e358689cb9a7af1016f906317da03ae4',
};
// The frozen read-only control used only for `--cleanup-scan` (no-follow fixture inventory, known
// WinINet profile junction retention, TEMP witness). Never compiled or changed here.
export const HELPER = {
  executable: { rel: 'launcher-438-supplemental-qa-preparation/helper-frozen-02/LauncherLogControl.exe',
    sha256: 'aa182d0eaf5faf873dfd6516226abece7c7693dfe13ca665f4a827db70751e87' },
  compileReceipt: { rel: 'launcher-438-supplemental-qa-preparation/helper-frozen-02/receipt.json',
    sha256: '0b14cc5030f4d468c4eb1d82673a5d6be6099fe6ac07afb3802ac80f92a5e774' },
  source: { rel: 'launcher-438-supplemental-qa-preparation/LauncherLogControl.cs',
    sha256: '8b33a3d403efaff4e744a6aa33315521f395166b44b519d780e1349f4409cc2f' },
};
// Exact driver environment created by launch.ps1 and exact case environment from the reused
// supplemental openCase. Nothing ambient (HOME, provider credentials, proxies, NODE_OPTIONS, GG_*)
// can be present.
export const DRIVER_ENV = ['SYSTEMROOT', 'WINDIR', 'PATH', 'TEMP', 'TMP'];
export const CASE_ENV = ['SYSTEMROOT', 'WINDIR', 'PATH', 'TEMP', 'TMP', 'USERPROFILE', 'APPDATA', 'LOCALAPPDATA'];
const GATEWAY_KEYS = ['GG_HOST', 'GG_PORT', 'GG_DATA_DIR', 'GG_WEB_DIST', 'GG_LOG_LEVEL', 'GG_REQUIRE_API_KEY',
  'GG_OLLAMA_ENABLED', 'GG_SWAGGER_UI', 'GG_WINDOWS_LAUNCHER_LOG_DIR', 'QA438_RECEIPT_PATH', 'QA438_CANARIES_JSON'];

export const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex');
export const pretty = (value) => JSON.stringify(value, (_key, item) => (typeof item === 'bigint' ? item.toString() : item), 2) + '\n';
export const nonce = () => randomBytes(5).toString('hex');
export const sleep = (ms) => new Promise((done) => setTimeout(done, ms));
export const describe = (error) => (error instanceof Error
  ? { name: error.name, message: error.message, code: error.code, stack: error.stack?.split('\n').slice(0, 8).join('\n'),
    actual: error.actual, expected: error.expected }
  : { value: String(error) });
const lower = (value) => String(value).toLowerCase();

function unfilled(value, path = '$', found = []) {
  if (typeof value === 'string' && value.startsWith(PLACEHOLDER)) found.push(path);
  else if (Array.isArray(value)) value.forEach((item, index) => unfilled(item, `${path}[${index}]`, found));
  else if (value && typeof value === 'object') for (const [key, item] of Object.entries(value)) unfilled(item, `${path}.${key}`, found);
  return found;
}

async function boundBytes(path, digest, systemFile = false) {
  assert(isAbsolute(path) && HEX64.test(digest ?? ''), 'unbound input ' + path);
  assert.equal(lower(await realpath(path)), lower(resolve(path)), 'aliased input ' + path);
  const info = await lstat(path);
  assert(info.isFile() && !info.isSymbolicLink() && (systemFile || info.nlink === 1), 'not an ordinary file ' + path);
  const bytes = await readFile(path);
  assert.equal(sha256(bytes), digest, 'digest ' + path);
  return bytes;
}

/** Verify every reused helper by digest, then import. Refuses before any fixture exists. */
export async function loadReused() {
  for (const [rel, digest] of Object.entries(REUSED)) await boundBytes(join(batchDir, ...rel.split('/')), digest);
  const load = (rel) => import(pathToFileURL(join(batchDir, ...rel.split('/'))).href);
  return {
    sup: await load('launcher-438-supplemental-qa-preparation/common.mjs'),
    native: await load('launcher-438-candidate-qa-preparation/native.mjs'),
    controls: await load('launcher-438-candidate-qa-preparation/controls.mjs'),
    workload: await load('launcher-438-native-preparation-v3/workload.mjs'),
    windows: await load('launcher-438-native-preparation-v3/windows.mjs'),
    artifacts: await load('runtime-410-build-preparation/artifacts.mjs'),
  };
}

export function assertEnvKeys(env, allowed, label) {
  const keys = Object.keys(env).map((key) => key.toUpperCase());
  const outside = keys.filter((key) => !allowed.includes(key));
  assert.deepEqual(outside, [], label + ' environment outside the explicit allowlist');
  assert.equal(new Set(keys).size, keys.length, label + ' environment has duplicate spellings');
}

// ------------------------------------------------------------------ admission and bindings

/** Verify the root admission and every bound input, then create the single-use output and fixture dirs. */
export async function openRun(argv) {
  const [admissionPath, expected, ...extra] = argv;
  assert.deepEqual(extra, [], 'usage: driver.mjs <admission.json> <admission-sha256>');
  assert(admissionPath && HEX64.test(expected ?? ''), 'usage: driver.mjs <admission.json> <admission-sha256>');
  assert.equal(process.platform, 'win32');
  assert.equal(process.version, 'v22.23.4');
  assert.deepEqual(process.execArgv, [], 'no Node options');
  assertEnvKeys(process.env, DRIVER_ENV, 'driver');
  const lib = await loadReused();
  const bytes = await boundBytes(admissionPath, expected);
  assert(resolve(admissionPath).toLowerCase().startsWith(batchDir.toLowerCase() + sep), 'admission must be inside the batch');
  const admission = JSON.parse(bytes.toString('utf8'));
  assert.equal(admission.schema, ADMISSION_SCHEMA, 'admission schema');
  assert.equal(admission.state, 'root-admitted', 'admission state');
  assert(['baseline', 'candidate'].includes(admission.label), 'admission label');
  assert.deepEqual(unfilled(admission), [], 'unfilled admission fields');
  // The driver environment is exactly the launch.ps1 envelope: project Node + system PATH and a
  // driver TEMP inside the admitted, wrapper-created invocation directory.
  const systemRoot = process.env.SystemRoot;
  assert(isAbsolute(systemRoot ?? ''), 'SystemRoot');
  assert.equal(process.env.WINDIR, systemRoot);
  assert.equal(lower(await realpath(process.execPath)), lower(lib.sup.projectNode), 'driver node is the project runtime');
  assert.equal(lower(lib.sup.projectNode), lower(await realpath(admission.node.path)), 'admitted node path');
  await boundBytes(admission.node.path, admission.node.sha256);
  assert.equal(process.env.PATH, [dirname(lib.sup.projectNode), join(systemRoot, 'System32'), systemRoot].join(';'), 'driver PATH');
  assert.equal(lower(dirname(resolve(admission.invocationDir))), lower(batchDir), 'invocation directory is a direct batch child');
  assert.equal(lower(process.env.TEMP), lower(join(admission.invocationDir, 'driver-temp')), 'driver TEMP is the envelope directory');
  assert.equal(process.env.TMP, process.env.TEMP);
  // Read-only helpers: the reused native module runs this exact Windows PowerShell for CIM and ACL rows.
  assert.equal(lower(admission.systemPowerShell.path), lower(join(systemRoot, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe')));
  // Windows servicing can hardlink this exact system binary. Its path and digest remain bound.
  await boundBytes(admission.systemPowerShell.path, admission.systemPowerShell.sha256, true);
  // Packet, plan, contract and reused helpers.
  assert.equal(lower(resolve(admission.plan.path)), lower(join(preparationDir, 'plan.md')), 'plan is this packet');
  await boundBytes(admission.plan.path, admission.plan.sha256);
  await boundBytes(admission.contract.path, admission.contract.sha256);
  for (const [rel, digest] of Object.entries(admission.scripts)) await boundBytes(join(preparationDir, ...rel.split('/')), digest);
  for (const required of ['launch.ps1', 'fixtures/common.mjs', 'fixtures/driver.mjs']) assert(admission.scripts[required], 'script binding ' + required);
  assert.deepEqual(admission.reused, REUSED, 'reused helper digests changed');
  const helper = {};
  for (const [key, value] of Object.entries(HELPER)) {
    const path = join(batchDir, ...value.rel.split('/'));
    assert.equal(lower(resolve(admission.helper[key]?.path ?? '')), lower(path), 'helper path ' + key);
    assert.equal(admission.helper[key].sha256, value.sha256, 'helper digest ' + key);
    await boundBytes(path, value.sha256);
    helper[key] = { path, sha256: value.sha256 };
  }
  assert(Array.isArray(admission.cases) && admission.cases.length > 0, 'cases');
  for (const id of admission.cases) assert(CASES.includes(id), 'unknown case ' + id);
  assert.equal(new Set(admission.cases).size, admission.cases.length, 'duplicate case');
  assert(admission.label === 'candidate' || !admission.cases.includes('n-f3-legacy-writer'),
    'the legacy-writer control is admitted for the candidate only; baseline legacy evidence is historical');
  for (const key of ['runMs', 'caseMs', 'caseGraceMs', 'requests', 'malformed', 'launches', 'gateways']) {
    assert(Number.isSafeInteger(admission.caps[key]) && admission.caps[key] > 0, 'cap ' + key);
  }
  assert.deepEqual(admission.forbiddenPorts, [4747, 4748]);
  assert(typeof admission.rc3?.expectedInUseText === 'string' && admission.rc3.expectedInUseText.length > 0, 'rc3 expected text');
  assert(typeof admission.rc3?.expectedDocsBlock === 'string' && admission.rc3.expectedDocsBlock.length > 0, 'rc3 docs block');
  const build = await verifyBuild(admission.build);
  await boundBytes(admission.launcher.path, admission.launcher.sha256);
  await boundBytes(admission.git.path, admission.git.sha256);
  const git = gitReadback(lib, admission);
  const fullVerifier = admission.build.fullVerifierOpening;
  await boundBytes(fullVerifier.path, fullVerifier.sha256);
  let legacy = null;
  if (admission.cases.includes('n-f3-legacy-writer')) {
    const binding = JSON.parse((await boundBytes(admission.legacyWriter.baselineBinding.path, admission.legacyWriter.baselineBinding.sha256)).toString('utf8'));
    assert.deepEqual([binding.schema, binding.mode, binding.head, binding.tree],
      ['gg438-native-source-build/v1', 'baseline', admission.legacyWriter.head, admission.legacyWriter.tree], 'legacy writer binding');
    assert.equal(binding.launcher.sha256, admission.legacyWriter.launcherSha256, 'legacy writer launcher');
    assert.equal(lower(await realpath(binding.node.path)), lower(lib.sup.projectNode), 'legacy writer node');
    legacy = binding;
  }
  // Single use: an existing output, fixture or case directory means this admission was consumed.
  const outputDir = resolve(admission.outputDir);
  assert.equal(lower(dirname(outputDir)), lower(batchDir), 'output directory is a direct batch child');
  assert.notEqual(lower(outputDir), lower(resolve(admission.invocationDir)));
  const parent = await realpath(admission.privateFixtureParent.path);
  assert.equal(lower(parent), lower(resolve(admission.privateFixtureParent.path)), 'private parent alias');
  assert.equal(lower(dirname(resolve(admission.fixtureDir))), lower(parent), 'fixture dir must be a direct child of the private parent');
  await mkdir(outputDir);
  await mkdir(join(parent, basename(resolve(admission.fixtureDir))));
  // The canonical spelling from here on: the reused openCase compares realpaths exactly.
  const fixtureDir = await realpath(join(parent, basename(resolve(admission.fixtureDir))));
  assert.equal(lower(fixtureDir), lower(resolve(admission.fixtureDir)), 'fixture dir alias');
  await mkdir(join(fixtureDir, 'cases'));
  const driverEvidence = join(outputDir, 'driver-evidence');
  await mkdir(driverEvidence);
  const records = [];
  const native = lib.native.createNative(driverEvidence, records);
  const parentAcl = await lib.controls.privateRootReadback(native, parent);
  assert.equal(parentAcl.owner, admission.privateFixtureParent.ownerSid, 'private parent owner');
  assert.equal(parentAcl.sddl, admission.privateFixtureParent.sddl, 'private fixture parent SDDL');
  assert(/D:P/u.test(parentAcl.sddl), 'private parent DACL is protected');
  const fixtureAcl = await lib.controls.privateRootReadback(native, fixtureDir);
  // Shim with exactly the fields the reused supplemental openCase reads. No supplemental admission,
  // runner or invoker is used.
  const job = { moduleDir: fixtureDir, ports: new Set(), helper: { executable: helper.executable },
    binding: { checkout: build.checkout }, lib: { native: lib.native, controls: lib.controls, workload: lib.workload, windows: lib.windows } };
  const session = {
    admission, admissionPath: resolve(admissionPath), admissionSha256: expected, lib, job, build, git, legacy, native, records,
    outputDir, fixtureDir, node: lib.sup.projectNode, launcher: admission.launcher.path, checkout: build.checkout,
    caps: admission.caps, counters: { launches: 0, gateways: 0, requests: 0, malformed: 0 },
  };
  await lib.sup.save(join(outputDir, 'opening.json'), {
    schema: RESULT_SCHEMA, at: new Date().toISOString(), label: admission.label, runId: admission.runId,
    admission: { path: session.admissionPath, sha256: expected }, build, git, parentAcl, fixtureAcl, pid: process.pid,
    driverEnvironmentKeys: Object.keys(process.env).sort(), reused: REUSED, helper,
    fullBindingNote: 'Selected-file digests only. The full build binding is root\'s accepted publication/build verifier, run before and after this execution.',
  });
  return session;
}

/** Selected built/source digests, cross-checked against the root-supplied full binding maps. */
export async function verifyBuild(build) {
  const checkout = await realpath(build.checkout);
  assert.equal(lower(checkout), lower(resolve(build.checkout)), 'checkout alias');
  const full = JSON.parse((await boundBytes(build.fullBinding.path, build.fullBinding.sha256)).toString('utf8'));
  const sourceBinding = build.sourceBinding
    ? JSON.parse((await boundBytes(build.sourceBinding.path, build.sourceBinding.sha256)).toString('utf8')) : full;
  const outputs = full.artifacts?.outputFiles;
  const sources = sourceBinding.sourceFiles;
  assert(outputs && typeof outputs === 'object', 'full binding has artifacts.outputFiles');
  assert(sources && typeof sources === 'object', 'source binding has a sourceFiles map');
  const files = {};
  for (const [group, map] of [['distFiles', outputs], ['sourceFiles', sources]]) {
    for (const [rel, digest] of Object.entries(build[group] ?? {})) {
      const actual = sha256(await readFile(join(checkout, ...rel.split('/'))));
      assert.equal(actual, digest, group + ' ' + rel);
      assert.equal(map[rel], digest, group + ' ' + rel + ' differs from the bound full map');
      files[rel] = actual;
    }
  }
  assert(files['apps/api/dist/instance-identity.js'], 'expected-identity helper is bound');
  const apiRequire = createRequire(join(checkout, 'apps', 'api', 'package.json'));
  const pinoRequire = createRequire(apiRequire.resolve('pino/package.json'));
  const versions = {
    fastify: JSON.parse(await readFile(apiRequire.resolve('fastify/package.json'), 'utf8')).version,
    pino: JSON.parse(await readFile(apiRequire.resolve('pino/package.json'), 'utf8')).version,
    'pino-std-serializers': JSON.parse(await readFile(pinoRequire.resolve('pino-std-serializers/package.json'), 'utf8')).version,
  };
  assert.deepEqual(versions, build.dependencyVersions, 'dependency versions');
  return { checkout, head: build.head, tree: build.tree, files, versions, fullBinding: build.fullBinding,
    sourceBinding: build.sourceBinding ?? null, scope: 'selected files only' };
}

/** Strict clean Git readback through the reused helper: no untracked or modified file, exact head/tree/index. */
export function gitReadback(lib, admission) {
  const read = lib.sup.gitReadback({ git: admission.git, checkout: admission.build.checkout });
  assert.equal(read.status, '', 'checkout is not clean (porcelain v1, untracked=all)');
  assert.deepEqual([read.head, read.tree], [admission.build.head, admission.build.tree], 'git head/tree');
  return { head: read.head, tree: read.tree, index: read.index, clean: true };
}

export async function closingReadback(session) {
  const { admission, lib } = session;
  const build = await verifyBuild(admission.build);
  await boundBytes(admission.launcher.path, admission.launcher.sha256);
  const git = gitReadback(lib, admission);
  return { build, git };
}

// ------------------------------------------------------------------ loopback and HTTP

export function counted(session, key) {
  session.counters[key]++;
  assert(session.counters[key] <= session.caps[key], key + ' cap exceeded');
}

/** One bounded request through the reused workload helper (5 s abort, ports 4747/4748 refused). */
export async function http(session, port, path, options) {
  counted(session, 'requests');
  const response = await session.lib.workload.request(port, path, options);
  const text = await response.text();
  return { status: response.status, headers: Object.fromEntries(response.headers), text };
}

export async function health(session, port, path) {
  counted(session, 'requests');
  return session.lib.workload.healthy(port, path);
}

/**
 * Send raw bytes on one loopback connection (chunks separated by `gapMs`) and record the reply.
 * Bounded by `timeoutMs`; used for malformed HTTP only.
 */
export function rawExchange(session, port, chunks, { gapMs = 150, timeoutMs = 5000 } = {}) {
  counted(session, 'malformed');
  assert(![4747, 4748].includes(port));
  return new Promise((done) => {
    const socket = net.connect({ host: '127.0.0.1', port });
    const parts = [];
    const started = Date.now();
    let finished = false;
    const finish = (reason) => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      socket.destroy();
      const reply = Buffer.concat(parts);
      const text = reply.toString('latin1');
      done({ reason, ms: Date.now() - started, replyBytes: reply.length, replySha256: sha256(reply),
        statusLine: text.split('\r\n')[0] ?? '', status: Number(/^HTTP\/1\.1 (\d{3})/u.exec(text)?.[1] ?? 0),
        fastifyClientErrorBody: text.includes('"message":"Client Error"') || text.includes('"message":"Exceeded maximum allowed HTTP header size"'),
        replyHead: text.slice(0, 400) });
    };
    const timer = setTimeout(() => finish('timeout'), timeoutMs);
    socket.on('data', (chunk) => parts.push(chunk));
    socket.on('end', () => finish('end'));
    socket.on('close', () => finish('close'));
    socket.on('error', (error) => finish('error:' + error.code));
    socket.on('connect', async () => {
      for (let index = 0; index < chunks.length; index++) {
        if (index > 0) await sleep(gapMs);
        if (socket.destroyed) return;
        socket.write(chunks[index]);
      }
    });
  });
}

// ------------------------------------------------------------------ cases

/**
 * Open one case through the reused supplemental openCase: owned case/evidence/fixture directories,
 * per-case V4 process receipts, the established clean environment (system + project Node PATH,
 * fixture TEMP/TMP/USERPROFILE/APPDATA/LOCALAPPDATA; no HOME or ambient value) and the qualified
 * cleanup readback. The returned ctx gains `qa` for ownership state.
 */
export async function openCase(session, id) {
  const ctx = await session.lib.sup.openCase(session.job, id);
  assertEnvKeys(ctx.env, CASE_ENV, 'case');
  ctx.qa = { session, id, owned: [], pending: [], labels: new Set() };
  await ctx.put('case-environment.json', { keys: Object.keys(ctx.env).sort(), env: ctx.env });
  return ctx;
}

/** Gateway environment as the launcher composes it plus declared fixture values; checked against the allowlist. */
export function gatewayEnv(ctx, config, extra = {}) {
  const env = ctx.gatewayEnv(config, extra);
  assertEnvKeys(env, [...CASE_ENV, ...GATEWAY_KEYS], 'gateway');
  return env;
}

export function argvOf(commandLine) {
  return [...String(commandLine ?? '').matchAll(/"([^"]*)"|([^"\s]+)/gu)].map((match) => match[1] ?? match[2]);
}

export async function lockNamesPresent(store) {
  const present = [];
  for (const name of LOCK_NAMES) {
    for (const suffix of ['', '.reclaim']) {
      try { await lstat(join(store, name + suffix)); present.push(name + suffix); } catch (error) {
        if (error.code !== 'ENOENT') throw error;
      }
    }
  }
  return present;
}

async function verifyIdentityHelper(ctx, repo) {
  const { session } = ctx.qa;
  const rel = 'apps/api/dist/instance-identity.js';
  const file = join(repo, ...rel.split('/'));
  const expected = lower(repo) === lower(session.checkout) ? session.build.files[rel] : session.legacy?.artifacts.outputFiles[rel];
  assert(HEX64.test(expected ?? ''), 'instance-identity.js is not admitted for ' + repo);
  assert.equal(sha256(await readFile(file)), expected, 'instance-identity.js digest for ' + repo);
}

/** Expected identity from the admitted instance-identity.js with the exact isolated gateway environment. */
export async function expectedIdentity(ctx, repo, env, label) {
  await verifyIdentityHelper(ctx, repo);
  return ctx.fingerprint(repo, env, label);
}

/**
 * Full ownership proof (supplemental proof approach): health identity equals the precomputed
 * expected identity and phase is running; the Win32 row has the admitted Node executable and the
 * exact full argv; the parent is the recorded launcher PID, or the row is the exact direct child of
 * this driver; both store leases name the PID and the raw Windows creation time (same CIM
 * CreationDate.ToFileTimeUtc() expression the product writes), with their digests.
 */
export async function prove(ctx, current) {
  const { session } = ctx.qa;
  const observed = await health(session, current.port);
  assert.equal(observed.identity, current.expected, 'health identity differs from the precomputed expected identity');
  assert.equal(observed.phase, 'running', 'gateway phase');
  const proc = await ctx.native.cim(observed.pid);
  assert.equal(proc.pid, observed.pid, 'Win32 row for the serving PID');
  const owner = ctx.records.find((row) => row.label === current.nativeLabel);
  assert(Number.isSafeInteger(owner?.pid), 'recorded launcher or direct child PID');
  if (current.direct) {
    assert.equal(proc.pid, owner.pid, 'serving PID is the exact direct child');
    assert.equal(proc.parentPid, process.pid, 'direct child parent is this driver');
  } else {
    assert.notEqual(proc.pid, owner.pid);
    assert.equal(proc.parentPid, owner.pid, 'gateway parent is the recorded launcher PID');
  }
  assert.equal(lower(await realpath(proc.executable)), lower(current.node), 'gateway executable');
  const argv = argvOf(proc.commandLine);
  assert.equal(argv.length, current.argv.length + 1, 'full argv length');
  assert.equal(lower(await realpath(argv[0])), lower(current.node), 'argv[0]');
  for (let index = 0; index < current.argv.length; index++) {
    const want = current.argv[index];
    if (typeof want === 'string') assert.equal(argv[index + 1], want, 'argv[' + (index + 1) + ']');
    else assert.equal(lower(await realpath(argv[index + 1])), lower(want.path), 'argv[' + (index + 1) + '] path');
  }
  const leases = [];
  for (const name of LOCK_NAMES) {
    const file = join(current.store, name);
    const raw = await readFile(file);
    const lease = JSON.parse(raw.toString('utf8'));
    assert.equal(lease.pid, observed.pid, name + ' lease PID');
    assert.equal(lease.windowsCreationTime, proc.creationFileTime, name + ' lease raw Windows creation time');
    leases.push({ name, path: file, sha256: sha256(raw), pid: lease.pid, windowsCreationTime: lease.windowsCreationTime });
  }
  return { health: observed, proc, leases };
}

function register(ctx, current) {
  assert(/^[a-z0-9][a-z0-9-]*$/u.test(current.label) && !ctx.qa.labels.has(current.label), 'label ' + current.label);
  ctx.qa.labels.add(current.label);
  ctx.qa.pending.push(current);
}

function promote(ctx, current) {
  // Only a fully proven incarnation becomes a drain target.
  ctx.qa.pending.splice(ctx.qa.pending.indexOf(current), 1);
  ctx.qa.owned.push(current);
}

/** Counted launcher call through the reused ctx.launch (V4 receipts, EOF checks; never signalled). */
export async function launch(ctx, label, launcherPath, configPath, { expect, cwd, timeout } = {}) {
  counted(ctx.qa.session, 'launches');
  return ctx.launch(label, launcherPath, ['--config', configPath, '--ensure-gateway'], { expect, cwd, timeout });
}

/** Launch through a launcher, then bind the exact serving gateway before registering it for drain. */
export async function bootLauncher(ctx, label, launcherPath, configPath, config, { cwd, entry } = {}) {
  const { session } = ctx.qa;
  const env = gatewayEnv(ctx, config);
  const current = { label, nativeLabel: label, direct: false, port: config.Port, store: config.DataDir, node: session.node,
    argv: [{ path: entry ?? await realpath(join(config.Repo, 'apps', 'api', 'dist', 'main.js')) }] };
  current.expected = await expectedIdentity(ctx, config.Repo, env, label);
  register(ctx, current);
  counted(session, 'gateways');
  const call = await launch(ctx, label, launcherPath, configPath, { expect: 0, cwd: cwd ?? config.Repo });
  current.launcher = { pid: call.pid, exit: call.exit };
  current.proof = await prove(ctx, current);
  promote(ctx, current);
  await ctx.put(label + '-gateway.json', { expected: current.expected, launcherPid: call.pid, argv: current.argv, proof: current.proof });
  return current;
}

/**
 * Start a direct gateway child through the reused V4 run (receipts, bounded raw streams, never
 * signalled), then prove it before registering it for drain. `argv` excludes the Node executable;
 * path elements are `{ path }`.
 */
export async function serveDirect(ctx, label, argv, env, { port, store, cwd, timeout }) {
  const { session } = ctx.qa;
  assertEnvKeys(env, [...CASE_ENV, ...GATEWAY_KEYS], 'direct gateway');
  const current = { label, nativeLabel: label, direct: true, port, store, node: session.node, argv };
  current.expected = await expectedIdentity(ctx, session.checkout, env, label);
  register(ctx, current);
  counted(session, 'gateways');
  const args = argv.map((item) => (typeof item === 'string' ? item : item.path));
  current.closed = ctx.native.run(label, session.node, args, cwd ?? session.checkout, { childEnv: env, timeout })
    .then((call) => ({ call }), (error) => ({ error }));
  await session.lib.native.observe(label + ' running health', async () => {
    const record = ctx.records.find((row) => row.label === label);
    if (record?.close) throw new Error(label + ' exited before readiness');
    try { return (await health(session, port)).phase === 'running'; } catch (error) {
      if (/cap exceeded/u.test(error.message)) throw error;
      return false;
    }
  }, 45_000);
  current.proof = await prove(ctx, current);
  promote(ctx, current);
  await ctx.put(label + '-gateway.json', { expected: current.expected, directPid: current.proof.health.pid, argv, proof: current.proof });
  return current;
}

/** Drain an exact owned gateway by its own API; never signal it. */
export async function drainOwned(ctx, current) {
  if (current.stopped) return current.stopped;
  const { session } = ctx.qa;
  const { observe, refused } = session.lib.native;
  const { proof } = current;
  assert(proof && ctx.qa.owned.includes(current), 'drain target was never fully proven');
  assert.deepEqual(await prove(ctx, current), proof, 'ownership changed before the shutdown-token GET');
  const state = await http(session, current.port, '/system/shutdown');
  assert.equal(state.status, 200, state.text.slice(0, 300));
  const { controlToken } = JSON.parse(state.text);
  assert(typeof controlToken === 'string' && controlToken.length > 0, 'control token');
  assert.deepEqual(await prove(ctx, current), proof, 'ownership changed before the drain POST');
  const posted = await http(session, current.port, '/system/shutdown', { method: 'POST',
    headers: { 'content-type': 'application/json', 'x-graphgoblin-shutdown-token': controlToken }, body: '{"action":"drain"}' });
  assert.equal(posted.status, 202, posted.text.slice(0, 300));
  await observe('exact gateway listener closed', () => refused(current.port), 25_000);
  const after = await observe('exact gateway birth absent', async () => {
    const row = await ctx.native.cim(proof.health.pid);
    return row.creationFileTime !== proof.proc.creationFileTime ? row : false;
  }, 15_000);
  assert.deepEqual(await lockNamesPresent(current.store), [], 'lease or reclaim name remains after drain');
  let exit = null;
  if (current.direct) {
    const ended = await session.lib.native.bounded(current.label + ' close receipt', current.closed, 30_000);
    if (ended.error) throw ended.error;
    const { call } = ended;
    assert.equal(call.exit.code, 0, current.label + ' exit after drain');
    assert.equal(call.stdoutEnd?.bytes, call.stdoutBytes, current.label + ' stdout EOF');
    assert.equal(call.stderrEnd?.bytes, call.stderrBytes, current.label + ' stderr EOF');
    exit = { exit: call.exit, close: call.close, stdoutBytes: call.stdoutBytes, stderrBytes: call.stderrBytes };
  }
  current.stopped = { label: current.label, pid: proof.health.pid, birth: proof.proc.creationFileTime, after, exit,
    listenerRefused: true, leasesAbsent: true };
  await ctx.put(current.label + '-drained.json', current.stopped);
  return current.stopped;
}

/**
 * Finite holder through the reused supplemental hold (release marker in finally, exact holder
 * close awaited, exit 0 and birth absence), plus explicit exit/close/stdout/stderr EOF readback.
 * The caller starts nothing positive until this returns.
 */
export async function holdExact(ctx, spec, work) {
  const result = await ctx.hold(spec, work);
  const row = ctx.holders.find((item) => item.spec === spec);
  const record = ctx.records.find((item) => item.label === 'holder ' + spec.name);
  assert(row && record, 'holder receipt');
  assert(record.exit && record.close, 'holder exit and close');
  assert.deepEqual(record.exit, record.close, 'holder exit equals close');
  assert.equal(record.exit.code, 0, 'holder exit code');
  assert.equal(record.stdoutEnd?.bytes, record.stdoutBytes, 'holder stdout EOF');
  assert.equal(record.stderrEnd?.bytes, record.stderrBytes, 'holder stderr EOF');
  assert.equal(row.goneAfterRelease, true, 'holder raw birth absent after release');
  return { result, holder: { pid: row.pid, birth: row.identity?.creationFileTime, exit: record.exit, close: record.close,
    stdoutBytes: record.stdoutBytes, stderrBytes: record.stderrBytes, eof: true, goneAfterRelease: true } };
}

/**
 * Close one case after its body has settled (the driver never runs this beside a live body).
 * Owned gateways drain by API; unproven launches are never signalled and are retained unless
 * port, leases and receipts prove nothing remains; then the reused qualified cleanup readback
 * (ports, every process exit/close, launcher-child census, exclusive DB/WAL/SHM handles, no-follow
 * fixture inventory with the known WinINet junction retention and the TEMP witness).
 */
export async function closeCase(ctx) {
  const { session } = ctx.qa;
  const report = { drained: [], unproven: [], storeLocks: [], errors: [] };
  for (const current of ctx.qa.owned) {
    try { report.drained.push(await drainOwned(ctx, current)); } catch (error) {
      report.errors.push({ step: 'drain', retained: true, label: current.label, pid: current.proof?.health.pid,
        birth: current.proof?.proc.creationFileTime, port: current.port, store: current.store, ...describe(error) });
    }
  }
  for (const current of ctx.qa.pending) {
    const record = ctx.records.find((row) => row.label === current.nativeLabel);
    let portFree = false;
    try { portFree = await session.lib.native.refused(current.port); } catch { portFree = false; }
    let locks;
    try { locks = await lockNamesPresent(current.store); } catch (error) { locks = ['unreadable: ' + error.code]; }
    const closed = Boolean(record?.exit && record?.close);
    const row = { label: current.label, pid: record?.pid ?? null, port: current.port, store: current.store, portFree, locks, closed };
    report.unproven.push(row);
    if (!portFree || locks.length > 0 || (current.direct && !closed)) report.errors.push({ step: 'unproven', retained: true, ...row });
  }
  for (const store of ctx.stores) {
    try {
      const locks = await lockNamesPresent(store);
      report.storeLocks.push({ store, locks });
      if (locks.length) report.errors.push({ step: 'store-lock', retained: true, store, locks });
    } catch (error) { report.errors.push({ step: 'store-lock', store, ...describe(error) }); }
  }
  if (report.errors.length === 0) {
    try {
      const qualified = await ctx.cleanup();
      report.qualified = qualified;
      for (const error of qualified.errors) report.errors.push({ ...error, step: 'qualified:' + error.step });
    } catch (error) { report.errors.push({ step: 'qualified-cleanup', ...describe(error) }); }
  } else {
    report.qualified = 'not run: an owned or unproven process is retained for root';
  }
  report.retainedFixture = ctx.fixture;
  report.complete = report.errors.length === 0;
  return report;
}

// ------------------------------------------------------------------ records and canaries

export async function slotState(root, names = ['gateway.log', 'gateway.log.1']) {
  const state = {};
  for (const name of names) {
    const path = join(root, name);
    try {
      const info = await lstat(path, { bigint: true });
      assert(info.isFile() && !info.isSymbolicLink(), 'managed name is not an ordinary file: ' + name);
      const bytes = await readFile(path);
      state[name] = { exists: true, size: Number(info.size), id: info.dev + ':' + info.ino, nlink: Number(info.nlink), sha256: sha256(bytes), bytes };
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
      state[name] = { exists: false };
    }
  }
  return state;
}

export const withoutBytes = (state) => Object.fromEntries(Object.entries(state).map(([name, value]) => {
  const { bytes, ...rest } = value;
  void bytes;
  return [name, rest];
}));

/** Complete LF-terminated lines; fatal UTF-8; JSON per line; nothing is sliced or repaired. */
export function parseRecords(bytes) {
  const rows = [];
  let offset = 0;
  const decoder = new TextDecoder('utf-8', { fatal: true });
  while (offset < bytes.length) {
    const end = bytes.indexOf(10, offset);
    if (end < 0) { rows.push({ offset, length: bytes.length - offset, incomplete: true }); break; }
    const line = bytes.subarray(offset, end + 1);
    let value;
    let error;
    try { value = JSON.parse(decoder.decode(line)); } catch (caught) { error = caught.message; }
    rows.push({ offset, length: line.length, value, error });
    offset = end + 1;
  }
  return rows;
}

/** Every encoding of an ASCII canary that a JSON log line could carry. */
export function canaryForms(value) {
  const bytes = Buffer.from(value, 'utf8');
  const forms = new Set([value, bytes.toString('hex'), bytes.toString('hex').toUpperCase(), [...bytes].join(','),
    [...bytes].join(', '), Buffer.from(value, 'utf16le').toString('latin1')]);
  for (let shift = 0; shift < 3; shift++) {
    const encoded = Buffer.concat([Buffer.alloc(shift), bytes]).toString('base64');
    const stable = encoded.slice(Math.ceil((4 * shift) / 3), Math.floor((4 * (shift + bytes.length)) / 3));
    if (stable.length >= 8) { forms.add(stable); forms.add(stable.replaceAll('+', '-').replaceAll('/', '_')); }
  }
  return [...forms];
}

function decodedArrays(value, found = []) {
  if (Array.isArray(value)) {
    if (value.length >= 4 && value.every((item) => Number.isInteger(item) && item >= 0 && item <= 255)) found.push(Buffer.from(value));
    else for (const item of value) decodedArrays(item, found);
  } else if (value && typeof value === 'object') {
    const keys = Object.keys(value);
    if (keys.length >= 4 && keys.every((key, index) => key === String(index)) &&
      keys.every((key) => Number.isInteger(value[key]) && value[key] >= 0 && value[key] <= 255)) {
      found.push(Buffer.from(keys.map((key) => value[key])));
    } else for (const item of Object.values(value)) decodedArrays(item, found);
  }
  return found;
}

/**
 * Scan raw slot bytes and every parsed record for each canary in every listed encoding, including
 * byte arrays such as Pino's `{"type":"Buffer","data":[...]}` rendering of a Node Buffer.
 */
export function scanCanaries(files, canaries) {
  const hits = [];
  const add = (hit) => { if (hits.length < 200) hits.push(hit); };
  for (const [file, bytes] of Object.entries(files)) {
    if (!bytes) continue;
    const latin = bytes.toString('latin1');
    const lowered = latin.toLowerCase();
    for (const [name, value] of Object.entries(canaries)) {
      for (const form of canaryForms(value)) {
        const haystack = form === value ? lowered : latin;
        const index = haystack.indexOf(form === value ? form.toLowerCase() : form);
        if (index >= 0) add({ file, canary: name, form: form === value ? 'raw' : 'encoded', offset: index });
      }
    }
    for (const row of parseRecords(bytes)) {
      if (!row.value) continue;
      for (const array of decodedArrays(row.value)) {
        for (const [name, value] of Object.entries(canaries)) {
          if (array.toString('latin1').toLowerCase().includes(value.toLowerCase())) add({ file, canary: name, form: 'byte-array', offset: row.offset, msg: row.value.msg });
        }
      }
      const text = JSON.stringify(row.value).toLowerCase();
      for (const [name, value] of Object.entries(canaries)) {
        if (text.includes(value.toLowerCase())) add({ file, canary: name, form: 'record-json', offset: row.offset, msg: row.value.msg });
      }
    }
  }
  return hits;
}

export async function launcherRecords(root) {
  const records = [];
  for (const name of ['launcher.log.1', 'launcher.log']) {
    let bytes;
    try { bytes = await readFile(join(root, name)); } catch (error) { if (error.code === 'ENOENT') continue; throw error; }
    for (const row of parseRecords(bytes)) records.push({ file: name, ...row });
  }
  return records;
}

export async function entries(path) {
  return (await readdir(path)).sort();
}
