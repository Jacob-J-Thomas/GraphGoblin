// #438 correction QA driver (preparation 02). One root-admitted, single-use execution of the
// admitted cases, serially, one gateway at a time. Run only through ../launch.ps1, which supplies
// the explicit environment allowlist and the outer timing/stream receipts:
//   node driver.mjs <admission.json> <admission-sha256>
// It never rebuilds, edits a checkout, deletes, changes permissions, signals a gateway or launcher
// or touches ports 4747/4748. A case body always settles before its cleanup starts; at the hard
// deadline the driver writes the exact retained ownership and exits without running cleanup beside
// a live body. Predicate values are observations; acceptance belongs to root and the reviewers.
import { isDeepStrictEqual } from 'node:util';
import { writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { closeCase, closingReadback, describe, openCase, openRun, pretty, RESULT_SCHEMA } from './common.mjs';

const MODULES = {
  's-source': ['./s-source.mjs', 'run'],
  'c-f2-writer': ['./f2-writer-retention.mjs', 'run'],
  'c-f1-logger-err': ['./f1-client-error.mjs', 'runLoggerErr'],
  'c-f1-client-error': ['./f1-client-error.mjs', 'runClientError'],
  'n-f1-trace-launcher': ['./f1-client-error.mjs', 'runTraceLauncher'],
  'n-f3-pipe-holder': ['./f3-in-use-guidance.mjs', 'runPipe'],
  'n-f3-file-holder': ['./f3-in-use-guidance.mjs', 'runFile'],
  'n-f3-legacy-writer': ['./f3-in-use-guidance.mjs', 'runLegacyWriter'],
};

/** Exact retained ownership at the hard deadline; synchronous, then the process stops. */
function hardStop(session, ctx, id) {
  const snapshot = {
    schema: RESULT_SCHEMA, status: 'hard-deadline-retained', case: id, at: new Date().toISOString(), driverPid: process.pid,
    note: 'The case body did not settle within caseMs + caseGraceMs. No cleanup ran beside it. Every listed process is retained for root.',
    owned: ctx.qa.owned.map((g) => ({ label: g.label, port: g.port, store: g.store, pid: g.proof?.health.pid,
      birth: g.proof?.proc.creationFileTime, stopped: Boolean(g.stopped) })),
    unproven: ctx.qa.pending.map((g) => ({ label: g.label, port: g.port, store: g.store })),
    processes: ctx.records.map((r) => ({ label: r.label, pid: r.pid, exit: r.exit ?? null, close: r.close ?? null, timeout: r.timeout ?? null })),
    holders: ctx.holders.map((h) => ({ label: h.label, pid: h.pid, birth: h.identity?.creationFileTime, exit: h.exit ?? null })),
    fixture: ctx.fixture, evidence: ctx.evidence, counters: session.counters,
  };
  try { writeFileSync(join(session.outputDir, 'hard-deadline-' + id + '.json'), pretty(snapshot), { flag: 'wx' }); } catch { /* stdout below */ }
  process.stdout.write(JSON.stringify({ status: 'hard-deadline-retained', case: id, output: session.outputDir }) + '\n');
  process.exit(3);
}

async function main() {
  let session;
  try {
    session = await openRun(process.argv.slice(2));
  } catch (error) {
    process.stdout.write(JSON.stringify({ schema: RESULT_SCHEMA, status: 'binding-refused', error: describe(error) }) + '\n');
    return 2;
  }
  const { admission } = session;
  const startedAt = new Date().toISOString();
  const started = performance.now();
  const results = [];
  let stopped = null;
  for (const id of admission.cases) {
    if (performance.now() - started > admission.caps.runMs) { stopped = 'run-time-cap'; break; }
    const ctx = await openCase(session, id);
    const [file, name] = MODULES[id];
    const caseStartedAt = new Date().toISOString();
    const watchdog = setTimeout(() => hardStop(session, ctx, id), admission.caps.caseMs + admission.caps.caseGraceMs);
    const bodyStart = performance.now();
    let outcome;
    try {
      const module = await import(file);
      outcome = await module[name](ctx);
    } catch (error) {
      outcome = { status: 'error', error: describe(error) };
    }
    const bodyMs = Math.round(performance.now() - bodyStart);
    // The body has settled: every inner operation was bounded and awaited. Only now clean up.
    const cleanup = await closeCase(ctx).catch((error) => ({ complete: false, errors: [{ step: 'close-case', ...describe(error) }] }));
    clearTimeout(watchdog);
    const overCap = bodyMs > admission.caps.caseMs;
    const row = { schema: RESULT_SCHEMA, id, label: admission.label, runId: admission.runId, startedAt: caseStartedAt,
      endedAt: new Date().toISOString(), bodyMs, status: overCap ? 'case-time-cap' : outcome.status ?? 'observed',
      tier: outcome.tier ?? null, predicates: outcome.predicates ?? {}, error: outcome.error ?? null, cleanup,
      counters: { ...session.counters }, evidence: ctx.evidence, fixture: ctx.fixture };
    await ctx.put('case-result.json', row);
    results.push({ id, status: row.status, cleanupComplete: cleanup.complete, evidence: ctx.evidence,
      predicates: Object.fromEntries(Object.entries(row.predicates).map(([key, value]) => [key, value.status])) });
    if (overCap) { stopped = 'case-time-cap:' + id; break; }
    if (!cleanup.complete) { stopped = 'cleanup-incomplete:' + id; break; }
  }
  let closing;
  try { closing = await closingReadback(session); } catch (error) { closing = { error: describe(error) }; }
  const closingMatchesOpening = !closing.error && isDeepStrictEqual(closing.build, session.build) &&
    isDeepStrictEqual({ head: closing.git.head, tree: closing.git.tree, clean: closing.git.clean },
      { head: session.git.head, tree: session.git.tree, clean: session.git.clean });
  const status = !closingMatchesOpening ? 'binding-mismatch' : stopped ? 'stopped' : 'complete';
  const summary = { schema: RESULT_SCHEMA, status, label: admission.label, runId: admission.runId, admissionSha256: session.admissionSha256,
    startedAt, endedAt: new Date().toISOString(), stopped, results,
    remaining: admission.cases.filter((id) => !results.some((row) => row.id === id)), counters: session.counters,
    closingMatchesOpening, closing,
    rootClosingStep: 'Run the accepted full publication/build verifier again now; this driver checked selected files only.' };
  writeFileSync(join(session.outputDir, 'summary.json'), pretty(summary), { flag: 'wx' });
  process.stdout.write(JSON.stringify({ status, stopped, output: session.outputDir }) + '\n');
  return status === 'complete' ? 0 : status === 'stopped' ? 3 : 4;
}

main().then((code) => process.exit(code), (error) => {
  process.stdout.write(JSON.stringify({ status: 'driver-error', error: describe(error) }) + '\n');
  process.exit(1);
});
