// #438 F1 (RC1): a reached malformed-HTTP parser event under supported managed GG_LOG_LEVEL=trace.
// Pinned Fastify 5.12.5's default clientErrorHandler logs `{ err }` at trace (fastify.js 963-1000);
// Pino's default err serializer copies enumerable error fields, including Node's `rawPacket`.
// Cases:
//   c-f1-logger-err      controlled: the built production logger + writer keep engine error
//                        name/message/stack; a parser-shaped err is an informational locus probe.
//   c-f1-client-error    controlled: the actual built guarded entry (managed, trace) started as the
//                        exact direct child `node --import <read-only receipt preload> <main.js>`,
//                        proven by its full argv before it can be drained; real raw socket stimuli.
//   n-f1-trace-launcher  native: the admitted launcher starts the gateway with GG_LOG_LEVEL=trace;
//                        same stimuli, #381 private diagnostic, access projection, rotation smoke.
// Every canary is synthetic. Every child gets the clean case environment plus declared values only.
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { readFile, stat, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import {
  bootLauncher, drainOwned, gatewayEnv, health, http, nonce, parseRecords, rawExchange, scanCanaries, serveDirect, sha256,
  sleep, SLOT, slotState, withoutBytes,
} from './common.mjs';

export function makeCanaries(n) {
  const c = (tag) => `qa438${tag}${n}`;
  return {
    p1Path: c('p1seg'), p1Query: c('p1qry'), p1Header: c('p1hdr'), p1HeaderName: 'x-' + c('p1name'), p1Auth: c('p1auth'), p1Body: c('p1body'),
    p2Query: c('p2qry'), p2Header: c('p2hdr'), p2Body: c('p2body'),
    vQuery: c('vqry'), vHeader: c('vhdr'), vSegment: c('vseg'), vBody: c('vbody'), vJson: c('vjson'),
  };
}

/** P1: one write; an invalid header token after URL, query, header and auth canaries; body bytes follow. */
export function malformedP1(port, c) {
  const body = Buffer.from(`{"qa438":"${c.p1Body}"}`, 'latin1');
  const head = [`GET /${c.p1Path}?k=${c.p1Query} HTTP/1.1`, `Host: 127.0.0.1:${port}`, `X-QA438: ${c.p1Header}`,
    `${c.p1HeaderName}: 1`, `Authorization: Bearer ${c.p1Auth}`, `Content-Length: ${body.length}`].join('\r\n') + '\r\n';
  return [Buffer.concat([Buffer.from(head, 'latin1'), Buffer.from('X-Bad\u0001Token: 1\r\n\r\n', 'latin1'), body])];
}

/** P2: valid headers for a registered JSON route, then (separately) an invalid chunk size carrying the body canary. */
export function malformedP2(port, c) {
  const head = [`POST /loops?k=${c.p2Query} HTTP/1.1`, `Host: 127.0.0.1:${port}`, 'Content-Type: application/json',
    'Transfer-Encoding: chunked', `X-QA438: ${c.p2Header}`].join('\r\n') + '\r\n\r\n';
  return [Buffer.from(head, 'latin1'), Buffer.from(`zz${c.p2Body}\r\n{"a":1}\r\n0\r\n\r\n`, 'latin1')];
}

const group = (canaries, prefix) => Object.fromEntries(Object.entries(canaries).filter(([key]) => key.startsWith(prefix)));

async function stimuli(session, port, c) {
  const rows = [];
  const echo = (text) => Object.keys(c).filter((key) => text.includes(c[key]));
  let response = await http(session, port, `/healthz?k=${c.vQuery}`, { headers: { 'x-qa438': c.vHeader } });
  rows.push({ name: 'v1-healthz', status: response.status, echoed: echo(response.text) });
  response = await http(session, port, `/${c.vSegment}`, { headers: { 'accept-version': '9.9.9' } });
  rows.push({ name: 'v2-unregistered', status: response.status, echoed: echo(response.text) });
  response = await http(session, port, '/loops', { method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ definition: { schemaVersion: 4, name: 'qa438 rc1', nodes: [], edges: [] }, qa438: c.vBody }) });
  rows.push({ name: 'v3-body', status: response.status, echoed: echo(response.text) });
  response = await http(session, port, '/loops', { method: 'POST', headers: { 'content-type': 'application/json' }, body: `{"qa438":${c.vJson}` });
  rows.push({ name: 'v4-malformed-json', status: response.status, echoed: echo(response.text) });
  const before = await health(session, port);
  rows.push({ name: 'p1-header-token', ...(await rawExchange(session, port, malformedP1(port, c))) });
  rows.push({ name: 'p2-chunk-size', ...(await rawExchange(session, port, malformedP2(port, c))) });
  const after = await health(session, port);
  return { rows, liveness: { before, after, same: before.pid === after.pid && before.identity === after.identity && after.phase === 'running' } };
}

/** Wait until the slot sizes and identities have been stable for `quietMs`, then read once (bounded). */
async function settledSlots(root, quietMs = 800, timeoutMs = 10_000) {
  let last = '';
  let since = Date.now();
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const key = [];
    for (const name of ['gateway.log', 'gateway.log.1']) {
      const info = await stat(join(root, name), { bigint: true }).catch(() => null);
      key.push(info ? `${info.ino}:${info.size}` : '-');
    }
    const joined = key.join('|');
    if (joined !== last) { last = joined; since = Date.now(); } else if (Date.now() - since >= quietMs) break;
    await sleep(150);
  }
  return slotState(root);
}

const ALLOWED_REQ = ['method', 'route'];
const ALLOWED_RES = ['method', 'route', 'statusCode'];

function analyse(state, canaries) {
  const files = { 'gateway.log.1': state['gateway.log.1'].bytes, 'gateway.log': state['gateway.log'].bytes };
  const records = Object.entries(files).flatMap(([file, bytes]) => (bytes ? parseRecords(bytes).map((row) => ({ file, ...row })) : []));
  const broken = records.filter((row) => row.incomplete || row.error).map(({ file, offset, length, error }) => ({ file, offset, length, error }));
  const hits = scanCanaries(files, canaries);
  const clientErrors = records.filter((row) => row.value && (/^client /u.test(row.value.msg ?? '') || /^HPE_/u.test(String(row.value.err?.code ?? ''))))
    .map((row) => ({ file: row.file, offset: row.offset, level: row.value.level, msg: row.value.msg, errKeys: Object.keys(row.value.err ?? {}),
      errType: row.value.err?.type ?? row.value.err?.name ?? null, errCode: row.value.err?.code ?? null,
      hasRawPacket: row.value.err?.rawPacket !== undefined, canaries: [...new Set(hits.filter((hit) => hit.file === row.file && hit.offset === row.offset).map((hit) => hit.canary))] }));
  const access = records.filter((row) => ['incoming request', 'request completed', 'request errored'].includes(row.value?.msg));
  const violations = access.filter((row) => {
    const { req, res } = row.value;
    return (req !== undefined && Object.keys(req).some((key) => !ALLOWED_REQ.includes(key))) ||
      (res !== undefined && Object.keys(res).some((key) => !ALLOWED_RES.includes(key)));
  }).map((row) => ({ file: row.file, offset: row.offset, msg: row.value.msg, req: row.value.req, res: row.value.res }));
  const tuples = {};
  for (const row of access) {
    const shape = row.value.res ?? row.value.req;
    if (!shape || (shape.route === '/healthz' && (shape.statusCode ?? 200) === 200) || shape.route === '/system/shutdown') continue;
    const key = [row.value.msg, shape.method ?? '-', shape.route ?? '(none)', shape.statusCode ?? '-'].join(' ');
    tuples[key] = (tuples[key] ?? 0) + 1;
  }
  const accessHits = hits.filter((hit) => access.some((row) => row.file === hit.file && row.offset === hit.offset));
  return { counts: { records: records.length, access: access.length, clientErrors: clientErrors.length }, broken, hits, accessHits,
    clientErrors, violations, tuples, records };
}

function rc1Predicates(analysis, exchange) {
  const p1 = exchange.rows.find((row) => row.name === 'p1-header-token');
  const p2 = exchange.rows.find((row) => row.name === 'p2-chunk-size');
  const demonstrated = analysis.clientErrors.filter((row) => row.canaries.length > 0);
  // A 4xx reply proves the server handled the parser error. A server-terminated connection without
  // reply bytes (a reset can discard them) is inconclusive here; the controlled receipt decides reach.
  const replied = (row) => row && row.status >= 400 && row.status < 500;
  const terminated = (row) => row && row.status === 0 && row.reason !== 'timeout';
  return {
    'rc1-reply-reached': {
      status: [p1, p2].every(replied) ? 'pass' : [p1, p2].every((row) => replied(row) || terminated(row)) ? 'inconclusive' : 'fail',
      detail: [p1, p2].map((row) => row && { name: row.name, status: row.status, statusLine: row.statusLine, reason: row.reason,
        fastifyClientErrorBody: row.fastifyClientErrorBody }),
    },
    'rc1-sink-canary-free': { status: analysis.hits.length === 0 ? 'pass' : 'fail', detail: { hits: analysis.hits.slice(0, 40) } },
    'rc1-leak-path-observed': {
      status: 'informational',
      detail: { observed: demonstrated.length > 0, clientErrorRecords: analysis.clientErrors,
        note: 'Baseline must show this path or be qualified; a corrected candidate may keep a projected record or none.' },
    },
    'access-projection': { status: analysis.violations.length === 0 && analysis.accessHits.length === 0 ? 'pass' : 'fail',
      detail: { violations: analysis.violations.slice(0, 20), accessHits: analysis.accessHits.slice(0, 20), tuples: analysis.tuples } },
    'sink-records-complete': { status: analysis.broken.length === 0 ? 'pass' : 'fail', detail: { broken: analysis.broken.slice(0, 20) } },
    'gateway-liveness': { status: exchange.liveness.same ? 'pass' : 'fail', detail: exchange.liveness },
    'public-reply-no-echo': { status: exchange.rows.every((row) => !(row.echoed?.length)) ? 'pass' : 'informational',
      detail: exchange.rows.map((row) => ({ name: row.name, echoed: row.echoed ?? [] })) },
  };
}

// ------------------------------------------------------------------ c-f1-logger-err (controlled)

export async function runLoggerErr(ctx) {
  const { session } = ctx.qa;
  const n = nonce();
  const loggerRel = 'apps/api/dist/gateway-logger.js';
  const writerRel = 'apps/api/dist/windows-log/gateway-log-writer.js';
  const root = await ctx.dir('logger-root');
  const specPath = join(ctx.evidence, 'logger-spec.json');
  const spec = { loggerPath: join(session.checkout, ...loggerRel.split('/')), loggerSha256: session.build.files[loggerRel],
    writerPath: join(session.checkout, ...writerRel.split('/')), writerSha256: session.build.files[writerRel],
    root, outPath: join(ctx.evidence, 'logger-child-result.json'), nonce: n, canary: 'qa438lprobe' + n };
  await ctx.put('logger-spec.json', spec);
  // Reused V4 run with the clean case environment; a controlled child is never terminated.
  const call = await ctx.native.run('logger-child', session.node, [fileURLToPath(import.meta.url), '--logger-child', specPath], root,
    { childEnv: ctx.env, timeout: 60_000 });
  assert.equal(call.stdoutEnd?.bytes, call.stdoutBytes, 'logger child stdout EOF');
  assert.equal(call.stderrEnd?.bytes, call.stderrBytes, 'logger child stderr EOF');
  if (call.exit.code !== 0) return { status: 'error', tier: 'controlled', error: { childExit: call.exit.code, stderr: call.stderr.slice(0, 2000) } };
  const child = JSON.parse(readFileSync(spec.outPath, 'utf8'));
  const state = await slotState(root);
  const records = parseRecords(state['gateway.log'].bytes ?? Buffer.alloc(0)).map((row) => row.value).filter(Boolean);
  await ctx.raw('gateway.log.copy', state['gateway.log'].bytes ?? Buffer.alloc(0));
  const engine = records.find((value) => value.msg === 'qa438 logger err engine');
  const diagnostic = records.find((value) => value.msg === 'qa438 logger err diagnostic');
  const probe = records.find((value) => value.msg === 'client error');
  const err = engine?.err ?? {};
  const probeHits = scanCanaries({ 'gateway.log': state['gateway.log'].bytes }, { probe: spec.canary });
  return {
    tier: 'controlled',
    predicates: {
      'engine-err-retained': {
        status: (err.type ?? err.name) === 'QaEngineError' && String(err.message ?? '').startsWith(child.e1.message) &&
          typeof err.stack === 'string' && err.stack.includes(child.e1.stack.split('\n')[0]) ? 'pass' : 'fail',
        detail: { type: err.type ?? null, name: err.name ?? null, message: err.message ?? null, stackHead: String(err.stack ?? '').split('\n')[0] },
      },
      'engine-diagnostic-retained': {
        status: diagnostic?.error?.name === child.e1.name && diagnostic?.error?.message === child.e1.message &&
          diagnostic?.error?.stack === child.e1.stack ? 'pass' : 'fail',
        detail: { runId: diagnostic?.runId ?? null, nodeId: diagnostic?.nodeId ?? null },
      },
      'engine-err-extra-fields': { status: 'informational', detail: { code: err.code ?? null, qaDetail: err.qaDetail ?? null,
        causeInMessage: String(err.message ?? '').includes('qa438 cause'), keys: Object.keys(err) } },
      'logger-locus-probe': { status: 'informational', detail: { recordPresent: !!probe, errKeys: Object.keys(probe?.err ?? {}),
        rawPacketPresent: probe?.err?.rawPacket !== undefined, canaryForms: [...new Set(probeHits.map((hit) => hit.form))],
        note: 'Shows whether the logger itself narrows a parser-shaped err; a fix elsewhere is equally valid.' } },
      'logger-settled': { status: child.settled ? 'pass' : 'fail', detail: { settled: child.settled } },
    },
  };
}

async function loggerChild(specPath) {
  const spec = JSON.parse(readFileSync(specPath, 'utf8'));
  for (const [path, digest] of [[spec.writerPath, spec.writerSha256], [spec.loggerPath, spec.loggerSha256]]) {
    assert.equal(sha256(readFileSync(path)), digest, 'built module digest ' + path);
  }
  const W = await import(pathToFileURL(spec.writerPath).href);
  const L = await import(pathToFileURL(spec.loggerPath).href);
  const writer = await W.openGatewayLog({ root: spec.root });
  const logger = L.createGatewayLogger({ logLevel: 'trace' }, writer);
  class QaEngineError extends Error {
    constructor(message) { super(message); this.name = 'QaEngineError'; this.code = 'QA438_ENGINE'; this.qaDetail = { kind: 'qa438-detail' }; }
  }
  const e1 = new QaEngineError('qa438 engine diagnostic ' + spec.nonce);
  e1.cause = new Error('qa438 cause ' + spec.nonce);
  logger.error({ err: e1 }, 'qa438 logger err engine');
  logger.error({ runId: 'qa438-run', nodeId: 'qa438-node', error: { name: e1.name, message: e1.message, stack: e1.stack } }, 'qa438 logger err diagnostic');
  const e2 = Object.assign(new Error('Parse Error: Invalid header value char'),
    { code: 'HPE_INVALID_HEADER_TOKEN', bytesParsed: 12, reason: 'Invalid header value char', rawPacket: Buffer.from(`GET /${spec.canary} HTTP/1.1\r\n`) });
  logger.trace({ err: e2 }, 'client error');
  const settled = await writer.settle(2000);
  await writer.close();
  writeFileSync(spec.outPath, JSON.stringify({ settled, e1: { name: e1.name, message: e1.message, stack: e1.stack } }, null, 2) + '\n', { flag: 'wx' });
}

// ------------------------------------------------------------------ c-f1-client-error (controlled)

export async function runClientError(ctx) {
  const { session } = ctx.qa;
  const c = makeCanaries(nonce());
  const store = await ctx.store('gateway');
  const port = await ctx.port();
  const root = await ctx.privateDir('log-root');
  const receipts = join(ctx.evidence, 'client-error-receipts.jsonl');
  await ctx.put('canaries.json', c);
  const config = ctx.config({ dataDir: store, port, environment: { GG_LOG_LEVEL: 'trace' } });
  const env = gatewayEnv(ctx, config, { GG_WINDOWS_LAUNCHER_LOG_DIR: root, QA438_RECEIPT_PATH: receipts, QA438_CANARIES_JSON: JSON.stringify(c) });
  const entry = join(session.checkout, 'apps', 'api', 'dist', 'main.js');
  const preloadPath = join(fileURLToPath(new URL('.', import.meta.url)), 'f1-receipt-preload.mjs');
  const preload = pathToFileURL(preloadPath).href;
  // Exact expected full argv after the Node executable: the read-only preload, then the admitted entry.
  const gateway = await serveDirect(ctx, 'direct-gateway', ['--import', preload, { path: entry }], env,
    { port, store, cwd: session.checkout, timeout: session.caps.caseMs });
  const evidence = { argv: ['--import', preload, entry], preloadSha256: sha256(await readFile(preloadPath)) };
  evidence.exchange = await stimuli(session, port, c);
  const state = await settledSlots(root);
  evidence.slots = withoutBytes(state);
  const analysis = analyse(state, c);
  await ctx.raw('gateway.log.copy', state['gateway.log'].bytes ?? Buffer.alloc(0));
  evidence.analysis = { ...analysis, records: undefined };
  evidence.drain = await drainOwned(ctx, gateway);
  let rows = [];
  try { rows = (await readFile(receipts, 'utf8')).trim().split('\n').filter(Boolean).map((line) => JSON.parse(line)); } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }
  evidence.receipts = rows;
  const p1Keys = Object.keys(group(c, 'p1'));
  const p1 = rows.find((row) => row.rawPacket && ['p1Path', 'p1Query', 'p1Header'].every((key) => row.rawPacket.canaries[key]));
  const p2 = rows.find((row) => row.rawPacket?.canaries.p2Body);
  await ctx.put('evidence.json', evidence);
  return {
    tier: 'controlled',
    predicates: {
      'rc1-parser-event-reached': {
        status: p1 && p2 && p1.listeners >= 1 ? 'pass' : 'fail',
        detail: { receipts: rows.length, p1: p1 && { code: p1.code, enumerable: p1.rawPacket.enumerable, canaries: p1.rawPacket.canaries },
          p2: p2 && { code: p2.code, enumerable: p2.rawPacket.enumerable, canaries: p2.rawPacket.canaries },
          p1BodyInPacket: p1 ? p1.rawPacket.canaries.p1Body === true : null, p1Keys },
      },
      ...rc1Predicates(analysis, evidence.exchange),
      'direct-exit-after-drain': { status: evidence.drain.exit?.exit?.code === 0 ? 'pass' : 'fail', detail: evidence.drain.exit },
    },
  };
}

// ------------------------------------------------------------------ n-f1-trace-launcher (native)

/** #381 boundary: a provider-free mutate node that produces an invalid patch (from the accepted V4 fixture). */
async function privateFailure(session, port, root, pid) {
  const { observe } = session.lib.native;
  const definition = { schemaVersion: 4, name: 'QA 438 correction private diagnostics',
    nodes: [
      { id: 'start', kind: 'trigger', label: 'Start', config: { type: 'manual' } },
      { id: 'mut', kind: 'mutate', label: 'QA mutation', config: { operations: [
        { op: 'set', path: '/vars/qaBefore', value: { kind: 'literal', value: true } },
        { op: 'set', path: '/vars', value: { kind: 'literal', value: 7 } }] } },
      { id: 'done', kind: 'exit', label: 'Done', config: { outcome: 'success', returns: 'vars', destinations: [{ kind: 'caller' }] } }],
    edges: [{ id: 'e1', from: { node: 'start', port: 'out' }, to: { node: 'mut' } }, { id: 'e2', from: { node: 'mut', port: 'out' }, to: { node: 'done' } }] };
  const post = (body) => ({ method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
  const created = await http(session, port, '/loops', post({ definition }));
  assert.equal(created.status, 201, created.text.slice(0, 300));
  const loopId = JSON.parse(created.text).loop.id;
  assert.equal((await http(session, port, `/loops/${loopId}/publish`, { method: 'POST' })).status, 200);
  const started = await http(session, port, `/loops/${loopId}/runs`, post({}));
  assert.equal(started.status, 202, started.text.slice(0, 300));
  const runId = JSON.parse(started.text).run.id;
  const failed = await observe('private diagnostic public failure', async () => {
    const value = JSON.parse((await http(session, port, `/runs/${runId}`)).text);
    return value.status === 'failed' ? value : false;
  }, 15_000);
  const events = JSON.parse((await http(session, port, `/runs/${runId}/events?limit=100`)).text);
  const record = await observe('correlated private record', async () => {
    const state = await slotState(root);
    for (const name of ['gateway.log', 'gateway.log.1']) {
      const found = parseRecords(state[name].bytes ?? Buffer.alloc(0)).map((row) => row.value)
        .find((value) => value?.runId === runId && value?.nodeId === 'mut' && value?.msg === 'node produced an invalid patch');
      if (found) return found;
    }
    return false;
  }, 8000);
  const publicText = JSON.stringify({ failed, events });
  const error = record.error ?? {};
  return {
    status: failed.failure?.code === 'INTERNAL_ERROR' && failed.failure?.nodeId === 'mut' && record.pid === pid &&
      ['name', 'message', 'stack'].every((key) => typeof error[key] === 'string' && error[key].length > 0) &&
      !/"stack"\s*:/u.test(publicText) ? 'pass' : 'fail',
    detail: { runId, publicFailure: failed.failure, privateKeys: Object.keys(error), privateName: error.name, privateMessage: error.message,
      stackHead: String(error.stack ?? '').split('\n')[0], recordPid: record.pid },
  };
}

/** Sustained provider-free access records through at least one rotation of a seeded active slot (bounded). */
async function rotationSmoke(session, port, root, seed) {
  const samples = [];
  let sent = 0;
  let rotated = false;
  const deadline = Date.now() + 60_000;
  while (Date.now() < deadline && sent < 2400 && !rotated) {
    await Promise.all(Array.from({ length: 24 }, (_, index) => http(session, port, `/healthz?n=${sent + index}`).catch(() => null)));
    sent += 24;
    const active = await stat(join(root, 'gateway.log'), { bigint: true }).catch(() => null);
    const previous = await stat(join(root, 'gateway.log.1'), { bigint: true }).catch(() => null);
    samples.push({ sent, active: active && { ino: String(active.ino), size: Number(active.size) }, previous: previous && { ino: String(previous.ino), size: Number(previous.size) } });
    rotated = previous !== null && String(previous.ino) === seed.ino;
  }
  for (let extra = 0; extra < 4; extra++) await Promise.all(Array.from({ length: 24 }, () => http(session, port, '/healthz').catch(() => null)));
  const state = await settledSlots(root);
  const rows = ['gateway.log.1', 'gateway.log'].flatMap((name) => parseRecords(state[name].bytes ?? Buffer.alloc(0)).map((row) => ({ name, ...row })));
  const bad = rows.filter((row) => row.incomplete || row.error || row.length > 65_536);
  const sizesOk = samples.every((row) => (row.active?.size ?? 0) <= SLOT && (row.previous?.size ?? 0) <= SLOT) &&
    ['gateway.log', 'gateway.log.1'].every((name) => !state[name].exists || state[name].size <= SLOT);
  return {
    status: rotated && sizesOk && bad.length === 0 ? 'pass' : 'fail',
    detail: { rotated, sent, samples: samples.filter((_, index) => index % 5 === 0 || index === samples.length - 1), slots: withoutBytes(state), badRecords: bad.length },
  };
}

export async function runTraceLauncher(ctx) {
  const { session } = ctx.qa;
  const c = makeCanaries(nonce());
  const store = await ctx.store('gateway');
  const port = await ctx.port();
  const root = await ctx.privateDir('install');
  await ctx.put('canaries.json', c);
  const evidence = {};
  // Seed the active slot near its cap with complete, canary-free records so pressure must rotate it.
  const seedLines = [];
  let seedSize = 0;
  for (let index = 0; seedSize < SLOT - 262_144 - 1024; index++) {
    const head = `{"level":30,"msg":"qa438seed","i":${index},"p":"`;
    const line = head + 's'.repeat(1024 - head.length - 3) + '"}\n';
    seedLines.push(line);
    seedSize += Buffer.byteLength(line);
  }
  await writeFile(join(root, 'gateway.log'), seedLines.join(''), { flag: 'wx' });
  const seedInfo = await stat(join(root, 'gateway.log'), { bigint: true });
  assert.equal(Number(seedInfo.size), seedSize, 'exact trace seed size');
  evidence.seed = { ino: String(seedInfo.ino), size: Number(seedInfo.size) };
  const config = ctx.config({ dataDir: store, port, environment: { GG_LOG_LEVEL: 'trace' }, startup: 30 });
  const configPath = await ctx.writeConfig(root, 'qa438-trace', config);
  // Expected identity, quiet launch (exit 0, no output, both EOFs), then the full proof.
  const gateway = await bootLauncher(ctx, 'trace', session.launcher, configPath, config, { cwd: session.checkout });
  evidence.launch = { launcherPid: gateway.launcher.pid, exit: gateway.launcher.exit };
  evidence.exchange = await stimuli(session, port, c);
  const state = await settledSlots(root);
  const analysis = analyse(state, c);
  evidence.analysis = { ...analysis, records: undefined };
  // Exact bytes of every non-seed line (both slots, previous first); seed lines are counted only.
  const exact = analysis.records.filter((row) => !(row.value && row.value.msg === 'qa438seed'))
    .map((row) => state[row.file].bytes.subarray(row.offset, row.offset + row.length));
  await ctx.raw('gateway.log.nonseed-lines', Buffer.concat(exact));
  evidence.private381 = await privateFailure(session, port, root, gateway.proof.health.pid);
  evidence.rotation = await rotationSmoke(session, port, root, evidence.seed);
  const finalState = await settledSlots(root);
  const finalHits = scanCanaries({ 'gateway.log.1': finalState['gateway.log.1'].bytes, 'gateway.log': finalState['gateway.log'].bytes }, c);
  let launcherLog = null;
  try { launcherLog = await readFile(join(root, 'launcher.log')); } catch (error) { if (error.code !== 'ENOENT') throw error; }
  const launcherHits = launcherLog ? scanCanaries({ 'launcher.log': launcherLog }, c) : [];
  evidence.after = await health(session, port);
  evidence.drain = await drainOwned(ctx, gateway);
  await ctx.put('evidence.json', evidence);
  return {
    tier: 'native',
    predicates: {
      'launcher-quiet-start': { status: gateway.launcher.exit.code === 0 ? 'pass' : 'fail', detail: evidence.launch },
      ...rc1Predicates(analysis, evidence.exchange),
      'rc1-sink-canary-free-final': { status: finalHits.length === 0 && launcherHits.length === 0 ? 'pass' : 'fail',
        detail: { slotHits: finalHits.slice(0, 20), launcherHits: launcherHits.slice(0, 20) } },
      '381-private-diagnostic': { status: evidence.private381.status, detail: evidence.private381.detail },
      'rotation-smoke': { status: evidence.rotation.status, detail: evidence.rotation.detail },
      'same-gateway-throughout': { status: evidence.after.pid === gateway.proof.health.pid && evidence.after.identity === gateway.expected ? 'pass' : 'fail',
        detail: { pid: gateway.proof.health.pid, after: evidence.after } },
    },
  };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href && process.argv[2] === '--logger-child') {
  loggerChild(process.argv[3]).then(() => process.exit(0), (error) => {
    process.stderr.write(String(error?.stack ?? error) + '\n');
    process.exit(1);
  });
}
