// Source-only tier (read-only file reads of the admitted build). Never a behavior claim: it records
// where each root cause is handled, which allocation primitives the writer uses (coverage of the
// F2 tracker) and whether the operator documentation and launcher source carry the exact admitted
// destination-in-use texts. No phrase ban: the oracle is equality with the admitted text.
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';

const TRACKED = ['Buffer.from', 'Buffer.concat', 'Buffer.alloc', 'Buffer.allocUnsafe', 'Buffer.allocUnsafeSlow', 'TextEncoder'];
const UNTRACKED = ['new Uint8Array', 'new ArrayBuffer', 'Buffer.copyBytesFrom', 'new SharedArrayBuffer', 'encodeInto', 'new DataView', 'Buffer.of('];
const DERIVED = ['.subarray(', '.slice('];

async function text(checkout, rel) {
  try { return await readFile(join(checkout, ...rel.split('/')), 'utf8'); } catch (error) { if (error.code === 'ENOENT') return null; throw error; }
}

function excerpts(source, pattern, radius = 6, limit = 8) {
  if (source === null) return null;
  const lines = source.split(/\r?\n/u);
  const found = [];
  lines.forEach((line, index) => {
    if (found.length < limit && pattern.test(line)) found.push({ line: index + 1, text: lines.slice(Math.max(0, index - radius), index + radius + 1).join('\n') });
  });
  return found;
}

/** The troubleshooting bullet for the in-use outcome, from its marker up to the next bullet or blank line. */
export function docsInUseBlock(guide, expectedDocsBlock) {
  if (guide === null) return null;
  const heading = /^- \*\*[^*\r\n]+\*\*/u.exec(expectedDocsBlock)?.[0];
  if (!heading) return null;
  const lines = guide.split(/\r?\n/u);
  const start = lines.findIndex((line) => line.startsWith(heading));
  if (start < 0) return null;
  let end = start + 1;
  while (end < lines.length && lines[end].startsWith('  ') && !lines[end].startsWith('- ')) end++;
  return lines.slice(start, end).join('\n');
}

export async function run(ctx) {
  const { session } = ctx.qa;
  const { checkout } = session;
  const { expectedInUseText, expectedDocsBlock, textSource } = session.admission.rc3;
  const writer = await text(checkout, 'apps/api/dist/windows-log/gateway-log-writer.js');
  const count = (list) => Object.fromEntries(list.map((name) => [name, writer ? writer.split(name).length - 1 : null]));
  const untracked = count(UNTRACKED);
  const untrackedUsed = UNTRACKED.filter((name) => untracked[name] > 0);
  const locus = {};
  for (const rel of ['apps/api/dist/gateway-logger.js', 'apps/api/dist/app.js', 'apps/api/dist/serve.js', 'apps/api/dist/windows-log/guard.js']) {
    locus[rel] = excerpts(await text(checkout, rel), /clientError|rawPacket|serializers|\berr\b\s*:/u);
  }
  const launcher = await text(checkout, 'apps/windows-launcher/Launcher.cs');
  const guide = await text(checkout, 'docs/guide/07-troubleshooting.md');
  const block = docsInUseBlock(guide, expectedDocsBlock);
  const adr = await text(checkout, 'docs/decisions/ADR-0081-bounded-windows-launcher-logs.md');
  const result = {
    tier: 'source-only',
    predicates: {
      'docs-in-use-text-exact': {
        status: block === null ? 'not-reached' : block === expectedDocsBlock ? 'pass' : 'fail',
        detail: { textSource, observed: block, expected: expectedDocsBlock,
          note: 'Baseline: the frozen block (unqualified attribution) is the negative control. Candidate: the root-reviewed block.' },
      },
      'launcher-in-use-text-source': {
        status: launcher === null ? 'not-reached' : launcher.includes(JSON.stringify(expectedInUseText).slice(1, -1)) ? 'pass' : 'informational',
        detail: { textSource, expected: expectedInUseText, excerpt: excerpts(launcher, /destination-in-use/u, 4, 4),
          note: 'Informational when the source builds the text differently; the native stderr/record equality decides.' },
      },
      'adr-in-use-wording': { status: 'informational', detail: excerpts(adr, /sharing violation|in use|live writer/iu, 2) },
      'writer-allocation-primitives': { status: untrackedUsed.length === 0 ? 'informational' : 'coverage-warning',
        detail: { tracked: count(TRACKED), untracked, derivedViews: count(DERIVED), untrackedUsed,
          note: 'An untracked primitive makes the F2 retained-cap result inconclusive; derived views are covered by backing-range accounting.' } },
      'writer-write-path-excerpt': { status: 'informational', detail: excerpts(writer, /writeBatch|handle\.write\(|Buffer\.concat/u, 12, 4) },
      'client-error-locus': { status: 'informational', detail: locus },
    },
  };
  await ctx.put('source-inspection.json', result);
  return result;
}
