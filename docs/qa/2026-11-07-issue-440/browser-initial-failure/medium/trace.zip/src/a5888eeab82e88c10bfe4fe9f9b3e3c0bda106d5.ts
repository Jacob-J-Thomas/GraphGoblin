import { LoopDefinitionSchema, ModelCatalogEntrySchema } from '@graphgoblin/contracts';
import { minimalLoop } from '@graphgoblin/contracts/testing';
import {
  closeNode,
  control,
  expect,
  openAdvanced,
  openNode,
  showLoopPanel,
  test,
} from './fixtures.js';

function inferenceLoop(name: string, model?: string) {
  const source = minimalLoop();
  return {
    ...source,
    name,
    nodes: [
      source.nodes[0]!,
      {
        id: 'infer',
        kind: 'inference',
        label: 'Infer',
        config: { prompt: { template: 'picker run' }, ...(model ? { model } : {}) },
      },
      source.nodes[1]!,
    ].map((node, i) => ({ ...node, ui: { x: i * 260, y: 80 } })),
    edges: [
      { id: 'e1', from: { node: 'start', port: 'out' }, to: { node: 'infer' } },
      { id: 'e2', from: { node: 'infer', port: 'out' }, to: { node: 'done' } },
    ],
  };
}

for (const requestedEffort of ['none', 'medium']) {
  test(`seeded GPT-6.1 Terra offers medium by default and publishes ${requestedEffort}`, async ({
    page,
    request,
  }) => {
    const response = await request.get('/model-catalog');
    const catalog = (await response.json()) as { items: unknown[] };
    expect(
      catalog.items
        .map((entry) => ModelCatalogEntrySchema.parse(entry))
        .find((entry) => entry.model === 'gpt-6.1-terra'),
    ).toMatchObject({
      harness: 'codex',
      source: 'harness',
      displayName: 'GPT-6.1 Terra',
      efforts: ['none', 'low', 'medium', 'high', 'xhigh', 'max'],
      defaultEffort: 'medium',
      enabled: true,
    });
    const created = await request.post('/loops', {
      data: { definition: inferenceLoop(`Terra ${requestedEffort}`) },
    });
    expect(created.status()).toBe(201);
    const { loop } = (await created.json()) as { loop: { id: string } };
    await page.goto(`/app/loops/${loop.id}/edit`);
    const dialog = await openNode(page, 'infer');
    await dialog.getByLabel('Model', { exact: true }).selectOption('gpt-6.1-terra');
    const effort = dialog.getByLabel('Effort', { exact: true });
    await expect(effort.locator('option')).toHaveText([
      'Default (medium)',
      'none (no reasoning)',
      'low',
      'medium',
      'high',
      'xhigh',
      'max',
    ]);
    await effort.selectOption(requestedEffort);
    await closeNode(page);
    await page.getByRole('button', { name: 'Publish', exact: true }).click();
    await expect(page.getByText('Published version 1.')).toBeVisible();
    const stored = (await (await request.get(`/loops/${loop.id}`)).json()) as {
      current: { definition: unknown };
    };
    expect(
      LoopDefinitionSchema.parse(stored.current.definition).nodes.find(
        (node) => node.id === 'infer',
      )?.config,
    ).toMatchObject({ model: 'gpt-6.1-terra', effort: requestedEffort });
    await control(request, '/harness/script', { turns: [{ finalText: 'Terra catalog smoke' }] });
    const before = (await control(request, '/harness/requests')) as {
      started: { model: string; effort: string }[];
    };
    await page.getByRole('link', { name: 'Open in Runs' }).first().click();
    await page.getByRole('button', { name: 'Start run', exact: true }).click();
    await expect
      .poll(async () =>
        ((await control(request, '/harness/requests')) as typeof before).started.slice(
          before.started.length,
        ),
      )
      .toEqual([{ model: 'gpt-6.1-terra', effort: requestedEffort }]);
    await expect(page.locator('[data-status="succeeded"]').first()).toBeVisible();
  });
}

for (const theme of ['dark', 'light']) {
  test(`catalog model and effort publish and reach the harness (${theme})`, async ({
    page,
    request,
  }) => {
    const selected = `picker-${theme}`;
    await control(request, '/catalog/upsert', {
      harness: 'codex',
      model: selected,
      displayName: `Picker ${theme}`,
      efforts: ['low', 'high'],
      defaultEffort: 'low',
      enabled: true,
      source: 'harness',
    });
    const created = await request.post('/loops', {
      data: { definition: inferenceLoop(`picker ${theme}`) },
    });
    expect(created.status()).toBe(201);
    const { loop } = (await created.json()) as { loop: { id: string } };
    await page.addInitScript((choice) => localStorage.setItem('graphgoblin-theme', choice), theme);
    await page.goto(`/app/loops/${loop.id}/edit`);
    const dialog = await openNode(page, 'infer');
    const model = dialog.getByLabel('Model', { exact: true });
    await expect(model).not.toHaveAttribute('aria-readonly');
    await expect(model).toHaveValue('');
    await model.focus();
    await page.keyboard.type(`Picker ${theme}`);
    await page.keyboard.press('Enter');
    await expect(model).toHaveValue(selected);
    const effort = dialog.getByLabel('Effort', { exact: true });
    await expect(effort.locator('option')).toHaveText(['Default (low)', 'low', 'high']);
    await effort.focus();
    await page.keyboard.press('h');
    await page.keyboard.press('Enter');
    await expect(effort).toHaveValue('high');
    await closeNode(page);
    await page.getByRole('button', { name: 'Publish', exact: true }).click();
    await expect(page.getByText('Published version 1.')).toBeVisible();
    const read = await request.get(`/loops/${loop.id}`);
    const stored = (await read.json()) as { current: { definition: unknown } };
    const config = LoopDefinitionSchema.parse(stored.current.definition).nodes.find(
      (node) => node.id === 'infer',
    )?.config;
    expect(config).toMatchObject({ model: selected, effort: 'high' });
    await control(request, '/harness/script', { turns: [{ finalText: 'picker done' }] });
    const before = (await control(request, '/harness/requests')) as {
      started: { model: string; effort: string }[];
    };
    await page.getByRole('link', { name: 'Open in Runs' }).first().click();
    await page.getByRole('button', { name: 'Start run', exact: true }).click();
    await expect(page).toHaveURL(/\/app\/runs\/[0-9A-Z]{26}$/);
    await expect
      .poll(async () =>
        ((await control(request, '/harness/requests')) as typeof before).started.slice(
          before.started.length,
        ),
      )
      .toEqual([{ model: selected, effort: 'high' }]);
    await expect(page.locator('[data-status="succeeded"]').first()).toBeVisible();
  });
}

test('a saved model removed from the catalog stays selected and explicit unknown import is rejected', async ({
  page,
  request,
}) => {
  await control(request, '/catalog/upsert', {
    harness: 'codex',
    model: 'imported-unknown-model',
    displayName: 'Imported unknown picker',
    efforts: ['low'],
    defaultEffort: 'low',
    enabled: true,
    source: 'litellm',
  });
  const created = await request.post('/loops', {
    data: { definition: inferenceLoop('imported unknown picker', 'imported-unknown-model') },
  });
  expect(created.status()).toBe(201);
  const { loop } = (await created.json()) as { loop: { id: string } };
  expect((await request.delete('/model-catalog/codex/imported-unknown-model')).status()).toBe(204);
  const rejectedImport = await request.post('/loops/import', {
    data: inferenceLoop('explicit unknown import', 'imported-unknown-model'),
  });
  expect(rejectedImport.status()).toBe(400);
  await page.goto(`/app/loops/${loop.id}/edit`);
  const dialog = await openNode(page, 'infer');
  const model = dialog.getByLabel('Model', { exact: true });
  await expect(model).toHaveValue('imported-unknown-model');
  await expect(model.locator('option:checked')).toHaveText(
    'imported-unknown-model (not in catalog)',
  );
  await expect(model).toHaveAccessibleDescription(/not in the catalog/);
  await expect(model).not.toHaveAccessibleDescription(/MODEL_NOT_IN_CATALOG/);
  await expect(dialog.locator('[data-field="model"] [role="status"] svg')).toHaveAttribute(
    'data-icon',
    'alert',
  );
  await expect(dialog.getByRole('link', { name: 'Model catalog in Settings' })).toHaveAttribute(
    'href',
    '/app/settings',
  );
  await closeNode(page);
  await page.route('**/model-catalog', (route) =>
    route.fulfill({
      status: 503,
      contentType: 'application/problem+json',
      body: JSON.stringify({ status: 503, code: 'FAILED', detail: 'catalog unavailable' }),
    }),
  );
  await page.reload();
  const offlineDialog = await openNode(page, 'infer');
  const offlineModel = offlineDialog.getByLabel('Model', { exact: true });
  await expect(offlineModel).toHaveValue('imported-unknown-model');
  await expect(offlineModel).toHaveAttribute('aria-readonly', 'true');
  await expect(offlineModel).toHaveAccessibleDescription(/Cannot load the model catalog/);
  await expect(offlineModel).toHaveAccessibleDescription(/MODEL_NOT_IN_CATALOG/);
});

test('catalog failure preserves the current values until retry and loop defaults share the picker', async ({
  page,
  request,
}) => {
  const catalog = ModelCatalogEntrySchema.array().parse(
    ((await (await request.get('/model-catalog')).json()) as { items: unknown }).items,
  );
  const chosen = catalog.find((entry) => entry.enabled && entry.harness === 'codex')!;
  const created = await request.post('/loops', {
    data: { definition: inferenceLoop('failed catalog picker', chosen.model) },
  });
  const { loop } = (await created.json()) as { loop: { id: string } };
  await page.route('**/model-catalog', (route) =>
    route.fulfill({
      status: 503,
      contentType: 'application/problem+json',
      body: JSON.stringify({ status: 503, code: 'FAILED', detail: 'catalog unavailable' }),
    }),
  );
  await page.goto(`/app/loops/${loop.id}/edit`);
  const dialog = await openNode(page, 'infer');
  const model = dialog.getByLabel('Model', { exact: true });
  await expect(model).toHaveValue(chosen.model);
  await expect(model).toHaveAttribute('aria-readonly', 'true');
  await expect(model).toHaveAccessibleDescription(/Cannot load the model catalog/);
  await page.unroute('**/model-catalog');
  await dialog.getByRole('button', { name: 'Retry model catalog' }).click();
  await expect(model).not.toHaveAttribute('aria-readonly');
  await expect(model).toHaveValue(chosen.model);
  await closeNode(page);
  await showLoopPanel(page);
  const settings = page.getByRole('form', { name: 'Loop settings form' });
  const defaults = settings.locator('[data-field="defaults.byHarness"]');
  await defaults.getByRole('button', { name: 'Add entry', exact: true }).click();
  await defaults.getByRole('textbox', { name: 'By harness key 1' }).fill('codex');
  const codexDefaults = settings.locator('[data-field="defaults.byHarness.codex"]');
  const defaultModel = codexDefaults.getByLabel('Model', { exact: true });
  await expect(defaultModel.locator('option').first()).toHaveText('(owner default) (gpt-6-luna)');
  await defaultModel.selectOption(chosen.model);
  await expect(codexDefaults.getByLabel('Effort', { exact: true }).locator('option')).toHaveCount(
    chosen.efforts.length + 1,
  );
});

test('the decision LLM uses an explicit harness model and rejects unsupported effort on admission', async ({
  page,
  request,
}) => {
  await control(request, '/catalog/upsert', {
    harness: 'codex',
    model: 'picker-decision',
    displayName: 'Picker decision',
    efforts: ['low', 'high'],
    defaultEffort: 'low',
    enabled: true,
    source: 'harness',
  });
  const source = inferenceLoop('decision picker');
  const withDecision = (effort: string) => ({
    ...source,
    nodes: source.nodes.map((node) =>
      node.id === 'infer'
        ? {
            ...node,
            kind: 'decision',
            config: {
              kind: 'llm',
              harness: 'codex',
              model: { mode: 'explicit', value: 'picker-decision' },
              effort: { mode: 'explicit', value: effort },
              context: {},
              instructions: 'q',
              routes: [
                {
                  id: 'yes',
                  label: 'Yes',
                },
                {
                  id: 'no',
                  label: 'No',
                },
              ],
            },
          }
        : node,
    ),
    edges: [
      source.edges[0],
      { id: 'yes', from: { node: 'infer', port: 'yes' }, to: { node: 'done' } },
      { id: 'no', from: { node: 'infer', port: 'no' }, to: { node: 'done' } },
    ],
  });
  const invalid = await request.post('/loops', {
    data: {
      definition: withDecision('max'),
    },
  });
  expect(invalid.status()).toBe(400);
  const created = await request.post('/loops', { data: { definition: withDecision('high') } });
  expect(created.status()).toBe(201);
  const { loop } = (await created.json()) as { loop: { id: string } };
  await page.goto(`/app/loops/${loop.id}/edit`);
  const dialog = await openNode(page, 'infer');
  const evaluation = dialog;
  const model = evaluation.getByLabel('Model', { exact: true });
  const effort = evaluation.getByLabel('Effort', { exact: true });
  await expect(model).toHaveValue('picker-decision');
  await expect(effort).toHaveValue('high');
  await closeNode(page);
  await page.getByRole('button', { name: 'Publish', exact: true }).click();
  await expect(page.getByText('Published version 1.')).toBeVisible();
  const read = await request.get(`/loops/${loop.id}`);
  const stored = (await read.json()) as { current: { definition: unknown } };
  expect(
    LoopDefinitionSchema.parse(stored.current.definition).nodes.find((node) => node.id === 'infer')
      ?.config,
  ).toMatchObject({
    kind: 'llm',
    model: { mode: 'explicit', value: 'picker-decision' },
    effort: { mode: 'explicit', value: 'high' },
  });
});

test('following a model issue keeps focus through a delayed catalog and a failed cached refresh', async ({
  page,
  request,
}) => {
  await control(request, '/catalog/upsert', {
    harness: 'codex',
    model: 'focus-unknown-model',
    displayName: 'Focus unknown picker',
    efforts: ['low'],
    defaultEffort: 'low',
    enabled: true,
    source: 'litellm',
  });
  const created = await request.post('/loops', {
    data: { definition: inferenceLoop('delayed catalog focus', 'focus-unknown-model') },
  });
  expect(created.status()).toBe(201);
  const { loop } = (await created.json()) as { loop: { id: string } };
  expect((await request.delete('/model-catalog/codex/focus-unknown-model')).status()).toBe(204);
  let release: (() => void) | undefined;
  const held = new Promise<void>((resolve) => {
    release = resolve;
  });
  let requested = false;
  await page.route('**/model-catalog', async (route) => {
    requested = true;
    await held;
    await route.continue();
  });
  await page.goto(`/app/loops/${loop.id}/edit`);
  // The editor prefetches before any node dialog is opened.
  await expect.poll(() => requested).toBe(true);
  await page
    .locator('.react-flow__node[data-id="infer"]')
    .getByRole('button', { name: '1 issue on infer' })
    .click();
  await page
    .getByRole('dialog', { name: 'Issues on infer' })
    .getByRole('button', { name: /^Error MODEL_NOT_IN_CATALOG/ })
    .click();
  const dialog = page.getByRole('dialog', { name: /^Edit inference/ });
  const model = dialog.getByLabel('Model', { exact: true });
  await expect(model).toHaveAttribute('aria-readonly', 'true');
  await expect(model).toBeFocused();
  const focused = await model.elementHandle();
  // Hold the request for the review reproduction's delay after the issue has focused the field.
  await page.waitForTimeout(2500);
  release?.();
  await expect(model).not.toHaveAttribute('aria-readonly');
  await expect(model).toBeFocused();
  expect(await model.evaluate((element, previous) => element === previous, focused)).toBe(true);
  await expect(model).toHaveValue('focus-unknown-model');
  await page.unroute('**/model-catalog');
  await page.route('**/model-catalog', (route) =>
    route.fulfill({
      status: 503,
      contentType: 'application/problem+json',
      body: JSON.stringify({ status: 503, code: 'FAILED', detail: 'catalog unavailable' }),
    }),
  );
  // RefetchOnWindowFocus needs a hidden-to-visible transition, without moving field focus.
  await page.waitForTimeout(2100);
  await page.evaluate(() => {
    Object.defineProperty(document, 'visibilityState', { configurable: true, value: 'hidden' });
    document.dispatchEvent(new Event('visibilitychange', { bubbles: true }));
    Reflect.deleteProperty(document, 'visibilityState');
    document.dispatchEvent(new Event('visibilitychange', { bubbles: true }));
  });
  await expect(model).toHaveAccessibleDescription(/catalog may be out of date/);
  await expect(model).toBeFocused();
  await expect(model).not.toHaveAttribute('aria-readonly');
  const choice = (await model.locator('option:not(:disabled)').nth(1).getAttribute('value')) ?? '';
  expect(choice).not.toBe('');
  await model.selectOption(choice);
  await expect(model).toHaveValue(choice);
  await model.focus();
  await page.keyboard.press('Tab');
  await expect(dialog.getByRole('button', { name: 'Retry model catalog' })).toBeFocused();
  await page.keyboard.press('Tab');
  await expect(dialog.getByRole('link', { name: 'Model catalog in Settings' })).toBeFocused();
});

test('explicit Claude to Codex switch persists the owner default and sends the exact request', async ({
  page,
  request,
}) => {
  const instance = await control(request, '/apps', { claude: true });
  const url = String(instance['url']);
  const instanceId = String(instance['instanceId']);
  expect(
    (
      await request.put(url + '/settings', {
        data: { defaults: { byHarness: { codex: { model: 'gpt-6.1-sol', effort: 'low' } } } },
      })
    ).status(),
  ).toBe(200);
  const definition = inferenceLoop('Reverse explicit harness switch');
  Object.assign(definition.nodes.find((node) => node.id === 'infer')!.config, {
    harness: 'claude',
    model: 'claude-opus-5-5',
    effort: 'high',
    harnessOptions: { sandbox: 'read-only', approval: 'never' },
  });
  const created = await request.post(url + '/loops', { data: { definition } });
  expect(created.status()).toBe(201);
  const { loop } = (await created.json()) as { loop: { id: string } };
  await page.goto(url + '/app/loops/' + loop.id + '/edit');
  const dialog = await openNode(page, 'infer');
  await openAdvanced(dialog);
  const model = dialog.getByLabel('Model', { exact: true });
  await dialog.getByRole('radio', { name: 'codex', exact: true }).focus();
  await page.keyboard.press('Space');
  await expect(model).toHaveValue('gpt-6.1-sol');
  await expect(dialog.getByLabel('Effort', { exact: true })).toHaveValue('high');
  await closeNode(page);
  await page.getByRole('button', { name: 'Publish', exact: true }).click();
  await expect(page.getByText('Published version 1.')).toBeVisible();
  await page.reload();
  const reopened = await openNode(page, 'infer');
  await openAdvanced(reopened);
  await expect(reopened.getByLabel('Model', { exact: true })).toHaveValue('gpt-6.1-sol');
  await expect(reopened.getByLabel('Effort', { exact: true })).toHaveValue('high');
  await closeNode(page);
  expect(
    (await request.post(url + '/loops/' + loop.id + '/runs', { data: { input: null } })).status(),
  ).toBe(202);
  await expect
    .poll(
      async () =>
        (await control(request, '/harness/requests', { instanceId, harness: 'codex' }))['started'],
    )
    .toMatchObject([{ model: 'gpt-6.1-sol', effort: 'high' }]);
});

test('cached catalog failure holds publication across a harness switch and recovers', async ({
  page,
  request,
}) => {
  const instance = await control(request, '/apps', { claude: true });
  const url = String(instance['url']);
  const definition = inferenceLoop('Cached catalog validation', 'gpt-6-luna');
  Object.assign(definition.nodes.find((node) => node.id === 'infer')!.config, {
    harness: 'codex',
    effort: 'high',
  });
  const created = await request.post(url + '/loops', { data: { definition } });
  expect(created.status()).toBe(201);
  const { loop } = (await created.json()) as { loop: { id: string } };
  await page.goto(url + '/app/loops/' + loop.id + '/edit');
  const dialog = await openNode(page, 'infer');
  await openAdvanced(dialog);
  const model = dialog.getByLabel('Model', { exact: true });
  // This case specifically needs the successful cache before the background refresh fails.
  await expect(page.getByText('Ready to publish', { exact: true })).toBeVisible();
  await expect(model.locator('option[value="gpt-6-luna"]')).toBeAttached();
  let refreshes = 0;
  await page.route(url + '/model-catalog', (route) => {
    refreshes++;
    return route.fulfill({
      status: 503,
      contentType: 'application/problem+json',
      body: JSON.stringify({ status: 503, code: 'FAILED', detail: 'catalog unavailable' }),
    });
  });
  // Exercise the normal stale-query refetch, without remounting or replacing its cached data.
  await page.waitForTimeout(2100);
  await page.evaluate(() => {
    Object.defineProperty(document, 'visibilityState', { configurable: true, value: 'hidden' });
    document.dispatchEvent(new Event('visibilitychange', { bubbles: true }));
    Reflect.deleteProperty(document, 'visibilityState');
    document.dispatchEvent(new Event('visibilitychange', { bubbles: true }));
  });
  await expect(model).toHaveAccessibleDescription(/catalog may be out of date/);
  const beforeSwitch = refreshes;
  await dialog.getByRole('radio', { name: 'claude', exact: true }).focus();
  await page.keyboard.press('Space');
  const notice = dialog.getByText(/Validation is unavailable while the catalog cannot be loaded/);
  await expect(notice).toBeVisible();
  const message = await notice.textContent();
  await expect(model).toHaveValue('gpt-6-luna');
  await expect(dialog.getByLabel('Effort', { exact: true })).toHaveValue('high');
  await expect(page.getByText('Validation unavailable', { exact: true })).toBeVisible();
  await expect(page.getByText('Ready to publish', { exact: true })).toHaveCount(0);
  await expect(page.getByRole('button', { name: 'Publish', exact: true })).toBeDisabled();
  expect(refreshes).toBe(beforeSwitch);
  await page.unroute(url + '/model-catalog');
  await dialog.getByRole('button', { name: 'Retry model catalog' }).click();
  await expect(model).toHaveAccessibleDescription(/Saved model belongs to Codex/);
  await expect(model).toHaveValue('gpt-6-luna');
  await expect(notice).toHaveText(message ?? '');
  // Recovery certifies the unchanged saved Codex draft; it never repairs the open form silently.
  await expect(page.getByText('Ready to publish', { exact: true })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Publish', exact: true })).toBeEnabled();
});
