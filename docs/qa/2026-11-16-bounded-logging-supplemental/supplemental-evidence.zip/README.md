# PR500 supplemental behavior QA archive

This packet preserves the admitted supplemental behavior run for the frozen PR500 candidate. It contains the complete report, all explicitly inventoried per-case evidence, the invocation and wrapper receipts, and the harness and helper provenance. The original report is stored byte-for-byte as `.md.txt` so repository Markdown formatting cannot rewrite it.

## Findings and limits

- Five serial modules ran: writer controls, guard controls, native startup, native sharing, and native predecessor. The report records 34 of 34 case groups passing. It also reports 392 spawns with matching exit, close, and EOF; 18 drains; 53 port-refusal checks; 10 holders exiting successfully and gone; 54 store files passing exclusive-open checks; and 18 expected retained reparse entries. See the full report for scope and per-case evidence.
- Two local-file and dangling-symlink variants returned Windows `EPERM`; they were not exercised and are not passes. The report records the body-serialization case as completed, not skipped.
- The evidence combines controlled harness cases and bounded native launcher observations. It is not a hosted installer or GUI acceptance result, a full CI result, or product acceptance. Formal review scans were 0/3 at the report checkpoint.
- The evidence inventory contains 2,211 case files (4,140,197 bytes), alongside 32 outer invocation files and 30 wrapper receipts. The complete fixture trees recorded by the inventory (575 directories, 1,783 files, 136,585,066 bytes, and 18 reparse entries) were not copied or read. Private provider-session streams are excluded. See [exclusions](exclusions.json) and the bounded [content-screen record](evidence-content-screen.json).

## Inspection paths

- [Full raw report](report/full-report.md.txt), [report analysis](report/analysis.json), [evidence inventory](report/evidence-inventory.json), and [original 15-row report checksum list](report/source-SHA256SUMS.txt). The separate reporter exit receipt is [exit.json](report/exit.json).
- [Admission](provenance/supplemental-admission.json), [invocation](provenance/supplemental-invocation.json), [root admission readback](provenance/root-admission-readback.json), [review readback](provenance/invoker-root-review.json), and [report seal readback](provenance/opus-root-seal.json).
- [Source-copy map](source-copy-map.json) records 2,319 exact source copies, the original batch-source paths, and repository-relative paths for reused V3/V4 harness files in the sibling [core archive](../2026-11-16-bounded-logging-core/README.md). It also identifies the candidate and predecessor bindings and executables by full hash without duplicating those external files.
- [Packet checksum list](SHA256SUMS.txt) covers every packet file except itself. The map, exclusions, and screen record document the exact copy set and boundaries.
