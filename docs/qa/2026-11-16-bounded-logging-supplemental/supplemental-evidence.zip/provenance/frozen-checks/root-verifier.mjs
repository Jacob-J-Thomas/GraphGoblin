import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
import {createWriteStream} from 'node:fs';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {pipeline} from 'node:stream/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
const batch=fileURLToPath(new URL('.',import.meta.url));
const suite=join(batch,'launcher-438-supplemental-qa-preparation');
const out=join(batch,'launcher-438-supplemental-frozen-checks-02');
const binding=join(batch,'launcher-438-candidate-binding-01.json');
const sha='8202421f8a0bda13d2f46467af88a060539b75111e9fabbbc38f461fcc7cf7ff';
const hash=b=>createHash('sha256').update(b).digest('hex');
assert.equal(process.version,'v22.23.4');assert.equal(hash(await readFile(binding)),sha);
await mkdir(out);
for(const [name,args] of [['source-checks',[join(suite,'source-checks.mjs'),'--binding',binding,sha]],['compile-helper',[join(suite,'compile-helper.mjs'),'--frozen',binding,sha,'helper-frozen-02']]]){
 const receipt={startedAt:new Date().toISOString(),executable:process.execPath,args};
 const child=spawn(process.execPath,args,{cwd:suite,windowsHide:true,stdio:['ignore','pipe','pipe']});receipt.pid=child.pid;
 const closed=new Promise(resolve=>{child.once('error',e=>receipt.error=e.message);child.once('exit',(code,signal)=>receipt.exit={code,signal,at:new Date().toISOString()});child.once('close',(code,signal)=>{receipt.close={code,signal,at:new Date().toISOString()};resolve();});});
 const drains=['stdout','stderr'].map(channel=>{const path=join(out,name+'.'+channel);receipt[channel]={path};child[channel].once('end',()=>receipt[channel].eof=new Date().toISOString());return pipeline(child[channel],createWriteStream(path,{flags:'wx'})).then(()=>receipt[channel].writeClosed=new Date().toISOString());});
 await Promise.all([closed,...drains]);
 for(const channel of ['stdout','stderr'])receipt[channel].sha256=hash(await readFile(receipt[channel].path));
 await writeFile(join(out,name+'.receipt.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({name,...receipt}));assert.equal(receipt.exit?.code,0);assert.equal(receipt.close?.code,0);assert.equal(receipt.error,undefined);
}
