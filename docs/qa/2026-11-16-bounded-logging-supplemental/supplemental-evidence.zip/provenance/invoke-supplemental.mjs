import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { createWriteStream } from 'node:fs';
import { lstat, mkdir, readFile, realpath, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { pipeline } from 'node:stream/promises';
import { fileURLToPath } from 'node:url';

const helpers = new URL('../launcher-438-candidate-freeze-root-tools/freeze.mjs', import.meta.url);
assert.equal(createHash('sha256').update(await readFile(helpers)).digest('hex'),
  'bc9359c83e01d2760047273c2358a722f60cff1e3edd86026c5a3ee553dc6e83');
const { admitRef, batch, checkedRef, currentNode, json, outputPath, psPath } = await import(helpers.href);
const now = () => new Date().toISOString();
const problem = ({ name, message, code }) => ({ name, message, code });
const save = (dir, name, value) => writeFile(join(dir, name), JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
const modules = ['writer-controls', 'guard-controls', 'native-startup', 'native-sharing', 'native-predecessor'];
const suite = join(batch, 'launcher-438-supplemental-qa-preparation');
assert.equal(await realpath(suite), suite);

const [planPath, sha256, ...extra] = process.argv.slice(2);
assert.equal(extra.length, 0, 'Usage: invoke-supplemental.mjs <root invocation plan> <SHA-256>');
assert.deepEqual(process.execArgv, []);
assert(!Object.keys(process.env).some((key) => /^(NODE_OPTIONS|GG_WINDOWS_LAUNCHER_LOG_DIR)$/iu.test(key)));
const planRef = await admitRef({ path: planPath, sha256 }, batch);
const plan = await json(planRef.path);
assert.equal(plan.schema, 'gg438-supplemental-invocation/v1');
assert.equal(plan.state, 'root-admitted-invocation');
assert.equal(plan.attempt, 'supplemental-attempt-1');
assert.deepEqual(plan.modules, modules);
const runtime = await currentNode();
assert.deepEqual(plan.node, { path: runtime.nodePath,
  sha256: 'dccc52de28d8df2ee22d2062424f8c563070d95d8ad70c54c4bf01d590dec14f' });
assert.equal(runtime.nodeSha256, plan.node.sha256);
assert.deepEqual(plan.powerShell, { path: psPath,
  sha256: '2a6769a3330dc1084d0154bfde7d164ab750ca7f700f313f9d417c1be78b2233', version: '7.6.9' });
await admitRef(plan.powerShell, undefined, true);
assert.deepEqual(plan.wrapper, { path: join(suite, 'launch.ps1'),
  sha256: '83514dd7b19d8bc298c287bcec75d8cf157f220a81fe9590741f1274b2922177' });
assert.deepEqual(plan.manifest, { path: join(suite, 'SHA256SUMS.txt'),
  sha256: '781c9738e289f0948ed5d8508c4c9dd3a227068cedd63debc447e298f8918795' });
await admitRef(plan.manifest, batch);
const admission = await admitRef(plan.admission, batch);
const cfg = await json(admission.path);
assert.equal(cfg.schema, 'gg438-supplemental-admission/v1');
assert.equal(cfg.attempt, plan.attempt);
assert.deepEqual(cfg.enabledModules, modules);
assert.equal(cfg.modules['launch.ps1'], plan.wrapper.sha256);
for (const value of ['admittedBy', 'admittedAt', 'schedule'].map((key) => cfg.rootAdmission[key]))
  assert(typeof value === 'string' && value.length && !value.includes('<ROOT'));
await assert.rejects(lstat(join(suite, 'attempts', plan.attempt)), { code: 'ENOENT' });
for (const name of modules)
  await assert.rejects(lstat(join(suite, 'receipts', plan.attempt + '-' + name)), { code: 'ENOENT' });
const self = await checkedRef(fileURLToPath(import.meta.url), undefined, batch);
assert.deepEqual(plan.invoker, self);
const out = outputPath(plan.outputDirectory, /^launcher-438-supplemental-invocation-01$/u);
await mkdir(out);
assert.equal(await realpath(out), out);
await save(out, 'requested.json', { at: now(), pid: process.pid, plan: planRef, ...plan,
  invoker: self, outerTimeoutMsPerModule: 2_100_000 });

async function invoke(module) {
  await admitRef(admission, batch);
  await admitRef(plan.node);
  const ps = await admitRef(plan.powerShell, undefined, true);
  const wrapper = await admitRef(plan.wrapper, batch);
  const dir = join(out, module);
  await mkdir(dir);
  const args = ['-NoProfile', '-NonInteractive', '-File', wrapper.path, '-Admission', admission.path,
    '-Sha256', admission.sha256, '-Module', module];
  await save(dir, 'requested.json', { at: now(), module, executable: plan.powerShell, args, cwd: suite });
  const child = spawn(ps.path, args, { cwd: suite, windowsHide: true, shell: false, stdio: ['ignore', 'pipe', 'pipe'] });
  const state = { pid: child.pid ?? null, spawnfile: child.spawnfile, spawnargs: child.spawnargs };
  const closed = Promise.withResolvers();
  const receipts = [];
  const recordEvent = (name, event) => receipts.push(save(dir, name + '.json', { pid: state.pid, ...event })
    .catch((error) => { state.receiptError = problem(error); }));
  child.once('spawn', () => { state.launch = { at: now() }; recordEvent('launch', state.launch); });
  child.once('error', (error) => { state.spawnError = problem(error); });
  child.once('exit', (code, signal) => { state.exit = { code, signal, at: now() }; recordEvent('exit', state.exit); });
  child.once('close', (code, signal) => { state.close = { code, signal, at: now() }; closed.resolve(); });
  const captures = {};
  const drains = ['stdout', 'stderr'].map((name) => {
    const stream = child[name];
    const receipt = (captures[name] = { path: join(dir, name + '.raw') });
    stream.once('end', () => { receipt.eof = now(); });
    return pipeline(stream, createWriteStream(receipt.path, { flags: 'wx' })).then(
      () => { receipt.writeClosed = now(); }, (error) => { receipt.error = problem(error); });
  });
  let timer;
  const disposition = await Promise.race([
    Promise.all([closed.promise, ...drains]).then(() => 'finished'),
    new Promise((resolve) => { timer = setTimeout(() => resolve('timeout'), 2_100_000); }),
  ]);
  clearTimeout(timer);
  await Promise.all(receipts);
  if (disposition === 'timeout') {
    await save(dir, 'timeout.json', { ...state, ...captures, at: now(), disposition: 'unverified-no-signal' });
    return { module, pid: state.pid, status: 'unverified-timeout' };
  }
  for (const receipt of Object.values(captures)) {
    if (receipt.eof && receipt.writeClosed && !receipt.error)
      Object.assign(receipt, await checkedRef(receipt.path, undefined, batch), { bytes: (await lstat(receipt.path)).size });
  }
  const complete = Boolean(state.pid && state.launch && state.exit && state.close &&
    state.exit.code === state.close.code && state.exit.signal === state.close.signal &&
    !state.spawnError && !state.receiptError && Object.values(captures).every(({ sha256 }) => sha256));
  await save(dir, 'close.json', { ...state, ...captures, complete });
  return { module, pid: state.pid, exitCode: state.exit?.code ?? null,
    status: !complete ? 'unverified' : state.exit.code === 0 && state.exit.signal === null ? 'passed' : 'wrapper-failed' };
}

const rows = [];
for (const name of modules) {
  const row = await invoke(name);
  rows.push(row);
  if (row.status !== 'passed') break;
}
const summary = { at: now(), rows, remaining: modules.slice(rows.length) };
await save(out, 'summary.json', summary);
console.log(JSON.stringify({ ...summary, output: out }));
if (rows.at(-1).status === 'unverified-timeout') process.exit(1);
process.exitCode = rows.length === modules.length && rows.every(({ status }) => status === 'passed') ? 0 : 1;
