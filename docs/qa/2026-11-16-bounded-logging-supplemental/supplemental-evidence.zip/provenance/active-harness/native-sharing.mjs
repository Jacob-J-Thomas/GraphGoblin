// #438 supplemental native ownership, sharing and unsafe-name cases: N-7/N-8/N-9, N-14, N-15,
// N-16, N-17, N-18, N-19/N-20, and the compiled launcher-log control for native C-1/C-2. Real
// Windows sharing denials come from finite holders with explicit ready/release markers.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { link, mkdir, readFile, stat, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import {
  admitSupplement, builtUrl, completeRecords, exclusiveOpen, fileState, LAUNCHER_RECORD, LAUNCHER_SLOT, logRecords,
  projectNode, RECORD, runCases, seedBytes, sha, SLOT, usersAce,
} from './common.mjs';

const job = await admitSupplement('native-sharing', process.argv.slice(2));
const { observe, refused } = job.lib.native;
const { startWork, releaseWork, traffic, workState } = job.lib.workload;
const checkout = job.binding.checkout;
const launcher = job.binding.launcher.path;
const mainJs = join(checkout, 'apps/api/dist/main.js');
const MR = await import(await builtUrl(job.binding, 'apps/api/dist/windows-log/managed-root.js'));
const limits = job.admission.limits.pressure;
const lastLauncher = async (root) => (await logRecords(join(root, 'launcher.log'))).at(-1);
const listening = (path, pid) => observe('listening record of ' + pid, async () =>
  (await logRecords(path)).some((r) => r.pid === pid && r.msg === 'GraphGoblin API listening'), 5000);
const light = async (path) => { const s = await stat(path, { bigint: true }); return { id: s.dev + ':' + s.ino, size: Number(s.size) }; };
const MALFORMED = '{ "Repo": ';
/** Two equal samples 400 ms apart: no batch is being appended when a baseline is taken. */
const quiet = (path) => observe('quiescent ' + path, async () => {
  const first = await light(path);
  await new Promise((resolve) => setTimeout(resolve, 400));
  const second = await light(path);
  return first.id === second.id && first.size === second.size;
}, 8000);

async function keys(ctx, label, dir, expect = 0) {
  const call = await ctx.helper('keys ' + label, ['--keys', dir], { expect });
  return JSON.parse(call.stdout);
}

async function oneWriterCase(ctx) {
  const install = await ctx.privateDir('install');
  const alias = await ctx.link(join(ctx.fixture, 'install-alias'), install, 'junction');
  const other = await ctx.privateDir('distinct-root');
  const [kInstall, kAlias, kOther] = [await keys(ctx, 'install', install), await keys(ctx, 'alias', alias), await keys(ctx, 'other', other)];
  assert.deepEqual([kAlias.path, kAlias.gatewayPipe, kAlias.launcherMutex], [kInstall.path, kInstall.gatewayPipe, kInstall.launcherMutex]);
  assert(kOther.gatewayPipe !== kInstall.gatewayPipe && kOther.launcherMutex !== kInstall.launcherMutex);
  const [nInstall, nAlias] = [await MR.resolveLogRoot(install), await MR.resolveLogRoot(alias)];
  assert.deepEqual([nInstall.pipeName, nAlias.pipeName, nAlias.path], [kInstall.gatewayPipe, kInstall.gatewayPipe, nInstall.path]);
  assert.deepEqual([String(nInstall.dev), String(nInstall.ino)], [kInstall.volume, kInstall.index], 'Node and Win32 identity widths differ');
  const digest = (text) => createHash('sha256').update(text, 'utf8').digest('hex').slice(0, 40);
  assert.equal(kInstall.gatewayPipe, '\\\\.\\pipe\\GraphGoblin.GatewayLog.' + digest('graphgoblin-gateway-log-root/v1\0dev=' + kInstall.volume + '\0ino=' + kInstall.index));
  assert.equal(kInstall.launcherMutex, 'Global\\GraphGoblin.LauncherLog.' + digest('graphgoblin-launcher-log-root/v1\0dev=' + kInstall.volume + '\0ino=' + kInstall.index));
  const config = ctx.config({ dataDir: await ctx.store('owner'), port: await ctx.port() });
  const owner = await ctx.boot('owner', launcher, await ctx.writeConfig(install, 'owner', config), config);
  const pid = owner.proof.health.pid;
  const active = join(install, 'gateway.log');
  const previous = join(install, 'gateway.log.1');
  await listening(active, pid);
  await quiet(active);
  const before = await fileState(active);
  const previousBefore = await fileState(previous);
  const contender = ctx.config({ dataDir: await ctx.store('alias-contender'), port: await ctx.port(), startup: 3 });
  await ctx.writeConfig(install, 'alias-contender', contender);
  const call = await ctx.launch('alias-contender', launcher, ['--config', join(alias, 'alias-contender.json'), '--ensure-gateway'], { expect: 1 });
  assert(call.stderr.includes('log folder is already in use'));
  const record = await lastLauncher(install);
  assert.equal(record.code, 'destination-in-use');
  assert([undefined, 70].includes(record.childExit));
  const route = record.childExit === undefined ? 'parent legacy-sharing refusal (live writable active)' : 'child reservation refusal (70)';
  const directConfig = ctx.config({ dataDir: await ctx.store('direct-contender'), port: await ctx.port() });
  const direct = await ctx.direct('direct-alias-contender', mainJs, [],
    ctx.gatewayEnv(directConfig, { GG_WINDOWS_LAUNCHER_LOG_DIR: alias }), { expect: 70 });
  assert.deepEqual([direct.stdoutBytes, direct.stderrBytes], [0, 0]);
  for (const cfg of [contender, directConfig]) assert(await refused(cfg.Port));
  assert.deepEqual(await ctx.proof(owner), owner.proof, 'owner identity, birth or store authority changed');
  const after = await fileState(active);
  assert.equal(after.id, before.id, 'active identity changed under contention');
  const bytes = await readFile(active);
  assert.equal(sha(bytes.subarray(0, before.size)), before.sha256, 'existing gateway bytes changed');
  const appended = completeRecords(bytes.subarray(before.size, bytes.lastIndexOf(10) + 1), RECORD);
  assert(appended.every((r) => r.value.pid === pid), 'a second process wrote the owned gateway pair');
  // The previous slot stays absent, or keeps its exact ID and bytes, alongside the active witness.
  assert.deepEqual(await fileState(previous), previousBefore, 'previous slot changed under contention');
  await ctx.drain(owner);
  const pipeRoot = await ctx.privateDir('pipe-root');
  const kPipe = await keys(ctx, 'pipe-root', pipeRoot);
  assert.equal((await MR.resolveLogRoot(pipeRoot)).pipeName, kPipe.gatewayPipe);
  const pipeConfig = ctx.config({ dataDir: await ctx.store('pipe-contender'), port: await ctx.port() });
  const pipeFile = await ctx.writeConfig(pipeRoot, 'pipe-contender', pipeConfig);
  const pipeRecord = await ctx.hold({ kind: 'pipe', name: 'gateway-pipe', pipe: kPipe.gatewayPipe, seconds: 90 }, async () => {
    const refusal = await ctx.launch('pipe-contender', launcher, ['--config', pipeFile, '--ensure-gateway'], { expect: 1 });
    assert(refusal.stderr.includes('log folder is already in use'));
    const value = await lastLauncher(pipeRoot);
    assert.deepEqual([value.code, value.childExit], ['destination-in-use', 70]);
    for (const name of ['gateway.log', 'gateway.log.1']) {
      assert.equal((await fileState(join(pipeRoot, name))).exists, false, 'refused child touched managed name ' + name);
    }
    assert(await refused(pipeConfig.Port));
    return value;
  });
  return { level: 'real native contention: live owner, junction alias, direct opt-in contender, cooperating pipe holder',
    keys: { install: kInstall, other: kOther.gatewayPipe }, aliasRoute: route, directExit: direct.exit.code, pipeRecord,
    previousSlot: previousBefore.exists ? { id: previousBefore.id, sha256: previousBefore.sha256 } : 'absent' };
}

async function partialCase(ctx) {
  const rows = [];
  const complete = seedBytes(4096, 'qa438-n14-complete');
  const boot = async (name, root) => {
    const config = ctx.config({ dataDir: await ctx.store(name), port: await ctx.port() });
    const current = await ctx.boot(name, launcher, await ctx.writeConfig(root, name, config), config);
    await listening(join(root, 'gateway.log'), current.proof.health.pid);
    return current;
  };
  for (const [name, fragment] of [['f0', [0xf0]], ['f09f', [0xf0, 0x9f]], ['f09f98', [0xf0, 0x9f, 0x98]], ['e282', [0xe2, 0x82]]]) {
    const root = await ctx.privateDir('partial-' + name);
    const active = join(root, 'gateway.log');
    await writeFile(active, Buffer.concat([complete, Buffer.from('{"msg":"qa438-partial-'), Buffer.from(fragment)]), { flag: 'wx' });
    const id = (await fileState(active)).id;
    const current = await boot('partial-' + name, root);
    const bytes = await readFile(active);
    assert(bytes.subarray(0, complete.length).equals(complete), 'complete prefix changed');
    assert(!bytes.includes('qa438-partial-'), 'incomplete record survived');
    completeRecords(bytes.subarray(0, bytes.lastIndexOf(10) + 1), RECORD);
    assert.equal((await fileState(active)).id, id);
    await ctx.drain(current);
    rows.push({ name, fragment, prefixBytes: complete.length });
  }
  const history = seedBytes(8192, 'qa438-n14-history');
  for (const [name, previousBytes, expected] of [['previous-only', history, history],
    ['previous-torn', Buffer.concat([history, Buffer.from('{"msg":"qa438-torn-€', 'utf8').subarray(0, -1)]), history]]) {
    const root = await ctx.privateDir(name);
    const previous = join(root, 'gateway.log.1');
    await writeFile(previous, previousBytes, { flag: 'wx' });
    const id = (await fileState(previous)).id;
    const current = await boot(name, root);
    const kept = await fileState(previous);
    assert.deepEqual([kept.id, kept.sha256], [id, sha(expected)]);
    await ctx.drain(current);
    rows.push({ name, previousSize: kept.size });
  }
  return { level: 'real native startup adoption of stopped roots', rows };
}

async function rotationDenialCase(ctx) {
  const root = await ctx.privateDir('install');
  const active = join(root, 'gateway.log');
  const previous = join(root, 'gateway.log.1');
  await writeFile(active, seedBytes(3 * 1024 * 1024, 'qa438-n15-history'), { flag: 'wx' });
  await writeFile(previous, '{"msg":"qa438-n15-previous"}\n', { flag: 'wx' });
  const config = ctx.config({ dataDir: await ctx.store('owner'), port: await ctx.port() });
  const owner = await ctx.boot('owner', launcher, await ctx.writeConfig(root, 'owner', config), config);
  const { health } = owner.proof;
  const work = await startWork({ port: owner.port, directory: await ctx.dir('work'), node: projectNode, definitionFormat: 4, observe },
    (state) => { owner.work = state; });
  const started = performance.now();
  let sent = 0;
  const budget = () => sent < limits.requests && performance.now() - started < limits.milliseconds;
  const burst = async () => {
    const count = Math.min(limits.batch, limits.requests - sent);
    await traffic(owner.port, health, count, limits.workers, sent);
    sent += count;
  };
  while (budget() && (await light(active)).size < SLOT - 128 * 1024) await burst();
  const nearCap = await light(active);
  assert(nearCap.size >= SLOT - 128 * 1024, 'did not approach the slot within the pressure budget');
  const previousBefore = await fileState(previous);
  const samples = [];
  const stuck = await ctx.hold({ kind: 'file', name: 'previous-without-delete-share', paths: [previous],
    access: 'Read', share: 'ReadWrite', seconds: 120 }, async () => {
    const holdStart = performance.now();
    let last;
    while (budget() && performance.now() - holdStart < 30_000) {
      await burst();
      const sample = { ...(await light(active)), at: performance.now() - holdStart, sent };
      samples.push(sample);
      assert.equal(sample.id, nearCap.id, 'active rotated while rename was denied');
      assert(sample.size <= SLOT && (!last || sample.size >= last.size), 'active exceeded the cap or was truncated');
      if (last && sample.size === last.size && sample.size > SLOT - 64 * 1024 && sample.at - last.firstAt >= 1000) return sample;
      if (!last || sample.size !== last.size) last = { ...sample, firstAt: sample.at };
    }
    throw new Error('did not observe a held rotation within 30 s of pressure');
  });
  assert.deepEqual(await fileState(previous), previousBefore, 'previous changed while held');
  assert.equal((await workState(owner.port, work)).status, 'running');
  const releaseStart = performance.now();
  let rotated;
  while (budget() && performance.now() - releaseStart < 45_000) {
    await burst();
    const moved = await light(previous);
    if (moved.id === stuck.id) { rotated = { previous: moved, active: await light(active), afterMs: performance.now() - releaseStart }; break; }
  }
  assert(rotated, 'no rotation after the holder released');
  assert.notEqual(rotated.active.id, stuck.id);
  assert.deepEqual(await ctx.proof(owner), owner.proof, 'serving PID, birth or store authority changed');
  await releaseWork(work);
  await observe('held work succeeds', async () => (await workState(owner.port, work)).status === 'succeeded', 15_000);
  await ctx.drain(owner);
  await ctx.put('n15-samples.json', { nearCap, samples, stuck, rotated, sent, elapsedMs: performance.now() - started });
  assert(sent <= limits.requests, 'request budget exceeded');
  return { level: 'real Windows sharing denial on a live launcher-started gateway', sent, stuckSize: stuck.size, rotationAfterMs: rotated.afterMs };
}

async function heldActiveCase(ctx) {
  const root = await ctx.privateDir('install');
  const active = join(root, 'gateway.log');
  await writeFile(active, seedBytes(8192, 'qa438-n16-history'), { flag: 'wx' });
  const before = await fileState(active);
  const config = ctx.config({ dataDir: await ctx.store('native'), port: await ctx.port() });
  const file = await ctx.writeConfig(root, 'held-active', config);
  const directConfig = ctx.config({ dataDir: await ctx.store('direct'), port: await ctx.port() });
  const result = await ctx.hold({ kind: 'file', name: 'active-read-share-read', paths: [active], access: 'Read', share: 'Read', seconds: 120 }, async () => {
    const call = await ctx.launch('held-active', launcher, ['--config', file, '--ensure-gateway'], { expect: 1 });
    const record = await lastLauncher(root);
    assert.equal(record.code, 'destination-unavailable', 'held read-share active was not classified unsafe/unavailable');
    assert.equal(record.childExit, 71, 'expected the reached child admission refusal (71); parent refusal would need its own classification');
    assert(call.stderr.includes('log folder is unsafe or unavailable'));
    const direct = await ctx.direct('direct-held-active', mainJs, [],
      ctx.gatewayEnv(directConfig, { GG_WINDOWS_LAUNCHER_LOG_DIR: root }), { expect: 71 });
    return { record, directExit: direct.exit.code };
  });
  assert.deepEqual(await fileState(active), before);
  await exclusiveOpen(ctx, [active]);
  for (const cfg of [config, directConfig]) assert(await refused(cfg.Port));
  return { level: 'real Windows read-only sharing on a stopped root', ...result };
}

async function launcherPairCase(ctx) {
  const root = await ctx.privateDir('install');
  const active = join(root, 'launcher.log');
  const previous = join(root, 'launcher.log.1');
  await writeFile(active, seedBytes(LAUNCHER_SLOT, 'qa438-n17-active'), { flag: 'wx' });
  await writeFile(previous, seedBytes(LAUNCHER_SLOT, 'qa438-n17-previous'), { flag: 'wx' });
  const bad = await ctx.writeConfig(root, 'malformed', MALFORMED);
  const before = { active: await fileState(active), previous: await fileState(previous) };
  const presented = [];
  await ctx.hold({ kind: 'file', name: 'launcher-pair', paths: [active, previous], access: 'Read', share: 'Read', seconds: 120 }, async () => {
    for (const attempt of [1, 2]) {
      const call = await ctx.launch('malformed-held-' + attempt, launcher, ['--config', bad, '--ensure-gateway'], { expect: 1 });
      assert(call.stderr.includes('unexpected launcher error during the configuration step') && call.stderr.includes('Configuration: ' + bad));
      presented.push(call.stderr);
      assert.deepEqual({ active: await fileState(active), previous: await fileState(previous) }, before, 'held pair changed');
    }
  });
  await ctx.launch('malformed-released', launcher, ['--config', bad, '--ensure-gateway'], { expect: 1 });
  const after = { active: await fileState(active), previous: await fileState(previous) };
  assert.deepEqual([after.previous.id, after.previous.sha256], [before.active.id, before.active.sha256], 'active did not rotate onto previous');
  const records = completeRecords(await readFile(active), LAUNCHER_RECORD);
  assert.equal(records.length, 1);
  assert.deepEqual([records[0].value.stage, records[0].value.code, records[0].value.message],
    ['configuration', 'unexpected', 'unexpected launcher error']);
  completeRecords(await readFile(previous), LAUNCHER_RECORD);
  return { level: 'real Windows sharing denial of both launcher slots', presentedWithoutDiskRecord: presented.length, after };
}

async function mutexCase(ctx) {
  const root = await ctx.privateDir('install');
  const alias = await ctx.link(join(ctx.fixture, 'install-alias'), root, 'junction');
  await ctx.writeConfig(root, 'malformed', MALFORMED);
  const viaAlias = join(alias, 'malformed.json');
  const timed = async (label) => {
    const started = performance.now();
    const call = await ctx.launch(label, launcher, ['--config', viaAlias, '--ensure-gateway'], { expect: 1 });
    assert(call.stderr.includes('unexpected launcher error during the configuration step'));
    return { ms: performance.now() - started, call };
  };
  const free1 = await timed('malformed-free-1');
  const one = await logRecords(join(root, 'launcher.log'));
  assert.equal(one.length, 1);
  const held = await ctx.hold({ kind: 'mutex', name: 'launcher-mutex', root, seconds: 60 }, async (holder) => {
    assert.match(holder.readyText, /^Global\\GraphGoblin\.LauncherLog\.[a-f0-9]{40}$/u);
    const before = await fileState(join(root, 'launcher.log'));
    const result = await timed('malformed-held');
    assert.deepEqual(await fileState(join(root, 'launcher.log')), before, 'a contended launcher record was written');
    return { ...result, mutex: holder.readyText };
  });
  const free2 = await timed('malformed-free-2');
  assert.equal((await logRecords(join(root, 'launcher.log'))).length, 2, 'record not written after release');
  const baseline = (free1.ms + free2.ms) / 2;
  const extra = held.ms - baseline;
  assert(extra >= 150 && extra <= 2000, 'held launcher took ' + Math.round(extra) + ' ms beyond the uncontended baseline');
  return { level: 'real cross-process mutex contention through a junction spelling', freeMs: [free1.ms, free2.ms], heldMs: held.ms,
    extraMs: extra, mutex: held.mutex };
}

async function unsafeCase(ctx) {
  const rows = [];
  const targets = await ctx.dir('targets');
  let index = 0;
  const sentinel = async () => {
    const path = join(targets, 'sentinel-' + index++ + '.log');
    await writeFile(path, '{"msg":"qa438 protected sentinel"}\n', { flag: 'wx' });
    return path;
  };
  const variants = [
    ['gateway-previous-hardlink', 'gateway.log.1', async (path) => link(await sentinel(), path)],
    ['gateway-active-hardlink', 'gateway.log', async (path) => link(await sentinel(), path)],
    ['gateway-active-junction', 'gateway.log', async (path) => { const dir = join(targets, 'junction-target-' + index++); await mkdir(dir); await ctx.link(path, dir, 'junction'); }],
    ['gateway-active-directory', 'gateway.log', async (path) => mkdir(path)],
    ['gateway-active-file-symlink', 'gateway.log', async (path) => ctx.link(path, await sentinel(), 'file')],
    ['gateway-active-dangling-symlink', 'gateway.log', async (path) => ctx.link(path, join(targets, 'qa438-absent-target.log'), 'file')],
    ['root-users-ace', null, null],
  ];
  for (const [name, managed, make] of variants) {
    const root = await ctx.privateDir(name);
    const entry = managed && join(root, managed);
    if (make) {
      try { await make(entry); } catch (error) {
        if (error.code !== 'EPERM') throw error;
        rows.push({ name, notExercised: 'symbolic-link creation refused with EPERM; no claim' });
        continue;
      }
    }
    const config = ctx.config({ dataDir: join(ctx.storesDir, 'never-' + name), port: await ctx.port() });
    const file = await ctx.writeConfig(root, name, config);
    if (name === 'root-users-ace') {
      // Exact pre-change SDDL and its restoration are registered before the ACE is added, so a
      // failure after the set still removes the ACE and verifies the original descriptor.
      const original = (await usersAce(ctx, root, 'read')).before;
      ctx.aclRestores.push(async () => {
        const removed = await usersAce(ctx, root, 'remove');
        assert.equal(removed.after, original, 'fixture-only ACL not restored');
        return removed;
      });
      const added = await usersAce(ctx, root, 'add');
      assert.equal(added.before, original, 'fixture ACL changed before the Users ACE was added');
    }
    const watched = [entry, join(root, 'launcher.log')].filter(Boolean);
    const before = { node: await Promise.all(watched.map(fileState)), windows: await ctx.windowsMeta(watched) };
    const call = await ctx.launch(name, launcher, ['--config', file, '--ensure-gateway'], { expect: 1 });
    assert(call.stderr.includes('log folder is unsafe or unavailable'), name + ' presentation');
    const direct = await ctx.direct('direct-' + name, mainJs, [],
      ctx.gatewayEnv({ ...config, DataDir: join(ctx.storesDir, 'never-direct-' + name) }, { GG_WINDOWS_LAUNCHER_LOG_DIR: root }), { expect: 71 });
    const record = name === 'root-users-ace' ? undefined : await lastLauncher(root);
    if (record) assert.deepEqual([record.code, record.childExit], ['destination-unavailable', undefined]);
    else assert.equal((await fileState(join(root, 'launcher.log'))).exists, false, 'launcher wrote into a non-private root');
    if (entry) {
      assert.deepEqual(await fileState(entry), before.node[0], name + ' entry changed');
      assert.deepEqual((await ctx.windowsMeta([entry]))[0], before.windows[0], name + ' no-follow metadata changed');
    }
    assert(await refused(config.Port));
    rows.push({ name, launcher: record?.code ?? 'stderr-only', directExit: direct.exit.code, before });
  }
  for (let i = 0; i < index; i++) {
    const path = join(targets, 'sentinel-' + i + '.log');
    try { assert.equal(await readFile(path, 'utf8'), '{"msg":"qa438 protected sentinel"}\n'); } catch (error) { if (error.code !== 'ENOENT') throw error; }
  }
  // Launcher pair: an unsafe launcher.log still yields the closed stderr presentation.
  for (const [name, make] of [['launcher-hardlink', async (path) => link(await sentinel(), path)],
    ['launcher-junction', async (path) => { const dir = join(targets, 'launcher-junction-target'); await mkdir(dir); await ctx.link(path, dir, 'junction'); }]]) {
    const root = await ctx.privateDir(name);
    const entry = join(root, 'launcher.log');
    await make(entry);
    const bad = await ctx.writeConfig(root, 'malformed', MALFORMED);
    const before = [await fileState(entry), (await ctx.windowsMeta([entry]))[0]];
    const call = await ctx.launch(name, launcher, ['--config', bad, '--ensure-gateway'], { expect: 1 });
    assert(call.stderr.includes('unexpected launcher error during the configuration step'));
    assert.deepEqual([await fileState(entry), (await ctx.windowsMeta([entry]))[0]], before, name + ' changed');
    assert.equal((await fileState(join(root, 'launcher.log.1'))).exists, false);
    rows.push({ name, presentation: 'stderr', unchanged: true });
  }
  const exercised = rows.filter((row) => !row.notExercised).map((row) => row.name);
  return { level: 'real native refusals of unsafe names; broad ACL only on an exact owned fixture; foreign SID not exercised', rows,
    exercised, skippedVariants: rows.filter((row) => row.notExercised).map((row) => row.name),
    ...(exercised.length === 0 ? { notExercised: 'no variant exercised' } : {}) };
}

async function launcherLogControlCase(ctx) {
  const edges = JSON.parse((await ctx.helper('record edges', ['--record-edges'])).stdout);
  assert.equal(edges.schema, 'gg438-launcher-record-edges/v1');
  const slots = JSON.parse((await ctx.helper('slot edges', ['--slot-edges', await ctx.dir('slot-edges')])).stdout);
  assert.equal(slots.schema, 'gg438-launcher-slot-edges/v1');
  await ctx.put('launcher-record-edges.json', edges);
  await ctx.put('launcher-slot-edges.json', slots);
  return { level: 'controlled compiled control around exact frozen LauncherLog.Build/Append', rows: edges.rows.length + slots.rows.length };
}

await runCases(job, [
  { id: 'c1-c2-launcher-log-control', level: 'controlled-native', criteria: ['C-1', 'C-2'], run: launcherLogControlCase },
  { id: 'n7-n8-n9-one-writer', level: 'native', criteria: ['N-7', 'N-8', 'N-9'], run: oneWriterCase },
  { id: 'n14-partial-utf8', level: 'native', criteria: ['N-14'], run: partialCase },
  { id: 'n16-held-active-read', level: 'native', criteria: ['N-16'], run: heldActiveCase },
  { id: 'n17-launcher-pair-held', level: 'native', criteria: ['N-17'], run: launcherPairCase },
  { id: 'n18-launcher-mutex', level: 'native', criteria: ['N-18'], run: mutexCase },
  { id: 'n19-n20-unsafe-names', level: 'native', criteria: ['N-19', 'N-20'], run: unsafeCase },
  { id: 'n15-live-rotation-denial', level: 'native', criteria: ['N-15'], run: rotationDenialCase },
]);
