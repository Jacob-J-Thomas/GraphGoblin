// #438 supplemental controls C-1, C-2 (gateway), C-3, C-5 and C-7 on the exact built production
// writer. Only the exported nodeLogFileSystem is wrapped (createSeam) and, for consecutive-fault
// bookkeeping only, the documented `schedule` option. Files, handles and renames are real.
import assert from 'node:assert/strict';
import { link, readFile, readdir, rename, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import {
  admitSupplement, builtUrl, completeRecords, createSeam, exactRecord, fileState, gate, injected,
  PENDING, RECORD, runCases, seedBytes, sha, SLOT,
} from './common.mjs';

const job = await admitSupplement('writer-controls', process.argv.slice(2));
const W = await import(await builtUrl(job.binding, 'apps/api/dist/windows-log/gateway-log-writer.js'));
const { observe } = job.lib.native;
assert.deepEqual([W.GATEWAY_LOG_SLOT_BYTES, W.GATEWAY_LOG_RECORD_BYTES, W.GATEWAY_LOG_PENDING_BYTES,
  W.GATEWAY_LOG_EXIT_FLUSH_MS, W.GATEWAY_LOG_MAX_FAULTS, [...W.GATEWAY_LOG_BACKOFF_MS]],
[SLOT, RECORD, PENDING, 250, 8, [1000, 2000, 4000, 8000, 16000, 32000, 60000]]);
const MARKER_MSG = 'gateway log record omitted: it exceeded the 65536-byte record limit';
const CHARS = ['é', '€', '\u{1F600}'];
const cp = (ch) => 'u' + ch.codePointAt(0).toString(16);
const line = (value) => JSON.stringify(value) + '\n';
const names = (root) => ({ active: join(root, 'gateway.log'), previous: join(root, 'gateway.log.1') });

async function openWriter(root, plan = {}, options = {}) {
  const seam = createSeam(W.nodeLogFileSystem, SLOT, plan);
  const writer = await W.openGatewayLog({ root, fs: seam.fs, observe: seam.observe, ...options });
  return { seam, writer };
}

function manualSchedule() {
  const calls = [];
  return {
    calls,
    schedule: (callback, ms) => {
      const row = { ms, callback, fired: false, cancelled: false };
      calls.push(row);
      return { cancel: () => { row.cancelled = true; } };
    },
    fire(ms) {
      const row = calls.findLast((item) => !item.fired && !item.cancelled);
      assert(row, 'no pending scheduled resume');
      assert.equal(row.ms, ms);
      row.fired = true;
      row.callback();
    },
  };
}

const waitEvent = (seam, label, predicate) => observe(label, () => seam.events.find(predicate), 5000);
const idle = (writer, seam) => observe('writer idle', () => writer.pendingBytes === 0 && seam.inFlight === 0, 5000);

async function finish(ctx, name, seam) {
  await ctx.put(name + '-seam.json', { ops: seam.ops, events: seam.events, maxInFlight: seam.maxInFlight });
  assert.deepEqual(seam.preWriteViolations(), [], 'A reached write could exceed the 4 MiB slot');
  assert(seam.maxInFlight <= 1, 'More than one gateway file operation was in flight');
}

function straddle(ch) {
  const prefix = '{"level":30,"msg":"qa438-c1-straddle","pad":"';
  const width = Buffer.byteLength(ch);
  const start = 65536 - Math.floor(width / 2);
  const text = prefix + 'a'.repeat(start - prefix.length) + ch + '"}\n';
  assert(start < 65536 && start + width > 65536, 'character must cross the would-be cutoff');
  assert.equal(Buffer.from(text).subarray(start, start + width).toString('utf8'), ch);
  return text;
}

async function c1(ctx) {
  const root = await ctx.dir('c1');
  const { seam, writer } = await openWriter(root);
  const inputs = [];
  for (const total of [65535, 65536]) {
    for (const ch of CHARS) inputs.push({ name: 'fit-' + total + '-' + cp(ch), text: exactRecord(total, 'qa438-c1-fit', ch), verbatim: true });
  }
  inputs.push({ name: 'over-65537', text: exactRecord(65537, 'qa438-c1-over'), verbatim: false });
  for (const ch of CHARS) inputs.push({ name: 'straddle-' + cp(ch), text: straddle(ch), verbatim: false });
  inputs.push({ name: 'no-lf-65535', text: exactRecord(65536, 'qa438-c1-nolf').slice(0, -1), verbatim: true });
  inputs.push({ name: 'no-lf-65536', text: exactRecord(65537, 'qa438-c1-nolf-over').slice(0, -1), verbatim: false });
  inputs.push({ name: 'lone-surrogate-65536', text: exactRecord(65536, 'qa438-c1-surrogate', '\uD800'), verbatim: true });
  inputs.push({ name: 'sentinel', text: line({ level: 30, msg: 'qa438-c1-sentinel' }), verbatim: true });
  const rows = [];
  for (const input of inputs) {
    const before = writer.pendingBytes;
    const started = performance.now();
    const accepted = writer.write(input.text);
    const callMs = performance.now() - started;
    rows.push({ name: input.name, inputBytes: Buffer.byteLength(input.text), accepted, charge: writer.pendingBytes - before, callMs });
    assert(await writer.settle(5000), 'writer did not settle after ' + input.name);
  }
  await writer.close();
  await finish(ctx, 'c1', seam);
  const bytes = await readFile(names(root).active);
  await ctx.raw('c1-gateway.log', bytes);
  const records = completeRecords(bytes, RECORD);
  assert.equal(records.length, inputs.length);
  for (const [index, input] of inputs.entries()) {
    const row = rows[index];
    const record = records[index];
    row.written = record.length;
    assert.equal(row.accepted, true, input.name);
    assert.equal(row.charge, record.length, 'pending charge differs from encoded bytes for ' + input.name);
    if (input.verbatim) {
      const expected = Buffer.from(input.text.endsWith('\n') ? input.text : input.text + '\n', 'utf8');
      assert(record.bytes.equals(expected), input.name + ' was not written verbatim');
      assert(record.length <= RECORD);
    } else {
      assert.deepEqual(Object.keys(record.value).sort(), ['level', 'msg', 'pid', 'time']);
      assert.deepEqual([record.value.level, record.value.pid, record.value.msg], [40, process.pid, MARKER_MSG]);
      assert.equal(record.bytes.toString('utf8'), W.oversizedMarker(record.value.time, process.pid));
      assert(!record.bytes.includes('qa438-c1'), 'marker carried source payload');
    }
  }
  await ctx.put('c1-rows.json', rows);
  return { level: 'controlled production writer, real file I/O', records: rows.length };
}

async function c2(ctx) {
  const L = 1000;
  const rows = [];
  for (const d of [-1, 0, 1]) {
    const root = await ctx.dir('c2/offset' + (d < 0 ? 'm1' : d === 0 ? '0' : 'p1'));
    const { active, previous } = names(root);
    const seed = seedBytes(SLOT - L + d, 'qa438-c2-seed');
    const sentinel = Buffer.from(line({ msg: 'qa438-c2-previous-sentinel' }));
    await writeFile(active, seed, { flag: 'wx' });
    await writeFile(previous, sentinel, { flag: 'wx' });
    const before = { active: await fileState(active), previous: await fileState(previous) };
    const record = exactRecord(L, 'qa438-c2-next');
    const { seam, writer } = await openWriter(root);
    assert.equal(writer.size, SLOT - L + d);
    assert(writer.write(record));
    assert(await writer.settle(5000));
    await writer.close();
    await finish(ctx, 'c2-' + d, seam);
    const after = { active: await fileState(active), previous: await fileState(previous) };
    const rotations = seam.events.filter((event) => event.type === 'rotate');
    const adopt = seam.events.filter((event) => event.type === 'adopt').map((event) => [event.slot, event.action, event.sizeBefore, event.sizeAfter]);
    assert.deepEqual(adopt, [['previous', 'kept', sentinel.length, sentinel.length], ['active', 'kept', SLOT - L + d, SLOT - L + d]]);
    if (d <= 0) {
      assert.deepEqual(rotations, []);
      assert.equal(after.active.id, before.active.id);
      assert.equal(after.active.size, SLOT - L + d + L);
      assert.equal(after.active.sha256, sha(Buffer.concat([seed, Buffer.from(record)])));
      assert.deepEqual(after.previous, before.previous);
    } else {
      assert.deepEqual(rotations.map((event) => [event.step, event.result]), [['close', 'complete'], ['rename', 'complete'], ['create', 'complete']]);
      assert.equal(after.previous.id, before.active.id, 'active identity did not move to previous');
      assert.equal(after.previous.sha256, sha(seed));
      assert.notEqual(after.active.id, before.active.id);
      assert.equal(after.active.sha256, sha(Buffer.from(record)));
    }
    assert.deepEqual((await readdir(root)).sort(), ['gateway.log', 'gateway.log.1']);
    rows.push({ d, before, after, adopt, rotations: rotations.length });
  }
  // Oversized stopped history is replaced under ownership; incomplete tails are repaired.
  const big = await ctx.dir('c2/oversized');
  await writeFile(names(big).active, seedBytes(SLOT + 1, 'qa438-c2-old-active'), { flag: 'wx' });
  await writeFile(names(big).previous, seedBytes(SLOT + 1, 'qa438-c2-old-previous'), { flag: 'wx' });
  const bigBefore = { active: await fileState(names(big).active), previous: await fileState(names(big).previous) };
  const replaced = await openWriter(big);
  assert(replaced.writer.write(line({ msg: 'qa438-c2-after-oversized' })));
  assert(await replaced.writer.settle(5000));
  await replaced.writer.close();
  await finish(ctx, 'c2-oversized', replaced.seam);
  assert.deepEqual(replaced.seam.events.filter((e) => e.type === 'adopt').map((e) => [e.slot, e.action, e.sizeBefore, e.sizeAfter]),
    [['previous', 'replaced-oversized', SLOT + 1, 0], ['active', 'replaced-oversized', SLOT + 1, 0]]);
  const bigAfter = { active: await fileState(names(big).active), previous: await fileState(names(big).previous) };
  assert.equal(bigAfter.previous.id, bigBefore.previous.id);
  assert.equal(bigAfter.previous.size, 0);
  assert.equal(bigAfter.active.id, bigBefore.active.id);
  assert.equal((await readFile(names(big).active, 'utf8')), line({ msg: 'qa438-c2-after-oversized' }));
  const torn = await ctx.dir('c2/tail');
  const complete = seedBytes(10_000, 'qa438-c2-tail');
  await writeFile(names(torn).active, Buffer.concat([complete, Buffer.from('{"msg":"qa438-partial-é', 'utf8').subarray(0, -1)]), { flag: 'wx' });
  await writeFile(names(torn).previous, Buffer.concat([complete, Buffer.from('{"msg":"cut')]), { flag: 'wx' });
  const repaired = await openWriter(torn);
  await repaired.writer.close();
  await finish(ctx, 'c2-tail', repaired.seam);
  assert.deepEqual(repaired.seam.events.filter((e) => e.type === 'adopt').map((e) => [e.slot, e.action, e.sizeAfter]),
    [['previous', 'tail-repaired', complete.length], ['active', 'tail-repaired', complete.length]]);
  for (const path of Object.values(names(torn))) assert((await readFile(path)).equals(complete));
  await ctx.put('c2-rows.json', { rows, bigBefore, bigAfter });
  return { level: 'controlled production writer, real file I/O', offsets: [-1, 0, 1] };
}

async function stalledWriter(ctx, name, ms = 10_000) {
  const root = await ctx.dir('c3/' + name);
  const stall = gate(ms);
  const { seam, writer } = await openWriter(root, {
    write: async ({ handle, buffer, offset, length, position, n, row }) => {
      if (n === 1) { stall.reachedAt = performance.now(); row.stalled = true; await stall.promise; }
      return handle.write(buffer, offset, length, position);
    },
  });
  const reached = () => observe('first write in flight', () => seam.ops.some((row) => row.op === 'handle.write' && row.n === 1 && row.endMs === undefined), 3000);
  return { root, stall, seam, writer, reached };
}

async function c3(ctx) {
  const out = {};
  // A: one 64 KiB write in flight plus three queued records reach exactly 256 KiB; more drops.
  {
    const { root, stall, seam, writer, reached } = await stalledWriter(ctx, 'saturate');
    const records = [1, 2, 3, 4].map((i) => exactRecord(65536, 'qa438-c3-r' + i));
    const calls = [];
    for (const [index, text] of records.entries()) {
      const started = performance.now();
      calls.push({ index, accepted: writer.write(text), ms: performance.now() - started, pending: writer.pendingBytes });
      if (index === 0) await reached();
    }
    assert.deepEqual(calls.map((call) => call.accepted), [true, true, true, true]);
    assert.equal(writer.pendingBytes, PENDING);
    const extra = line({ msg: 'x' });
    const dropped = writer.write(extra);
    assert.equal(dropped, false);
    assert.equal(writer.pendingBytes, PENDING);
    assert(seam.events.some((e) => e.type === 'drop' && e.reason === 'pending-limit' && e.bytes === Buffer.byteLength(extra)));
    assert.equal(stall.released, false, 'every call returned while the file write was still held');
    stall.open();
    assert(await writer.settle(5000));
    assert.equal(writer.pendingBytes, 0);
    const next = line({ level: 30, msg: 'qa438-c3-after-drop' });
    assert(writer.write(next));
    const charge = writer.pendingBytes;
    assert(await writer.settle(5000));
    await writer.close();
    await finish(ctx, 'c3-saturate', seam);
    const written = completeRecords(await readFile(names(root).active), RECORD);
    assert.equal(written.length, 6);
    records.forEach((text, index) => assert(written[index].bytes.equals(Buffer.from(text))));
    const summary = written[4];
    assert.deepEqual(Object.keys(summary.value).sort(), ['dropped', 'level', 'msg', 'pid', 'time']);
    assert.deepEqual([summary.value.msg, summary.value.dropped, summary.value.pid], ['gateway log records dropped', 1, process.pid]);
    assert.equal(summary.bytes.toString(), W.dropSummary(summary.value.time, process.pid, 1));
    assert.equal(charge, summary.length + Buffer.byteLength(next));
    assert(written[5].bytes.equals(Buffer.from(next)));
    assert.deepEqual(seam.ops.filter((row) => row.op === 'handle.write').map((row) => row.length), [65536, 196608, summary.length + Buffer.byteLength(next)]);
    out.saturate = { calls, charge, summaryBytes: summary.length };
  }
  // B: exact +1 boundary against the combined in-flight and queued bytes.
  for (const [name, queued, expected] of [['fits', [65536, 65536, 64536], true], ['plus-one', [65536, 65536, 64537], false]]) {
    const { stall, seam, writer, reached } = await stalledWriter(ctx, name);
    assert(writer.write(exactRecord(65536, 'qa438-c3-first')));
    await reached();
    for (const size of queued) assert(writer.write(exactRecord(size, 'qa438-c3-q')));
    const before = writer.pendingBytes;
    assert.equal(before, 65536 + queued.reduce((a, b) => a + b, 0));
    const probe = exactRecord(1000, 'qa438-c3-probe');
    assert.equal(writer.write(probe), expected);
    assert.equal(writer.pendingBytes, expected ? PENDING : before);
    stall.open();
    assert(await writer.settle(5000));
    await writer.close();
    await finish(ctx, 'c3-' + name, seam);
    out[name] = { before, accepted: expected };
  }
  // C: the fixed marker is what is charged for an oversized record while I/O is held.
  {
    const { root, stall, seam, writer, reached } = await stalledWriter(ctx, 'marker');
    assert(writer.write(line({ msg: 'qa438-c3-held' })));
    await reached();
    const before = writer.pendingBytes;
    assert(writer.write(exactRecord(70_000, 'qa438-c3-oversize')));
    const charge = writer.pendingBytes - before;
    stall.open();
    assert(await writer.settle(5000));
    await writer.close();
    await finish(ctx, 'c3-marker', seam);
    const written = completeRecords(await readFile(names(root).active), RECORD);
    assert.equal(written[1].value.msg, MARKER_MSG);
    assert.equal(charge, written[1].length);
    assert(!written[1].bytes.includes('qa438-c3-oversize'));
    out.marker = { charge };
  }
  return { level: 'controlled production writer, held real write', ...out };
}

async function seeded(ctx, rel, activeBytes, previousBytes) {
  const root = await ctx.dir(rel);
  const { active, previous } = names(root);
  await writeFile(active, activeBytes, { flag: 'wx' });
  if (previousBytes) await writeFile(previous, previousBytes, { flag: 'wx' });
  return { root, active, previous };
}

async function c5(ctx) {
  const out = {};
  const record = (tag) => exactRecord(1000, 'qa438-c5-' + tag);
  // a: ENOSPC before any byte is written. Real spare capacity remains; the code is injected.
  {
    const seed = seedBytes(8192, 'qa438-c5-seed');
    const { root, active } = await seeded(ctx, 'c5/enospc', seed);
    const manual = manualSchedule();
    let pending = 1;
    const { seam, writer } = await openWriter(root, { write: async (a) => {
      if (pending-- > 0) throw injected('ENOSPC');
      return a.handle.write(a.buffer, a.offset, a.length, a.position);
    } }, { schedule: manual.schedule });
    assert(writer.write(record('one')));
    await waitEvent(seam, 'ENOSPC suspension', (e) => e.type === 'suspend');
    const failed = seam.events.find((e) => e.type === 'write');
    assert.deepEqual([failed.result, failed.code, failed.bytesWritten], ['failed', 'ENOSPC', 0]);
    assert(!seam.events.some((e) => e.type === 'rollback'));
    assert.deepEqual(seam.events.find((e) => e.type === 'suspend'), { ...seam.events.find((e) => e.type === 'suspend'), faults: 1, delayMs: 1000 });
    assert.equal((await fileState(active)).sha256, sha(seed));
    assert.equal(writer.write(record('two')), false);
    manual.fire(1000);
    assert.equal(writer.state, 'open');
    assert(writer.write(record('three')));
    await idle(writer, seam);
    await writer.close();
    await finish(ctx, 'c5-enospc', seam);
    const tail = completeRecords((await readFile(active)).subarray(seed.length), RECORD);
    assert.deepEqual([tail[0].value.msg, tail[0].value.dropped, tail[1].value.msg], ['gateway log records dropped', 2, 'qa438-c5-three']);
    out.enospc = { schedule: manual.calls.map((c) => c.ms) };
  }
  // b: a real short write, then the writer's ordinary truncate rollback.
  {
    const seed = seedBytes(8192, 'qa438-c5-seed');
    const { root, active } = await seeded(ctx, 'c5/short-write', seed);
    let first = true;
    const { seam, writer } = await openWriter(root, { write: async ({ handle, buffer, offset, length, position, row }) => {
      if (!first) return handle.write(buffer, offset, length, position);
      first = false;
      const result = await handle.write(buffer, offset, length - 7, position);
      row.realSizeAfterShortWrite = Number((await handle.stat()).size);
      return result;
    } }, { schedule: manualSchedule().schedule });
    assert(writer.write(record('short')));
    await waitEvent(seam, 'short-write suspension', (e) => e.type === 'suspend');
    const short = seam.ops.find((row) => row.op === 'handle.write');
    assert.equal(short.realSizeAfterShortWrite, seed.length + 1000 - 7, 'the partial bytes were not actually written');
    assert.deepEqual(seam.events.find((e) => e.type === 'write'), { ...seam.events.find((e) => e.type === 'write'), result: 'partial', bytesWritten: 993 });
    assert.deepEqual(seam.events.find((e) => e.type === 'rollback'), { ...seam.events.find((e) => e.type === 'rollback'), size: seed.length, result: 'complete' });
    assert.equal((await fileState(active)).sha256, sha(seed));
    await writer.close();
    await finish(ctx, 'c5-short-write', seam);
    out.shortWrite = { partialSize: short.realSizeAfterShortWrite };
  }
  // c: short write whose rollback fails: the target is disabled, then safely repaired on reopen.
  {
    const seed = seedBytes(8192, 'qa438-c5-seed');
    const { root, active } = await seeded(ctx, 'c5/rollback-failure', seed);
    let first = true;
    const { seam, writer } = await openWriter(root, {
      write: async ({ handle, buffer, offset, length, position }) => {
        if (!first) return handle.write(buffer, offset, length, position);
        first = false;
        return handle.write(buffer, offset, length - 7, position);
      },
      truncate: async () => { throw injected('EIO'); },
    }, { schedule: manualSchedule().schedule });
    assert(writer.write(record('torn')));
    await waitEvent(seam, 'rollback-failure disable', (e) => e.type === 'disable');
    assert.equal(seam.events.find((e) => e.type === 'disable').reason, 'rollback-failed');
    assert.equal(writer.state, 'disabled');
    assert.equal(writer.write(record('after')), false);
    assert.equal((await fileState(active)).size, seed.length + 993);
    await writer.close();
    await finish(ctx, 'c5-rollback-failure', seam);
    const reopened = await openWriter(root);
    assert.deepEqual(reopened.seam.events.filter((e) => e.type === 'adopt' && e.slot === 'active').map((e) => [e.action, e.sizeBefore, e.sizeAfter]),
      [['tail-repaired', seed.length + 993, seed.length]]);
    assert(reopened.writer.write(record('recovered')));
    assert(await reopened.writer.settle(5000));
    await reopened.writer.close();
    await finish(ctx, 'c5-rollback-recovery', reopened.seam);
    assert((await readFile(active)).equals(Buffer.concat([seed, Buffer.from(record('recovered'))])));
  }
  // d: rename denied after the exact close; nothing is truncated; a later attempt rotates.
  {
    const seed = seedBytes(SLOT - 500, 'qa438-c5-full');
    const sentinel = Buffer.from(line({ msg: 'qa438-c5-previous' }));
    const { root, active, previous } = await seeded(ctx, 'c5/rename-denied', seed, sentinel);
    const before = { active: await fileState(active), previous: await fileState(previous) };
    const manual = manualSchedule();
    let deny = true;
    const { seam, writer } = await openWriter(root, { rename: async () => { if (deny) { deny = false; throw injected('EPERM'); } } },
      { schedule: manual.schedule });
    assert(writer.write(record('needs-room')));
    await waitEvent(seam, 'rename denial suspension', (e) => e.type === 'suspend');
    const steps = seam.events.filter((e) => e.type === 'rotate').map((e) => [e.step, e.result, e.code]);
    assert.deepEqual(steps, [['close', 'complete', undefined], ['rename', 'failed', 'EPERM']]);
    const closeOp = seam.ops.find((row) => row.op === 'handle.close');
    const renameOp = seam.ops.find((row) => row.op === 'rename');
    assert(closeOp.endMs <= renameOp.startMs, 'rename must follow the exact close');
    assert.deepEqual({ active: await fileState(active), previous: await fileState(previous) }, before);
    assert.equal(writer.write(record('during')), false);
    manual.fire(1000);
    assert(writer.write(record('after')));
    await idle(writer, seam);
    await writer.close();
    await finish(ctx, 'c5-rename-denied', seam);
    const moved = await fileState(previous);
    assert.deepEqual([moved.id, moved.sha256], [before.active.id, before.active.sha256]);
    const fresh = completeRecords(await readFile(active), RECORD);
    assert.deepEqual([fresh[0].value.dropped, fresh[1].value.msg], [2, 'qa438-c5-after']);
  }
  // e: interrupted after a real rename and before create; reopen the previous-only state.
  {
    const seed = seedBytes(SLOT - 500, 'qa438-c5-full');
    const sentinel = Buffer.from(line({ msg: 'qa438-c5-previous' }));
    const { root, active, previous } = await seeded(ctx, 'c5/interrupted', seed, sentinel);
    const before = await fileState(active);
    let failCreate = true;
    const { seam, writer } = await openWriter(root, { open: async ({ mode }) => {
      if (mode === 'create' && failCreate) { failCreate = false; throw injected('EIO'); }
    } }, { schedule: manualSchedule().schedule });
    assert(writer.write(record('interrupted')));
    await waitEvent(seam, 'interrupted rotation suspension', (e) => e.type === 'suspend');
    assert.deepEqual(seam.events.filter((e) => e.type === 'rotate').map((e) => [e.step, e.result]),
      [['close', 'complete'], ['rename', 'complete'], ['create', 'failed']]);
    assert.deepEqual(await fileState(active), { path: active, exists: false });
    const only = await fileState(previous);
    assert.deepEqual([only.id, only.sha256], [before.id, before.sha256]);
    await writer.close();
    await finish(ctx, 'c5-interrupted', seam);
    const reopened = await openWriter(root);
    assert.deepEqual(reopened.seam.events.filter((e) => e.type === 'adopt').map((e) => [e.slot, e.action, e.sizeAfter]),
      [['previous', 'kept', SLOT - 500], ['active', 'created', 0]]);
    assert(reopened.writer.write(record('reopened')));
    assert(await reopened.writer.settle(5000));
    await reopened.writer.close();
    await finish(ctx, 'c5-reopened', reopened.seam);
    assert.equal(await readFile(active, 'utf8'), record('reopened'));
    assert.deepEqual(await fileState(previous), only);
  }
  // f: consecutive faults back off 1..60 s by the documented schedule seam, then disable at 8.
  {
    const seed = seedBytes(8192, 'qa438-c5-seed');
    const { root, active } = await seeded(ctx, 'c5/backoff', seed);
    const unrelated = join(root, 'qa438-unrelated.keep');
    await writeFile(unrelated, 'unrelated fixture bytes\n', { flag: 'wx' });
    const manual = manualSchedule();
    const { seam, writer } = await openWriter(root, { write: async () => { throw injected('EIO'); } }, { schedule: manual.schedule });
    const delays = [];
    for (let attempt = 1; attempt <= 8; attempt++) {
      assert.equal(writer.state, 'open');
      assert(writer.write(record('fault-' + attempt)));
      if (attempt < 8) {
        const suspended = await waitEvent(seam, 'suspend ' + attempt, (e) => e.type === 'suspend' && e.faults === attempt);
        delays.push(suspended.delayMs);
        manual.fire(suspended.delayMs);
      } else {
        await waitEvent(seam, 'fault-limit disable', (e) => e.type === 'disable');
      }
    }
    assert.deepEqual(delays, [1000, 2000, 4000, 8000, 16000, 32000, 60000]);
    assert.equal(seam.events.find((e) => e.type === 'disable').reason, 'fault-limit');
    assert.equal(writer.state, 'disabled');
    assert.equal(writer.write(record('disabled')), false);
    await writer.close();
    await finish(ctx, 'c5-backoff', seam);
    assert.equal((await fileState(active)).sha256, sha(seed));
    assert.equal(await readFile(unrelated, 'utf8'), 'unrelated fixture bytes\n');
    out.backoff = delays;
  }
  return { level: 'controlled production writer faults (injected codes), real file I/O', ...out };
}

async function c5Sharing(ctx) {
  const seed = seedBytes(SLOT - 500, 'qa438-c5r-full');
  const sentinel = Buffer.from(line({ msg: 'qa438-c5r-previous' }));
  const { root, active, previous } = await seeded(ctx, 'c5r', seed, sentinel);
  const before = { active: await fileState(active), previous: await fileState(previous) };
  const manual = manualSchedule();
  const { seam, writer } = await openWriter(root, {}, { schedule: manual.schedule });
  const denied = await ctx.hold({ kind: 'file', name: 'previous-without-delete-share', paths: [previous],
    access: 'Read', share: 'ReadWrite', seconds: 60 }, async () => {
    assert(writer.write(exactRecord(1000, 'qa438-c5r-needs-room')));
    const failed = await waitEvent(seam, 'real rename sharing denial', (e) => e.type === 'rotate' && e.step === 'rename');
    assert.equal(failed.result, 'failed');
    assert(['EPERM', 'EBUSY', 'EACCES'].includes(failed.code), 'unexpected native code ' + failed.code);
    assert.deepEqual({ active: await fileState(active), previous: await fileState(previous) }, before);
    return failed.code;
  });
  manual.fire(1000);
  assert(writer.write(exactRecord(1000, 'qa438-c5r-after-release')));
  await idle(writer, seam);
  await writer.close();
  await finish(ctx, 'c5r', seam);
  const moved = await fileState(previous);
  assert.deepEqual([moved.id, moved.sha256], [before.active.id, before.active.sha256]);
  return { level: 'real Windows sharing denial at the production writer seam', nativeCode: denied };
}

async function c7(ctx) {
  const out = {};
  for (const slot of ['active', 'previous']) {
    const full = slot === 'previous';
    const seed = full ? seedBytes(SLOT - 500, 'qa438-c7-full') : seedBytes(8192, 'qa438-c7-seed');
    const priorPrevious = Buffer.from(line({ msg: 'qa438-c7-previous' }));
    const { root, active, previous } = await seeded(ctx, 'c7/' + slot, seed, priorPrevious);
    const sentinel = join(root, 'qa438-sentinel.keep');
    await writeFile(sentinel, 'qa438 preserved sentinel\n', { flag: 'wx' });
    const target = slot === 'active' ? active : previous;
    const barrier = gate(10_000);
    let armed = false;
    let reached = false;
    const { seam, writer } = await openWriter(root, { lstat: async ({ path }) => {
      if (armed && !reached && path === target) { reached = true; await barrier.promise; }
    } }, { schedule: manualSchedule().schedule });
    armed = true;
    assert(writer.write(exactRecord(1000, 'qa438-c7-record')));
    await observe('name check barrier', () => reached, 5000);
    const displaced = join(root, 'qa438-displaced-' + slot + '.keep');
    await rename(target, displaced);
    await link(sentinel, target);
    const swapped = { name: await fileState(target), sentinel: await fileState(sentinel) };
    assert.equal(swapped.name.nlink, 2);
    barrier.open();
    const disabled = await waitEvent(seam, 'identity-change disable', (e) => e.type === 'disable');
    assert.equal(disabled.reason, slot === 'active' ? 'active-slot-changed' : 'previous-slot-changed');
    assert.equal(barrier.expired, false);
    await writer.close();
    await finish(ctx, 'c7-' + slot, seam);
    assert.equal(await readFile(sentinel, 'utf8'), 'qa438 preserved sentinel\n');
    assert.equal((await fileState(sentinel)).nlink, 2);
    assert.equal((await fileState(displaced)).sha256, sha(slot === 'active' ? seed : priorPrevious));
    if (slot === 'previous') {
      assert(!seam.ops.some((row) => row.op === 'rename'));
      assert.equal((await fileState(active)).sha256, sha(seed));
    }
    out[slot] = { swapped, reason: disabled.reason };
  }
  return { level: 'controlled hostile name mutation (outside the cooperating-process guarantee)', ...out };
}

await runCases(job, [
  { id: 'c1-record-boundary', level: 'controlled', criteria: ['C-1'], run: c1 },
  { id: 'c2-slot-boundary', level: 'controlled', criteria: ['C-2'], run: c2 },
  { id: 'c3-queue-saturation', level: 'controlled', criteria: ['C-3'], run: c3 },
  { id: 'c5-faults', level: 'controlled', criteria: ['C-5'], run: c5 },
  { id: 'c5-real-sharing-denial', level: 'real-native-sharing+controlled-schedule', criteria: ['C-5', 'N-15'], run: c5Sharing },
  { id: 'c7-name-swap', level: 'controlled', criteria: ['C-7'], run: c7 },
]);
