// #438 supplemental native startup cases: N-3, N-4 (+unlogged 75), N-5 (+unlogged 73), N-6,
// N-21, N-22 and N-23 against the actual frozen candidate launcher and built entry. Build deltas
// for N-5/N-22/N-6 live only in owned external shadows whose every byte is hash-bound.
import assert from 'node:assert/strict';
import { lstat, mkdir, readFile, readdir, realpath, writeFile } from 'node:fs/promises';
import { dirname, join, parse, sep } from 'node:path';
import {
  admitSupplement, exclusiveOpen, fileState, logRecords, projectNode, runCases, seedBytes, sha, SLOT,
} from './common.mjs';

const job = await admitSupplement('native-startup', process.argv.slice(2));
const { observe, refused } = job.lib.native;
const { healthy, request, releaseWork, startWork, workState } = job.lib.workload;
const checkout = job.binding.checkout;
const launcher = job.binding.launcher.path;
const mainJs = join(checkout, 'apps/api/dist/main.js');
const CLOSED_KEYS = ['cause', 'detail', 'guidance', 'level', 'msg', 'pid', 'stage', 'time'];
const lastLauncher = async (root) => (await logRecords(join(root, 'launcher.log'))).at(-1);
const closedFor = async (root, pid) => (await logRecords(join(root, 'gateway.log')))
  .filter((r) => r.pid === pid && ['GraphGoblin startup failed', 'GraphGoblin application import failed'].includes(r.msg));

function assertClosed(record, stage, cause) {
  assert(record, 'closed startup record missing');
  assert.deepEqual(Object.keys(record).sort(), CLOSED_KEYS);
  assert.deepEqual([record.level, record.stage, record.cause], [50, stage, cause]);
}

async function corruptStore(ctx) {
  const directory = await ctx.dir('corrupt-qa438-dbpath-canary');
  const file = join(directory, 'qa438.db');
  await writeFile(file, 'qa438-db-bytes-canary deliberately not SQLite\n', { flag: 'wx' });
  return { file, url: 'file:' + file.replaceAll('\\', '/'), canaries: ['qa438-dbpath-canary', 'qa438-db-bytes-canary'] };
}

/**
 * External shadow checkout: frozen apps/api/dist, apps/web/dist(-goblin) and apps/api/package.json
 * copied byte-for-byte (each digest checked against the freeze), plus junctions to the frozen
 * candidate's own node_modules at exactly the levels the candidate has them. One named delta.
 */
async function makeShadow(ctx, name, delta = {}) {
  const shadow = await ctx.dir('shadows/' + name);
  const outputs = Object.entries(job.binding.artifacts.outputFiles)
    .filter(([rel]) => /^apps\/(?:api\/dist|web\/dist|web\/dist-goblin)\//u.test(rel));
  const expected = {};
  for (const [rel, digest] of outputs) {
    if (delta.remove?.includes(rel)) continue;
    const replaced = delta.replace?.[rel];
    const bytes = replaced ?? await readFile(join(checkout, ...rel.split('/')));
    if (!replaced) assert.equal(sha(bytes), digest, rel);
    const target = join(shadow, ...rel.split('/'));
    await mkdir(dirname(target), { recursive: true });
    await writeFile(target, bytes, { flag: 'wx' });
    expected[rel] = sha(bytes);
  }
  for (const rel of ['apps/api/package.json']) {
    const bytes = await readFile(join(checkout, ...rel.split('/')));
    assert.equal(sha(bytes), job.binding.sourceFiles[rel], rel);
    await writeFile(join(shadow, ...rel.split('/')), bytes, { flag: 'wx' });
    expected[rel] = sha(bytes);
  }
  const links = [];
  for (const rel of ['apps/api/dist/node_modules', 'apps/api/node_modules', 'apps/node_modules', 'node_modules']) {
    const source = join(checkout, ...rel.split('/'));
    let present = false;
    try { present = (await lstat(source)) !== undefined; } catch (error) { if (error.code !== 'ENOENT') throw error; }
    if (!present) continue;
    const physical = await realpath(source);
    assert(physical === source || physical.startsWith(checkout + sep), 'candidate dependency root escapes: ' + rel);
    links.push({ rel, target: physical });
    await ctx.link(join(shadow, ...rel.split('/')), physical, 'junction');
  }
  // Bare-specifier resolution walks ancestors. Ancestors above the shadow that the candidate does
  // not share must have no node_modules; shared ones (for example the profile root) are recorded.
  const ancestry = async (start) => {
    const rows = [];
    for (let dir = start; ; dir = dirname(dir)) {
      let present = false;
      try { present = (await lstat(join(dir, 'node_modules'))) !== undefined; } catch (error) { if (error.code !== 'ENOENT') throw error; }
      rows.push({ dir, nodeModules: present });
      if (dir === parse(dir).root) break;
    }
    return rows;
  };
  const candidateAncestors = await ancestry(dirname(checkout));
  const shadowAncestors = await ancestry(dirname(shadow));
  const shared = new Set(candidateAncestors.map((row) => row.dir.toLowerCase()));
  const escaping = shadowAncestors.filter((row) => row.nodeModules && !shared.has(row.dir.toLowerCase()));
  if (escaping.length) {
    throw Object.assign(new Error('INCONCLUSIVE: shadow resolution could escape to ' + escaping.map((r) => r.dir).join(', ')), { code: 'QA438_INCONCLUSIVE' });
  }
  const inventory = {};
  async function walk(dir) {
    for (const entry of await readdir(dir, { withFileTypes: true })) {
      const full = join(dir, entry.name);
      if (entry.isSymbolicLink()) continue;
      if (entry.isDirectory()) await walk(full);
      else inventory[full.slice(shadow.length + 1).replaceAll('\\', '/')] = sha(await readFile(full));
    }
  }
  await walk(shadow);
  for (const link of links) delete inventory[link.rel];
  assert.deepEqual(Object.keys(inventory).sort(), Object.keys(expected).sort(), 'shadow inventory differs');
  for (const [rel, digest] of Object.entries(expected)) assert.equal(inventory[rel], digest, rel);
  await ctx.put('shadow-' + name + '.json', { shadow, delta: { remove: delta.remove ?? [], replace: Object.keys(delta.replace ?? {}) },
    files: Object.keys(expected).length, links, candidateAncestors, shadowAncestors, expected });
  return shadow;
}

async function stimuliCase(ctx) {
  const install = await ctx.privateDir('install');
  const config = ctx.config({ dataDir: await ctx.store('primary'), port: await ctx.port() });
  const file = await ctx.writeConfig(install, 'primary', config);
  const current = await ctx.boot('cold', launcher, file, config);
  const active = join(install, 'gateway.log');
  const pid = current.proof.health.pid;
  await observe('listening record', async () => (await logRecords(active)).some((r) => r.pid === pid && r.msg === 'GraphGoblin API listening'), 5000);
  const canary = { query: 'qa438n3-query-61d2', auth: 'qa438n3-auth-0b7c', segment: 'qa438n3-segment-e4a9',
    version: '123.45.67', body: 'qa438n3-body-2f85', store: config.DataDir };
  const stimuli = [
    { name: 'query', path: '/runs/qa438-run-id?qa=' + canary.query, route: /^\/runs\/:[A-Za-z]+$/u },
    { name: 'auth', path: '/healthz?qa438n3=auth', headers: { authorization: 'Bearer ' + canary.auth }, status: 401, route: /^\/healthz$/u },
    { name: 'version', path: '/' + canary.segment, headers: { 'accept-version': canary.version }, status: 404, route: null },
    { name: 'body', path: '/loops', method: 'POST', headers: { 'content-type': 'application/json' }, route: /^\/loops$/u,
      body: JSON.stringify({ definition: { schemaVersion: 4, name: 'qa438 n3', nodes: [], edges: [] }, qa438BodyCanary: canary.body }) },
  ];
  const values = Object.values(canary).concat(canary.store.replaceAll('\\', '\\\\'));
  const rows = [];
  for (const item of stimuli) {
    const cursor = (await fileState(active)).size;
    const response = await request(current.port, item.path, { method: item.method ?? 'GET', headers: item.headers, body: item.body });
    await response.arrayBuffer();
    if (item.status) assert.equal(response.status, item.status);
    const pair = await observe(item.name + ' access pair', async () => {
      const all = await readFile(active);
      // Start at a record boundary even if the cursor was sampled inside a batch being written.
      const begin = cursor > 0 && all[cursor - 1] !== 10 ? all.indexOf(10, cursor) + 1 : cursor;
      const bytes = all.subarray(begin);
      const fresh = bytes.subarray(0, bytes.lastIndexOf(10) + 1).toString('utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l));
      const done = fresh.find((r) => r.msg === 'request completed' && r.res?.statusCode === response.status);
      const start = done && fresh.find((r) => r.msg === 'incoming request' && r.reqId === done.reqId);
      return start ? { start, done, fresh } : false;
    }, 5000);
    assert(Object.keys(pair.start.req).every((k) => ['method', 'route'].includes(k)));
    assert(Object.keys(pair.done.res).every((k) => ['method', 'route', 'statusCode'].includes(k)));
    assert.equal(pair.start.req.method, item.method ?? 'GET');
    if (item.route) assert.match(pair.done.res.route ?? '', item.route);
    else assert(pair.done.res.route === undefined || !pair.done.res.route.includes(canary.segment), 'raw unregistered path in route field');
    for (const record of [pair.start, pair.done]) for (const value of values) assert(!JSON.stringify(record).includes(value), 'canary in reached access record');
    rows.push({ name: item.name, status: response.status, reqId: pair.done.reqId, req: pair.start.req, res: pair.done.res,
      unregisteredTemplate: item.route ? undefined : pair.done.res.route ?? null,
      otherRecordsWithCanary: pair.fresh.filter((r) => !['incoming request', 'request completed'].includes(r.msg) &&
        values.some((v) => JSON.stringify(r).includes(v))).length });
  }
  await ctx.drain(current);
  return { level: 'real native launcher-started gateway; absence limited to reached access projections', rows };
}

async function configurationCase(ctx) {
  const canary = 'Q438RAWSTART';
  const root = await ctx.privateDir('managed-root');
  const config = ctx.config({ dataDir: await ctx.store('direct'), port: await ctx.port() });
  const env = ctx.gatewayEnv(config, { GG_DEFAULTS: canary });
  const shell = await ctx.direct('shell-invalid-defaults', mainJs, [], env, { expect: 1 });
  assert(shell.stderr.includes(canary), 'shell control did not show the reached raw configuration error');
  const managed = await ctx.direct('managed-invalid-defaults', mainJs, [], { ...env, GG_WINDOWS_LAUNCHER_LOG_DIR: root }, { expect: 74 });
  const [closed, ...extra] = await closedFor(root, managed.pid);
  assert.deepEqual(extra, []);
  assertClosed(closed, 'configuration', 'invalid-configuration');
  for (const name of ['gateway.log', 'gateway.log.1']) {
    const state = await fileState(join(root, name));
    if (state.exists) assert(!(await readFile(join(root, name), 'utf8')).includes(canary), 'raw configuration canary in ' + name);
  }
  assert(!managed.stdout.includes(canary) && !managed.stderr.includes(canary));
  assert.deepEqual(await readdir(config.DataDir), []);
  const install = await ctx.privateDir('launcher-root');
  const launcherConfig = ctx.config({ dataDir: await ctx.store('launcher'), port: await ctx.port(), environment: { GG_DEFAULTS: canary } });
  const file = await ctx.writeConfig(install, 'invalid-defaults', launcherConfig);
  const refusal = await ctx.launch('launcher-invalid-defaults', launcher, ['--config', file, '--ensure-gateway'], { expect: 1 });
  assert(!refusal.stderr.includes(canary));
  const record = await lastLauncher(install);
  assert.deepEqual([record.stage, record.code, record.childExit], ['gateway', 'helper-refused', undefined]);
  assert(!JSON.stringify(record).includes(canary));
  assert.equal((await fileState(join(install, 'gateway.log'))).exists, false, 'helper refusal must precede log admission');
  assert(await refused(launcherConfig.Port));
  return { level: 'real direct guarded entry + real native launcher', shellExit: shell.exit.code, managedExit: managed.exit.code,
    managedOutputBytes: [managed.stdoutBytes, managed.stderrBytes], launcherCode: record.code };
}

async function storeFailureCase(ctx) {
  const corrupt = await corruptStore(ctx);
  const install = await ctx.privateDir('install');
  const config = ctx.config({ dataDir: await ctx.store('launcher'), port: await ctx.port(), environment: { GG_DB_URL: corrupt.url }, startup: 60 });
  const file = await ctx.writeConfig(install, 'store-failure', config);
  const call = await ctx.launch('launcher-store-failure', launcher, ['--config', file, '--ensure-gateway'], { expect: 1 });
  const canonical = await realpath(install);
  assert.match(call.stderr, /failed during startup\. A startup diagnostic naming the failed stage was written/u);
  assert(call.stderr.includes('Log folder: ' + canonical) && call.stderr.includes('Configuration: ' + file));
  const record = await lastLauncher(install);
  assert.deepEqual([record.stage, record.code, record.childExit, record.config, record.logFolder],
    ['gateway', 'startup-failed-logged', 74, file, canonical]);
  const records = await logRecords(join(install, 'gateway.log'));
  const closed = records.filter((r) => r.msg === 'GraphGoblin startup failed');
  assert.equal(closed.length, 1);
  assertClosed(closed[0], 'store', 'store-unavailable');
  for (const value of corrupt.canaries) {
    assert(!call.stderr.includes(value) && !JSON.stringify(record).includes(value) && !JSON.stringify(closed[0]).includes(value));
  }
  const privateMentions = records.filter((r) => corrupt.canaries.some((v) => JSON.stringify(r).includes(v))).length;
  assert(await refused(config.Port));
  assert.deepEqual((await readdir(config.DataDir)).filter((n) => n.includes('lock')), []);
  const root = await ctx.privateDir('direct-root');
  const directConfig = ctx.config({ dataDir: await ctx.store('direct'), port: await ctx.port(), environment: { GG_DB_URL: corrupt.url } });
  const direct = await ctx.direct('direct-store-failure', mainJs, [],
    ctx.gatewayEnv(directConfig, { GG_WINDOWS_LAUNCHER_LOG_DIR: root }), { expect: 74 });
  assertClosed((await closedFor(root, direct.pid))[0], 'store', 'store-unavailable');
  return { level: 'real native launcher and direct guarded entry; real store failure',
    privateRecordsMentioningCanary: privateMentions, childExit: record.childExit };
}

async function storeHeldCase(ctx) {
  const store = await ctx.store('shared');
  const shellConfig = ctx.config({ dataDir: store, port: await ctx.port() });
  const shellEnv = ctx.gatewayEnv(shellConfig);
  const shell = { label: 'shell-owner', port: shellConfig.Port, store, entry: mainJs,
    expected: await ctx.fingerprint(checkout, shellEnv, 'shell-owner') };
  ctx.serveDirect('shell-owner', [mainJs], shellEnv, shell);
  await observe('shell owner ready', async () => (await refused(shell.port)) ? false : true, 25_000);
  shell.proof = await ctx.proof(shell);
  const root = await ctx.privateDir('managed-root');
  const contender = ctx.config({ dataDir: store, port: await ctx.port() });
  const call = await ctx.direct('managed-store-held', mainJs, [],
    ctx.gatewayEnv(contender, { GG_WINDOWS_LAUNCHER_LOG_DIR: root }), { expect: 74 });
  assertClosed((await closedFor(root, call.pid))[0], 'store', 'store-held');
  assert.deepEqual(await healthy(shell.port), shell.proof.health);
  assert(await refused(contender.Port));
  await ctx.drain(shell);
  return { level: 'real direct guarded entry against a real live store owner', exit: call.exit.code };
}

async function launchShadow(ctx, label, shadow, install, environment = {}) {
  const config = ctx.config({ repo: shadow, dataDir: await ctx.store(label), port: await ctx.port(), environment });
  const file = await ctx.writeConfig(install, label, config);
  return { config, file };
}

async function importCase(ctx) {
  const positive = await makeShadow(ctx, 'positive');
  const positiveRoot = await ctx.privateDir('positive-root');
  const { config, file } = await launchShadow(ctx, 'positive', positive, positiveRoot);
  const current = await ctx.boot('positive-shadow', launcher, file, config, { cwd: positive });
  await ctx.drain(current);
  const missing = await makeShadow(ctx, 'missing-serve', { remove: ['apps/api/dist/serve.js'] });
  const missingMain = join(missing, 'apps/api/dist/main.js');
  // Written outcome (72), direct and native.
  const directRoot = await ctx.privateDir('direct-72');
  const directConfig = ctx.config({ repo: missing, dataDir: await ctx.store('direct-72'), port: await ctx.port() });
  const direct = await ctx.direct('direct-missing-module', missingMain, [],
    ctx.gatewayEnv(directConfig, { GG_WINDOWS_LAUNCHER_LOG_DIR: directRoot }), { expect: 72, cwd: missing });
  assertClosed((await closedFor(directRoot, direct.pid))[0], 'import', 'module-not-found');
  const install = await ctx.privateDir('native-72');
  const nativeCase = await launchShadow(ctx, 'native-72', missing, install);
  const refusal = await ctx.launch('launcher-missing-module', launcher, ['--config', nativeCase.file, '--ensure-gateway'], { expect: 1, cwd: missing });
  assert.match(refusal.stderr, /could not load its application modules\. A startup diagnostic was written to gateway\.log/u);
  const record = await lastLauncher(install);
  assert.deepEqual([record.code, record.childExit], ['import-failed-logged', 72]);
  const closed = (await logRecords(join(install, 'gateway.log'))).filter((r) => r.msg === 'GraphGoblin application import failed');
  assert.equal(closed.length, 1);
  assertClosed(closed[0], 'import', 'module-not-found');
  assert(await refused(nativeCase.config.Port));
  // Unwritten outcome (73): full active, previous held without delete sharing denies rotation.
  const unlogged = await unloggedPair(ctx, 'import', missing, {}, 73, 'import-failed-unlogged');
  return { level: 'fault-injected build delta through the actual entry and launcher', positiveShadow: current.stopped,
    direct: direct.exit.code, native: record, unlogged };
}

async function unloggedPair(ctx, name, repo, environment, expected, code) {
  const out = {};
  for (const mode of ['direct', 'native']) {
    const root = await ctx.privateDir(name + '-' + mode + '-unlogged');
    const active = join(root, 'gateway.log');
    const previous = join(root, 'gateway.log.1');
    await writeFile(active, seedBytes(SLOT, 'qa438-unlogged-full'), { flag: 'wx' });
    await writeFile(previous, '{"msg":"qa438-unlogged-previous-sentinel"}\n', { flag: 'wx' });
    const before = [await fileState(active), await fileState(previous)];
    const config = ctx.config({ repo, dataDir: await ctx.store(name + '-' + mode), port: await ctx.port(), environment });
    const result = await ctx.hold({ kind: 'file', name: name + '-' + mode + '-previous', paths: [previous],
      access: 'Read', share: 'ReadWrite', seconds: 120 }, async () => {
      if (mode === 'direct') {
        const call = await ctx.direct(name + '-direct-unlogged', join(repo, 'apps/api/dist/main.js'), [],
          ctx.gatewayEnv(config, { GG_WINDOWS_LAUNCHER_LOG_DIR: root }), { expect: expected, cwd: repo });
        return { exit: call.exit.code, pid: call.pid };
      }
      const file = await ctx.writeConfig(root, name + '-unlogged', config);
      const call = await ctx.launch(name + '-native-unlogged', launcher, ['--config', file, '--ensure-gateway'], { expect: 1, cwd: repo });
      assert.match(call.stderr, /no startup diagnostic could be written/u);
      const record = await lastLauncher(root);
      assert.deepEqual([record.code, record.childExit], [code, expected]);
      return { exit: call.exit.code, launcherRecord: record };
    });
    assert.deepEqual([await fileState(active), await fileState(previous)], before, 'unlogged slots changed');
    await exclusiveOpen(ctx, [active, previous]);
    assert(await refused(config.Port));
    out[mode] = result;
  }
  return out;
}

async function unknownExitCase(ctx) {
  const shadow = await makeShadow(ctx, 'exit-79', { replace: { 'apps/api/dist/serve.js': Buffer.from('process.exit(79);\n') } });
  const entry = join(shadow, 'apps/api/dist/main.js');
  const root = await ctx.privateDir('direct-79');
  const config = ctx.config({ repo: shadow, dataDir: await ctx.store('direct'), port: await ctx.port() });
  const direct = await ctx.direct('direct-unknown-exit', entry, [], ctx.gatewayEnv(config, { GG_WINDOWS_LAUNCHER_LOG_DIR: root }), { expect: 79, cwd: shadow });
  assert.deepEqual(await closedFor(root, direct.pid), []);
  const install = await ctx.privateDir('native-79');
  const nativeCase = await launchShadow(ctx, 'native-79', shadow, install);
  const call = await ctx.launch('launcher-unknown-exit', launcher, ['--config', nativeCase.file, '--ensure-gateway'], { expect: 1, cwd: shadow });
  assert(call.stderr.includes('exit code 79') && call.stderr.includes('No startup diagnostic can be assumed'));
  const record = await lastLauncher(install);
  assert.deepEqual([record.code, record.childExit], ['unknown-exit', 79]);
  assert.deepEqual((await logRecords(join(install, 'gateway.log'))).filter((r) => /startup failed|import failed/u.test(r.msg ?? '')), []);
  return { level: 'fault-injected build delta through the actual entry and launcher', direct: direct.exit.code, native: record };
}

async function startupUnloggedCase(ctx) {
  const corrupt = await corruptStore(ctx);
  return { level: 'real native sharing denial of rotation; real store failure',
    ...await unloggedPair(ctx, 'startup', checkout, { GG_DB_URL: corrupt.url }, 75, 'startup-failed-unlogged') };
}

async function staleEntryCase(ctx) {
  const predecessorMain = join(job.baseline.checkout, 'apps/api/dist/main.js');
  const bytes = await readFile(predecessorMain);
  assert.equal(sha(bytes), job.baseline.artifacts.outputFiles['apps/api/dist/main.js']);
  const marker = Buffer.from('export const WINDOWS_LAUNCHER_LOG_PROTOCOL = 1;', 'ascii');
  assert.equal(bytes.subarray(0, 4096).indexOf(marker), -1);
  const current = await readFile(mainJs);
  const at = current.indexOf(marker);
  assert(at >= 0 && at + marker.length <= 4096, 'frozen entry marker not wholly within 4 KiB');
  const stale = await makeShadow(ctx, 'stale-entry', { replace: { 'apps/api/dist/main.js': bytes } });
  const install = await ctx.privateDir('install');
  const port = await ctx.port();
  const appId = await ctx.launch('expected-app-id', launcher, ['--expected-app-id', String(port)]);
  assert.equal(appId.exit.code, 0);
  assert.match(appId.stdout.trim(), /^[a-p]{32}$/u);
  const chrome = join(await ctx.dir('chrome-fixture'), 'qa438-not-invoked.exe');
  await writeFile(chrome, 'qa438 fixture file; never executed\n', { flag: 'wx' });
  const staged = (repo, name) => ({ ...ctx.config({ repo, dataDir: join(ctx.storesDir, 'never-' + name), port }),
    ChromeProxy: chrome, ChromeProfile: 'Profile 438', ChromeAppId: appId.stdout.trim(),
    PwaAppUserModelId: 'GraphGoblin.QA438.Pwa', IconLocation: chrome + ',0' });
  const staleFile = await ctx.writeConfig(install, 'stale', staged(stale, 'stale'));
  const validate = await ctx.launch('validate-stale', launcher, ['--validate-install', '--config', staleFile], { expect: 1 });
  assert.match(validate.stderr, /built gateway does not match this launcher/u);
  const ensure = await ctx.launch('ensure-stale', launcher, ['--config', staleFile, '--ensure-gateway'], { expect: 1 });
  assert.match(ensure.stderr, /built gateway does not match this launcher/u);
  assert.deepEqual([(await lastLauncher(install)).stage, (await lastLauncher(install)).code], ['configuration', 'configuration-refused']);
  const currentFile = await ctx.writeConfig(install, 'current', staged(checkout, 'current'));
  await ctx.launch('validate-current', launcher, ['--validate-install', '--config', currentFile], { expect: 0 });
  assert.equal((await fileState(join(install, 'gateway.log'))).exists, false);
  assert(await refused(port));
  for (const name of ['never-stale', 'never-current']) assert.equal((await fileState(join(ctx.storesDir, name))).exists, false);
  return { level: 'real native validator against a stale-entry shadow; no shortcut or Chrome launch',
    markerOffset: at, appId: appId.stdout.trim() };
}

async function reservedEnvironmentCase(ctx) {
  const install = await ctx.privateDir('install');
  const refusals = [];
  for (const key of ['GG_windows_launcher_log_dir', 'GG_WINDOWS_LAUNCHER_LOG_DIR']) {
    const config = ctx.config({ dataDir: join(ctx.storesDir, 'never-' + refusals.length), port: await ctx.port(),
      environment: { [key]: 'C:\\qa438-not-a-log-root' } });
    const file = await ctx.writeConfig(install, 'reserved-' + refusals.length, config);
    const call = await ctx.launch('reserved-' + refusals.length, launcher, ['--config', file, '--ensure-gateway'], { expect: 1 });
    assert(call.stderr.includes('GG_WINDOWS_LAUNCHER_LOG_DIR is reserved for the launcher.'));
    const record = await lastLauncher(install);
    assert.deepEqual([record.stage, record.code], ['configuration', 'configuration-refused']);
    refusals.push({ key, code: record.code });
  }
  const root = await ctx.privateDir('opt-in-root');
  const config = ctx.config({ dataDir: await ctx.store('opt-in'), port: await ctx.port() });
  const plain = await ctx.fingerprint(checkout, ctx.gatewayEnv(config), 'plain');
  const withVariable = await ctx.fingerprint(checkout, ctx.gatewayEnv(config, { GG_WINDOWS_LAUNCHER_LOG_DIR: root }), 'with-variable');
  assert.equal(withVariable, plain, 'identity fingerprint depends on the launcher log variable');
  const current = { label: 'opt-in', port: config.Port, store: config.DataDir, entry: mainJs, expected: plain };
  ctx.serveDirect('opt-in', [mainJs], ctx.gatewayEnv(config, { gg_windows_launcher_log_dir: root }), current);
  await observe('opt-in gateway ready', async () => (await refused(current.port)) ? false : true, 25_000);
  current.proof = await ctx.proof(current);
  const pid = current.proof.health.pid;
  await observe('managed listening record from lowercase opt-in', async () =>
    (await logRecords(join(root, 'gateway.log'))).some((r) => r.pid === pid && r.msg === 'GraphGoblin API listening'), 5000);
  const witness = join(await ctx.dir('env-witness'), 'script-env.json');
  const script = [
    "const fs = require('node:fs'); const keys = Object.keys(process.env);",
    `fs.writeFileSync(${JSON.stringify(witness)}, JSON.stringify({ reserved: keys.some((k) => k.toUpperCase() === 'GG_WINDOWS_LAUNCHER_LOG_DIR'),`,
    "  inherited: keys.some((k) => k.toUpperCase() === 'GG_LOG_LEVEL') }), { flag: 'wx' });",
  ].join('\n');
  const definition = { schemaVersion: 4, name: 'QA 438 environment witness', nodes: [
    { id: 'start', kind: 'trigger', label: 'Start', config: { type: 'manual' } },
    { id: 'probe', kind: 'script', label: 'Probe', config: { command: projectNode, args: ['-e', script], timeoutSeconds: 60, stdin: 'none', stdout: 'ignore' } },
    { id: 'done', kind: 'exit', label: 'Done', config: {} },
  ], edges: [
    { id: 'e1', from: { node: 'start', port: 'out' }, to: { node: 'probe' } },
    { id: 'e2', from: { node: 'probe', port: 'out' }, to: { node: 'done' } },
  ] };
  const post = (body) => ({ method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
  const created = await request(current.port, '/loops', post({ definition }));
  assert.equal(created.status, 201);
  const { loop } = await created.json();
  assert.equal((await request(current.port, '/loops/' + loop.id + '/publish', { method: 'POST' })).status, 200);
  const started = await request(current.port, '/loops/' + loop.id + '/runs', post({}));
  assert.equal(started.status, 202);
  const { run } = await started.json();
  await observe('environment witness run succeeded', async () => (await workState(current.port, { runId: run.id })).status === 'succeeded', 20_000);
  const observed = JSON.parse(await readFile(witness, 'utf8'));
  assert.deepEqual(observed, { reserved: false, inherited: true });
  await ctx.drain(current);
  return { level: 'real native refusal + real direct opt-in and real Script environment', refusals, scriptEnvironment: observed };
}

async function shellAndCliCase(ctx) {
  const config = ctx.config({ dataDir: await ctx.store('shell'), port: await ctx.port() });
  const env = ctx.gatewayEnv(config);
  const shell = { label: 'shell', port: config.Port, store: config.DataDir, entry: mainJs,
    expected: await ctx.fingerprint(checkout, env, 'shell') };
  ctx.serveDirect('shell', [mainJs], env, shell);
  await observe('shell ready', async () => (await refused(shell.port)) ? false : true, 25_000);
  shell.proof = await ctx.proof(shell);
  await healthy(shell.port, '/healthz?qa438shell=ordinary-projection');
  await ctx.drain(shell);
  const shellOut = (await shell.closed).call.stdout;
  assert(shellOut.includes('GraphGoblin API listening'));
  const access = shellOut.split('\n').filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } })
    .find((r) => r?.msg === 'incoming request' && String(r.req?.url).includes('qa438shell=ordinary-projection'));
  assert(access, 'ordinary shell Pino projection (raw URL with query) not observed on stdout');
  const root = await ctx.privateDir('consumed-root');
  for (const [name, text] of [['gateway.log', '{"msg":"qa438-cli-gateway"}\n'], ['launcher.log', '{"msg":"qa438-cli-launcher"}\n']]) {
    await writeFile(join(root, name), text, { flag: 'wx' });
  }
  const pair = async () => Promise.all(['gateway.log', 'gateway.log.1', 'launcher.log', 'launcher.log.1'].map((n) => fileState(join(root, n))));
  const before = { files: await pair(), names: (await readdir(root)).sort() };
  const alias = await ctx.link(join(ctx.fixture, 'dist-alias'), join(checkout, 'apps', 'api', 'dist'), 'junction');
  const rows = [];
  let index = 0;
  for (const args of [['--preflight'], ['--create-api-key'], ['--reset']]) {
    const run = async (label, entry, extra) => {
      const store = await ctx.store('cli-' + index++);
      const cliConfig = ctx.config({ dataDir: store, port: config.Port });
      const call = await ctx.direct(label, entry, args, ctx.gatewayEnv(cliConfig, extra));
      const normal = (text) => text.split(store).join('<STORE>').split(store.replaceAll('\\', '\\\\')).join('<STORE>');
      return { exit: call.exit.code, stdout: normal(call.stdout), stderr: normal(call.stderr) };
    };
    const plain = await run('cli-plain' + args[0], mainJs, {});
    const consumed = await run('cli-variable' + args[0], mainJs, { GG_WINDOWS_LAUNCHER_LOG_DIR: root });
    assert.deepEqual(consumed, plain, args[0] + ' changed when the launcher variable was present');
    if (args[0] === '--preflight') {
      const aliased = await run('cli-alias' + args[0], join(alias, 'main.js'), {});
      assert.deepEqual(aliased, plain, 'physical entry detection through a checkout alias changed --preflight');
    }
    rows.push({ args, exit: plain.exit });
  }
  assert.deepEqual({ files: await pair(), names: (await readdir(root)).sort() }, before, 'CLI modes touched managed log names');
  return { level: 'real direct shell and CLI dispatch on disposable stores', cli: rows };
}

await runCases(job, [
  { id: 'n3-access-projection', level: 'native', criteria: ['N-3', 'N-4 positive control'], run: stimuliCase },
  { id: 'n4-configuration', level: 'native', criteria: ['N-4'], run: configurationCase },
  { id: 'n4-store-failure', level: 'native', criteria: ['N-4'], run: storeFailureCase },
  { id: 'n4-store-held', level: 'native', criteria: ['N-4'], run: storeHeldCase },
  { id: 'n5-import-outcomes', level: 'native+fault-injected-build', criteria: ['N-5', 'N-5 unlogged'], run: importCase },
  { id: 'n4-startup-unlogged', level: 'native', criteria: ['N-4 unlogged'], run: startupUnloggedCase },
  { id: 'n22-unknown-exit', level: 'native+fault-injected-build', criteria: ['N-22'], run: unknownExitCase },
  { id: 'n6-stale-entry', level: 'native', criteria: ['N-6'], run: staleEntryCase },
  { id: 'n21-reserved-environment', level: 'native', criteria: ['N-21'], run: reservedEnvironmentCase },
  { id: 'n23-shell-and-cli', level: 'native', criteria: ['N-23'], run: shellAndCliCase },
]);
