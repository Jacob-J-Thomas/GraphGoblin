// #438 supplemental predecessor cases: the actual frozen e21c baseline launcher and gateway as the
// live legacy writer (N-11), the incompatible warm control (N-12), deliberate stop then oversized
// replacement (N-13), and candidate/predecessor CLI parity (N-23). The baseline checkout is read
// and executed in place; its source, index and build are never changed.
import assert from 'node:assert/strict';
import { readFile, readdir } from 'node:fs/promises';
import { join } from 'node:path';
import {
  admitSupplement, BASELINE, completeRecords, fileState, gitReadback, logRecords, projectNode, readBound,
  RECORD, runCases, sha, SLOT,
} from './common.mjs';

const job = await admitSupplement('native-predecessor', process.argv.slice(2));
const { observe, refused } = job.lib.native;
const { healthy, releaseWork, startWork, traffic, workState } = job.lib.workload;
const baseline = job.baseline;
const candidateLauncher = job.binding.launcher.path;
const limits = job.admission.limits.pressure;
const lastLauncher = async (root) => (await logRecords(join(root, 'launcher.log'))).at(-1);
const FOREIGN = 'belongs to an unrelated or differently configured service (or an older GraphGoblin build)';

/** Immutable predecessor proof without depending on the moving remote main ref. */
async function verifyPredecessor() {
  for (const ref of [baseline.launcher, baseline.launcherBuildReceipt, baseline.launcherBuildExit, baseline.buildReceipt,
    baseline.buildLog, baseline.buildExit]) await readBound(ref);
  await readBound(baseline.node);
  await readBound(baseline.git);
  const opening = gitReadback(baseline);
  assert.deepEqual([opening.status, opening.head, opening.tree], ['', BASELINE.head, BASELINE.tree]);
  assert.equal(sha(await readFile(opening.index)), baseline.indexSha256, 'baseline index changed');
  const files = opening.git('ls-files', '-z').split('\0').filter(Boolean);
  assert.equal(files.length, Object.keys(baseline.sourceFiles).length);
  for (const file of files) assert.equal(sha(await readFile(join(baseline.checkout, file))), baseline.sourceFiles[file], file);
  assert.deepEqual(await job.lib.artifacts.collectArtifacts(baseline.checkout), baseline.artifacts);
  const closing = gitReadback(baseline);
  assert.deepEqual([closing.status, closing.head, closing.tree], ['', BASELINE.head, BASELINE.tree]);
  let remoteMain;
  try { remoteMain = closing.git('rev-parse', 'refs/remotes/origin/main').trim(); } catch (error) { remoteMain = 'unavailable: ' + error.message; }
  return { head: closing.head, tree: closing.tree, sourceFiles: files.length, artifactInventorySha256: baseline.artifacts.inventorySha256,
    launcherSha256: baseline.launcher.sha256, observedRemoteMain: remoteMain,
    remoteMainNote: 'Recorded only; the predecessor proof is the immutable head/tree/index/source/artifact binding.' };
}

let openingProof;

async function sourceFingerprintControl() {
  const read = async (binding) => {
    const bytes = await readFile(join(binding.checkout, 'apps/api/src/instance-identity.ts'));
    assert.equal(sha(bytes), binding.sourceFiles['apps/api/src/instance-identity.ts']);
    return bytes.toString('utf8');
  };
  const extract = (text) => {
    const start = text.indexOf('export function instanceIdentity(');
    assert(start >= 0);
    return text.slice(start, text.indexOf('\n}\n', start) + 2).split('\n');
  };
  const [before, afterText] = [await read(baseline), await read(job.binding)];
  const a = extract(before);
  const b = extract(afterText);
  assert.equal(a.length, b.length, 'instanceIdentity changed shape');
  const diffs = a.map((line, i) => [line.trim(), b[i].trim()]).filter(([x, y]) => x !== y);
  assert.deepEqual(diffs, [['protocol: 1,', 'protocol: INSTANCE_PROTOCOL,']]);
  assert.match(afterText, /^export const INSTANCE_PROTOCOL = 2;$/mu);
  return { level: 'source-only', diffs };
}

async function liveCase(ctx) {
  const root = await ctx.privateDir('install');
  const active = join(root, 'gateway.log');
  const baseConfig = ctx.config({ repo: baseline.checkout, dataDir: await ctx.store('predecessor'), port: await ctx.port() });
  const predecessor = await ctx.boot('predecessor', baseline.launcher.path, await ctx.writeConfig(root, 'predecessor', baseConfig),
    baseConfig, { cwd: baseline.checkout });
  const health = predecessor.proof.health;
  const sentinel = 'qa438-predecessor-history-sentinel-7d1e';
  await healthy(baseConfig.Port, '/healthz?' + sentinel + '=1');
  await observe('predecessor appended its raw access line', async () => (await readFile(active)).includes(sentinel), 5000);
  const work = await startWork({ port: baseConfig.Port, directory: await ctx.dir('work'), node: projectNode, definitionFormat: 4, observe },
    (state) => { predecessor.work = state; });
  await observe('predecessor log quiescent', async () => {
    const first = await fileState(active);
    await new Promise((resolve) => setTimeout(resolve, 400));
    const second = await fileState(active);
    return first.size === second.size ? second : false;
  }, 8000);
  const before = await fileState(active);
  // N-11: the candidate refuses a live predecessor append handle on the same root (disjoint store/port).
  const contender = ctx.config({ dataDir: await ctx.store('candidate-contender'), port: await ctx.port(), startup: 2 });
  const refusal = await ctx.launch('candidate-contender', candidateLauncher,
    ['--config', await ctx.writeConfig(root, 'candidate-contender', contender), '--ensure-gateway'], { expect: 1 });
  assert(refusal.stderr.includes('log folder is already in use'));
  const record = await lastLauncher(root);
  assert.deepEqual([record.stage, record.code, record.childExit], ['gateway', 'destination-in-use', undefined]);
  assert.deepEqual(await readdir(contender.DataDir), []);
  assert(await refused(contender.Port));
  const held = await fileState(active);
  assert.equal(held.id, before.id);
  assert.equal(sha((await readFile(active)).subarray(0, before.size)), before.sha256, 'existing predecessor bytes changed');
  assert.deepEqual(await ctx.proof(predecessor), predecessor.proof);
  await healthy(baseConfig.Port, '/healthz?qa438-after-contender=1');
  await observe('predecessor still appends', async () => (await readFile(active)).includes('qa438-after-contender'), 5000);
  // N-12: candidate warm probe against the serving predecessor's store and port.
  const warm = ctx.config({ dataDir: baseConfig.DataDir, port: baseConfig.Port });
  const warmCall = await ctx.launch('candidate-warm', candidateLauncher,
    ['--config', await ctx.writeConfig(root, 'candidate-warm', warm), '--ensure-gateway'], { expect: 1 });
  assert(warmCall.stderr.includes(FOREIGN));
  const warmRecord = await lastLauncher(root);
  assert.deepEqual([warmRecord.stage, warmRecord.code, warmRecord.childExit], ['gateway', 'foreign-listener', undefined]);
  assert.deepEqual(await ctx.proof(predecessor), predecessor.proof);
  assert.equal((await fileState(active)).id, before.id);
  const fingerprint = await sourceFingerprintControl();
  // Drive the predecessor's own unbounded history past one slot within the existing budget.
  const started = performance.now();
  let sent = 0;
  while ((await fileState(active)).size <= SLOT + 64 * 1024) {
    assert(sent < limits.requests && performance.now() - started < limits.milliseconds, 'predecessor history did not exceed one slot within budget');
    const count = Math.min(limits.batch, limits.requests - sent);
    await traffic(baseConfig.Port, health, count, limits.workers, sent);
    sent += count;
  }
  const grown = await fileState(active);
  assert.equal(grown.id, before.id);
  await releaseWork(work);
  await observe('predecessor held work succeeds', async () => (await workState(baseConfig.Port, work)).status === 'succeeded', 15_000);
  await ctx.drain(predecessor);
  // N-13: deliberate stop, then the candidate replaces the oversized stopped history on adoption.
  const stopped = await fileState(active);
  assert(stopped.size > SLOT);
  const next = ctx.config({ dataDir: await ctx.store('candidate-restart'), port: await ctx.port() });
  const restarted = await ctx.boot('candidate-restart', candidateLauncher, await ctx.writeConfig(root, 'candidate-restart', next), next);
  const pid = restarted.proof.health.pid;
  const slots = [active, join(root, 'gateway.log.1')];
  const logs = await observe('restarted PID listening record', async () => {
    const all = await Promise.all(slots.map((path) => logRecords(path)));
    return all.flat().some((r) => r.pid === pid && r.msg === 'GraphGoblin API listening') ? all : false;
  }, 5000);
  for (const path of slots) {
    const state = await fileState(path);
    if (!state.exists) continue;
    const bytes = await readFile(path);
    assert(!bytes.includes(sentinel), 'oversized predecessor history was retained in ' + path);
    assert(state.size <= SLOT);
    completeRecords(bytes.subarray(0, bytes.lastIndexOf(10) + 1), RECORD);
  }
  await ctx.drain(restarted);
  await ctx.put('predecessor-summary.json', { before, held, grown, stopped, sent, logs: logs.map((rows) => rows.length) });
  return { level: 'actual frozen predecessor launcher and gateway as the live legacy writer', contender: record.code,
    warm: warmRecord.code, fingerprint, sentRequests: sent, oversizedStoppedBytes: stopped.size };
}

async function cliParityCase(ctx) {
  const rows = [];
  let index = 0;
  for (const args of [['--preflight'], ['--create-api-key'], ['--reset']]) {
    const run = async (binding) => {
      const store = await ctx.store('cli-' + index++);
      const config = ctx.config({ repo: binding.checkout, dataDir: store, port: await ctx.port() });
      const call = await ctx.direct('cli-' + binding.mode + args[0], join(binding.checkout, 'apps/api/dist/main.js'), args,
        ctx.gatewayEnv(config), { cwd: binding.checkout });
      const normal = (text) => [[store, '<STORE>'], [store.replaceAll('\\', '\\\\'), '<STORE>'],
        [binding.checkout, '<REPO>'], [binding.checkout.replaceAll('\\', '\\\\'), '<REPO>'], [String(config.Port), '<PORT>']]
        .reduce((value, [from, to]) => value.split(from).join(to), text);
      return { exit: call.exit.code, stdout: normal(call.stdout), stderr: normal(call.stderr) };
    };
    const candidate = await run(job.binding);
    const predecessor = await run(baseline);
    await ctx.put('cli' + args[0] + '.json', { candidate, predecessor });
    assert.deepEqual(candidate, predecessor, args[0] + ' behavior differs from the predecessor');
    rows.push({ args, exit: candidate.exit });
  }
  return { level: 'real CLI dispatch of candidate and predecessor on disposable stores', rows };
}

await runCases(job, [
  { id: 'baseline-opening-readback', level: 'binding', criteria: ['predecessor binding'], run: async () => {
    openingProof = await verifyPredecessor();
    return openingProof;
  } },
  { id: 'n11-n12-n13-live-predecessor', level: 'native', criteria: ['N-11', 'N-12', 'N-13'], run: liveCase },
  { id: 'n23-cli-parity', level: 'native', criteria: ['N-23'], run: cliParityCase },
  { id: 'baseline-closing-readback', level: 'binding', criteria: ['predecessor binding'], run: async () => {
    const closing = await verifyPredecessor();
    assert.deepEqual({ ...closing, observedRemoteMain: null }, { ...openingProof, observedRemoteMain: null });
    return closing;
  } },
]);
