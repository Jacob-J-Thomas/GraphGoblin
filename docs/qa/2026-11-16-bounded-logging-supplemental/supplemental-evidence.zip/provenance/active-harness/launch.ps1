#Requires -Version 7.0
# Root-invoked wrapper for one admitted #438 supplemental module. It verifies the admission and the
# module bytes, runs project Node with exact argv and records PID, exit and raw stream receipts.
# It never signals the runner: on its finite deadline it records the open disposition and stops.
param(
    [Parameter(Mandatory)][string]$Admission,
    [Parameter(Mandatory)][ValidatePattern('^[a-f0-9]{64}$')][string]$Sha256,
    [Parameter(Mandatory)][ValidateSet('writer-controls', 'guard-controls', 'native-startup', 'native-sharing', 'native-predecessor')][string]$Module
)

$ErrorActionPreference = 'Stop'
if (!$IsWindows) { throw 'Windows only' }
$batch = Split-Path -Parent $PSScriptRoot
$user = Split-Path -Parent (Split-Path -Parent $batch)
$projectNode = Join-Path $user '.claude/codex-runs/GraphGoblin/runtime/node-v22.23.4-win-x64/node.exe'
if (![IO.Path]::IsPathFullyQualified($Admission)) { throw 'Admission must be absolute' }
$Admission = [IO.Path]::GetFullPath($Admission)
if (!$Admission.StartsWith($batch + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Admission must be inside the QA batch'
}
if ((Get-FileHash -LiteralPath $Admission -Algorithm SHA256).Hash.ToLowerInvariant() -cne $Sha256) { throw 'Admission digest changed' }
$admitted = Get-Content -LiteralPath $Admission -Raw | ConvertFrom-Json
if ($admitted.schema -cne 'gg438-supplemental-admission/v1' -or $admitted.attempt -notmatch '^supplemental-attempt-[1-9][0-9]*$') {
    throw 'Wrong execution admission'
}
if (@($admitted.enabledModules) -notcontains $Module) { throw 'Module not admitted' }
foreach ($file in @('common.mjs', ($Module + '.mjs'))) {
    $actual = (Get-FileHash -LiteralPath (Join-Path $PSScriptRoot $file) -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -cne $admitted.modules.$file) { throw ('Module digest changed: ' + $file) }
}
$receipts = Join-Path $PSScriptRoot 'receipts'
[IO.Directory]::CreateDirectory($receipts) | Out-Null
if (([IO.File]::GetAttributes($receipts) -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Unsafe receipt root' }
$output = Join-Path $receipts ($admitted.attempt + '-' + $Module)
New-Item -ItemType Directory -Path $output | Out-Null

function Save-Receipt($Name, $Data) {
    $file = [IO.File]::Open((Join-Path $output $Name), [IO.FileMode]::CreateNew, [IO.FileAccess]::Write)
    try {
        $bytes = [Text.UTF8Encoding]::new($false).GetBytes(($Data | ConvertTo-Json -Depth 12) + "`n")
        $file.Write($bytes)
    } finally { $file.Dispose() }
}

$info = [Diagnostics.ProcessStartInfo]::new($projectNode)
$info.WorkingDirectory = $PSScriptRoot
$info.UseShellExecute = $false
$info.CreateNoWindow = $true
$info.RedirectStandardOutput = $true
$info.RedirectStandardError = $true
foreach ($name in @($info.Environment.Keys)) {
    if ($name -ieq 'NODE_OPTIONS' -or $name -ieq 'GG_WINDOWS_LAUNCHER_LOG_DIR') { $info.Environment.Remove($name) | Out-Null }
}
foreach ($arg in @((Join-Path $PSScriptRoot ($Module + '.mjs')), $Admission, $Sha256)) { $info.ArgumentList.Add($arg) }
$stdout = [IO.File]::Open((Join-Path $output 'stdout.raw'), [IO.FileMode]::CreateNew, [IO.FileAccess]::Write)
$stderr = [IO.File]::Open((Join-Path $output 'stderr.raw'), [IO.FileMode]::CreateNew, [IO.FileAccess]::Write)
$child = $null
$code = $null
try {
    Save-Receipt 'requested.json' @{ executable = $projectNode; arguments = $info.ArgumentList; module = $Module; at = [DateTime]::UtcNow.ToString('o') }
    $child = [Diagnostics.Process]::Start($info)
    $outCopy = $child.StandardOutput.BaseStream.CopyToAsync($stdout)
    $errCopy = $child.StandardError.BaseStream.CopyToAsync($stderr)
    $created = try { $child.StartTime.ToUniversalTime().ToString('o') } catch { $null }
    Save-Receipt 'launch.json' @{ pid = $child.Id; creationUtc = $created; module = $Module }
    $deadline = [DateTime]::UtcNow.AddMinutes(30)
    do { $finished = $child.WaitForExit(10000) } until ($finished -or [DateTime]::UtcNow -ge $deadline)
    if (!$finished) {
        Save-Receipt 'timeout.json' @{ pid = $child.Id; creationUtc = $created; at = [DateTime]::UtcNow.ToString('o') }
        throw 'Runner disposition requires exact owned process readback'
    }
    $code = $child.ExitCode
    Save-Receipt 'exit.json' @{ pid = $child.Id; exitCode = $code; at = [DateTime]::UtcNow.ToString('o') }
    if (![Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($outCopy, $errCopy), 5000)) { throw 'Runner stream close ambiguous' }
    Save-Receipt 'capture.json' @{ stdoutBytes = $stdout.Length; stderrBytes = $stderr.Length }
} finally {
    $stdout.Dispose()
    $stderr.Dispose()
    if ($null -ne $child) { $child.Dispose() }
}
exit $code
