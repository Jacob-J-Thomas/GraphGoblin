// Read-only source binding for every literal, constant and seam the supplemental fixtures assert.
// A missing needle means a fixture expectation must be re-derived from the frozen source; it is a
// preparation finding, not a product verdict.
//   node source-checks.mjs --binding <absolute candidate binding> <sha256>   (frozen; digests enforced)
//   node source-checks.mjs --dirty <absolute candidate checkout>             (preparation readback only)
import assert from 'node:assert/strict';
import { readFile, realpath } from 'node:fs/promises';
import { join } from 'node:path';
import { BASELINE, batch, readBound, sha, under } from './common.mjs';

const [mode, ...rest] = process.argv.slice(2);
let checkout;
let binding;
if (mode === '--binding') {
  assert.equal(rest.length, 2);
  binding = JSON.parse((await readBound({ path: rest[0], sha256: rest[1] }, batch)).toString('utf8'));
  checkout = binding.checkout;
} else if (mode === '--dirty') {
  assert.equal(rest.length, 1);
  checkout = await realpath(rest[0]);
} else throw new Error('usage: --binding <binding> <sha256> | --dirty <checkout>');
const baseline = JSON.parse((await readBound({ path: under(batch, 'launcher-438-baseline-binding-02.json'), sha256: BASELINE.bindingSha256 }, batch)).toString('utf8'));

const candidate = {
  'apps/windows-launcher/Launcher.cs': [
    'log folder is already in use by another GraphGoblin gateway',
    'log folder is unsafe or unavailable',
    'could not load its application modules. A startup diagnostic was written to gateway.log',
    'and no startup diagnostic could be written',
    'No startup diagnostic can be assumed',
    '(exit code " + code.ToString(CultureInfo.InvariantCulture) + ")',
    "built gateway does not match this launcher",
    'LogDirectoryVariable + " is reserved for the launcher."',
    'public const string LogDirectoryVariable = "GG_WINDOWS_LAUNCHER_LOG_DIR";',
    'unexpected launcher error during the " + stage + " step',
    'failed during startup. A startup diagnostic naming the failed stage was written',
    'belongs to an unrelated or differently configured service (or an older GraphGoblin build)',
    ': "unexpected launcher error";',
    '"destination-in-use"', '"destination-unavailable"', '"import-failed-logged"', '"import-failed-unlogged"',
    '"startup-failed-logged"', '"startup-failed-unlogged"', '"unknown-exit"', '"configuration-refused"',
    '"helper-refused"', '"foreign-listener"',
    'public const int SlotBytes = 262144, RecordBytes = 4096;',
    'MutexWait = TimeSpan.FromMilliseconds(250);',
    '@"Global\\GraphGoblin.LauncherLog." + Key("graphgoblin-launcher-log-root/v1")',
    '@"\\\\.\\pipe\\GraphGoblin.GatewayLog." + Key("graphgoblin-gateway-log-root/v1")',
    'NativeFiles.GenericRead, NativeFiles.ShareRead, NativeFiles.OpenExisting, NativeFiles.OpenReparsePoint',
    'if (Marshal.GetLastWin32Error() != NativeFiles.SharingViolation)',
    'NativeFiles.GenericRead | NativeFiles.GenericWrite, NativeFiles.ShareRead,',
    'Nul(0x80000000)', 'outputHandle = Nul(0x40000000);', 'new IntPtr(0x20002), handles, new IntPtr(IntPtr.Size * 2)',
    'if (!HasLogProtocol(Path.Combine(Repo, "apps/api/dist/main.js")))',
    'public const string LogProtocolMarker = "export const WINDOWS_LAUNCHER_LOG_PROTOCOL = 1;";',
    '"apps/api/dist/main.js", "apps/api/dist/instance-identity.js",',
    '"apps/api/dist/windows-log/guard.js", "apps/web/dist/index.html"',
    'public static byte[] Build(DateTime time, int pid, Exception error, string stage, string configFile)',
    'public static bool Append(LogRoot root, byte[] record)',
    'public static LogRoot Admit(string directory)',
    'public const int MaxRenderedPath = 260;',
  ],
  'apps/api/src/main.ts': [
    'export const WINDOWS_LAUNCHER_LOG_PROTOCOL = 1;',
    "const COMMANDS = ['--preflight', '--create-api-key', '--reset'] as const;",
    "command === undefined && logDirectory !== undefined && process.platform === 'win32'",
  ],
  'apps/api/src/windows-log/guard.ts': [
    'destinationInUse: 70,', 'destinationUnavailable: 71,', 'importFailedWritten: 72,', 'importFailedUnwritten: 73,',
    'startupFailedWritten: 74,', 'startupFailedUnwritten: 75,',
    "'module-not-found':", "'invalid-configuration':", "'store-held':", "'store-unavailable':",
    "'GraphGoblin application import failed' : 'GraphGoblin startup failed'",
    'deps.delay(GATEWAY_LOG_EXIT_FLUSH_MS).then(() => false)',
    'beforeExit: () => writer.settle(GATEWAY_LOG_EXIT_FLUSH_MS),',
    'openLog: (options) => openGatewayLog(options),',
    "if (name.toUpperCase() !== LAUNCHER_LOG_DIR_VARIABLE) continue;",
  ],
  'apps/api/src/windows-log/gateway-log-writer.ts': [
    'export const GATEWAY_LOG_SLOT_BYTES = 4 * 1024 * 1024;', 'export const GATEWAY_LOG_RECORD_BYTES = 64 * 1024;',
    'export const GATEWAY_LOG_PENDING_BYTES = 256 * 1024;', 'export const GATEWAY_LOG_EXIT_FLUSH_MS = 250;',
    'export const GATEWAY_LOG_MAX_FAULTS = 8;',
    'export const GATEWAY_LOG_BACKOFF_MS = [1_000, 2_000, 4_000, 8_000, 16_000, 32_000, 60_000] as const;',
    'gateway log record omitted: it exceeded the ${GATEWAY_LOG_RECORD_BYTES}-byte record limit',
    '"msg":"gateway log records dropped","dropped":${dropped}',
    "await open(path, mode === 'create' ? 'wx+' : 'r+', 0o600);",
    'export const nodeLogFileSystem: LogFileSystem = {',
    'schedule?: (callback: () => void, ms: number) => { cancel(): void };',
    'timer.unref();',
  ],
  'apps/api/src/windows-log/managed-root.ts': [
    "export const GATEWAY_LOG_PIPE_PREFIX = '\\\\\\\\.\\\\pipe\\\\GraphGoblin.GatewayLog.';",
    '.update(`graphgoblin-gateway-log-root/v1\\0dev=${dev}\\0ino=${ino}`)',
    'run: MetadataRunner = powerShellMetadata,',
    "error.code === 'EADDRINUSE' ? 'in-use' : 'reservation-failed'",
  ],
  'apps/api/src/serve.ts': [
    "if (message.startsWith('another GraphGoblin process')) return 'store-held';",
    "managed?.onStage('store');\n    const owner = await createContainer(config, { logger });",
    'await managed?.beforeExit();\n        process.exit(0);',
  ],
  'apps/api/src/gateway-logger.ts': [
    'export const managedAccessSerializers = {',
    'pino({ level: config.logLevel, serializers: managedAccessSerializers }, destination)',
    'pino({ level: config.logLevel });',
  ],
  'apps/api/src/instance-identity.ts': ['export const INSTANCE_PROTOCOL = 2;', 'protocol: INSTANCE_PROTOCOL,'],
  'apps/api/src/plugins/errors.ts': ['app.setNotFoundHandler((request, reply) =>\n    problem(reply, 404,'],
  'apps/api/src/routes/runs.ts': ["'/runs/:id',"],
  'packages/contracts/src/loop.ts': ['export const CURRENT_DEFINITION_FORMAT = 4 as const;'],
  'packages/infrastructure/src/process/scripts.ts': ["env: { ...(request.inheritEnv === false ? {} : this.baseEnv), ...request.env },"],
};
const predecessor = {
  'apps/api/src/instance-identity.ts': ['protocol: 1,'],
  'apps/windows-launcher/Launcher.cs': ['IntPtr outputHandle = CreateFile(log, 4, 3, IntPtr.Zero, 4, 0, IntPtr.Zero);'],
};

const files = {};
const checks = [];
async function scan(root, expected, table, label) {
  for (const [rel, needles] of Object.entries(table)) {
    const bytes = await readFile(join(root, ...rel.split('/')));
    const digest = sha(bytes);
    files[label + ':' + rel] = digest;
    if (expected) assert.equal(digest, expected[rel], label + ' ' + rel + ' differs from its binding');
    const text = bytes.toString('utf8').replaceAll('\r\n', '\n');
    for (const needle of needles) checks.push({ source: label, file: rel, needle, ok: text.includes(needle) });
  }
}
await scan(checkout, binding?.sourceFiles, candidate, binding ? 'candidate-frozen' : 'candidate-unfrozen');
await scan(baseline.checkout, baseline.sourceFiles, predecessor, 'predecessor-e21c');
const failures = checks.filter((check) => !check.ok);
console.log(JSON.stringify({ schema: 'gg438-supplemental-source-checks/v1', mode, checkout, head: binding?.head ?? null,
  checkedAt: new Date().toISOString(), files, checks: checks.length, failures }, null, 2));
process.exitCode = failures.length ? 1 : 0;
