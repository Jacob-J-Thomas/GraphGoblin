// #438 supplemental controls C-4, C-6, C-8 and C-9 on the exact built guard, writer, managed-root,
// serve and gateway-logger modules. The guard composition is the production one; only `openLog`
// (to supply the writer's documented fs/observe/schedule seams), the `delay` receipt and, for
// C-8, inspectLogRoot's documented metadata runner are wrapped. A parent process admits and
// orchestrates; each composed gateway runs in its own child (`--child`) because serve exits.
import assert from 'node:assert/strict';
import { appendFileSync, existsSync } from 'node:fs';
import { lstat, readFile, readdir, realpath, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import {
  admitSupplement, builtUrl, completeRecords, createSeam, fileState, gate, projectNode,
  RECORD, runCases, save, sha, SLOT, USERS,
} from './common.mjs';

const self = await realpath(fileURLToPath(import.meta.url));
const BUILT = ['apps/api/dist/windows-log/gateway-log-writer.js', 'apps/api/dist/windows-log/guard.js',
  'apps/api/dist/windows-log/managed-root.js', 'apps/api/dist/serve.js', 'apps/api/dist/gateway-logger.js'];
const CLOSED_KEYS = ['cause', 'detail', 'guidance', 'level', 'msg', 'pid', 'stage', 'time'];

if (process.argv[2] === '--child') await child(process.argv.slice(3));
else await parent(process.argv.slice(2));

// ---------------------------------------------------------------- child (composed gateway)
async function child([specPath, specDigest, ...extra]) {
  assert.deepEqual(extra, []);
  const raw = await readFile(specPath);
  assert.equal(sha(raw), specDigest);
  const spec = JSON.parse(raw.toString('utf8'));
  const emit = (event) => appendFileSync(spec.control, JSON.stringify({ t: performance.now(), ...event }) + '\n');
  const watchdog = setTimeout(() => { emit({ type: 'watchdog-expired' }); process.exit(97); }, spec.expiryMs);
  process.on('exit', (code) => emit({ type: 'exit', code }));
  const urls = {};
  for (const [rel, digest] of Object.entries(spec.built)) {
    const path = join(spec.checkout, ...rel.split('/'));
    assert.equal(sha(await readFile(path)), digest, rel);
    urls[rel] = pathToFileURL(path).href;
  }
  const W = await import(urls['apps/api/dist/windows-log/gateway-log-writer.js']);
  const G = await import(urls['apps/api/dist/windows-log/guard.js']);
  let stall;
  let writer;
  const arm = () => { stall = gate(spec.holdMs); emit({ type: 'armed', holdMs: spec.holdMs }); };
  const poll = setInterval(() => {
    if (stall && !stall.released && existsSync(spec.release)) { stall.open(); emit({ type: 'released-by-parent' }); }
  }, 50);
  poll.unref();
  const seam = createSeam(W.nodeLogFileSystem, SLOT, {
    write: async ({ handle, buffer, offset, length, position }) => {
      if (stall && !stall.used) {
        stall.used = true;
        emit({ type: 'write-stalled', length, position, pending: writer?.pendingBytes });
        await stall.promise;
        emit({ type: 'write-resumed', expired: stall.expired });
      }
      return handle.write(buffer, offset, length, position);
    },
  });
  // Mirrors the writer's default timer exactly (unref'd) and records the requested delay.
  const schedule = (callback, ms) => {
    emit({ type: 'schedule', ms });
    const timer = setTimeout(callback, ms);
    timer.unref();
    return { cancel: () => clearTimeout(timer) };
  };
  if (spec.serializers) {
    // Read-only receipts of the reached serializer input; the production function still decides.
    const L = await import(urls['apps/api/dist/gateway-logger.js']);
    const original = { ...L.managedAccessSerializers };
    const view = (request) => ({ id: request?.id, method: request?.method, url: request?.url,
      route: request?.routeOptions?.url, authorization: request?.headers?.authorization,
      acceptVersion: request?.headers?.['accept-version'], body: request?.body });
    L.managedAccessSerializers.req = (request) => {
      const output = original.req(request);
      emit({ type: 'serializer', kind: 'req', input: view(request), output });
      return output;
    };
    L.managedAccessSerializers.res = (reply) => {
      const output = original.res(reply);
      emit({ type: 'serializer', kind: 'res', input: { ...view(reply?.request), statusCode: reply?.statusCode }, output });
      return output;
    };
  }
  const load = spec.load === 'missing'
    ? () => import(pathToFileURL(spec.absentModule).href)
    : async () => {
      const real = await import(urls['apps/api/dist/serve.js']);
      return {
        startupFailureCause: real.startupFailureCause,
        serve: (options) => real.serve({ managed: { ...options.managed, beforeExit: () => {
          emit({ type: 'beforeExit', pending: writer?.pendingBytes, stalled: stall ? !stall.released : false });
          return options.managed.beforeExit().then((value) => { emit({ type: 'settled', value }); return value; });
        } } }),
      };
    };
  const production = G.productionDependencies(load);
  const deps = {
    ...production,
    openLog: async (options) => {
      writer = await W.openGatewayLog({ ...options, fs: seam.fs, schedule,
        observe: (event) => { seam.observe(event); emit({ type: 'writer', event }); } });
      emit({ type: 'opened', size: writer.size });
      return writer;
    },
    delay: (ms) => { emit({ type: 'delay', ms }); return production.delay(ms); },
  };
  if (spec.stall === 'from-start') arm();
  const started = performance.now();
  const code = await G.runManagedGateway(spec.root, deps);
  emit({ type: 'outcome', code: code ?? null, ms: performance.now() - started, pending: writer?.pendingBytes });
  if (code !== undefined) {
    // Let a held write finish after the outcome; it must not change the decided exit code.
    stall?.open();
    const settled = writer ? await writer.settle(2000) : null;
    emit({ type: 'after-outcome', settled, state: writer?.state, maxInFlight: seam.maxInFlight });
    clearTimeout(watchdog);
    process.exit(code);
  }
  emit({ type: 'ready', size: writer.size });
  if (spec.stall === 'after-ready') arm();
  if (spec.pendingProbe) {
    setInterval(() => emit({ type: 'pending', pending: writer.pendingBytes, state: writer.state,
      held: stall ? !stall.released : false }), 200).unref();
  }
}

// ---------------------------------------------------------------- parent (admitted orchestration)
async function parent(argv) {
  const job = await admitSupplement('guard-controls', argv);
  const { observe } = job.lib.native;
  const { healthy, request, startWork, releaseWork, workState } = job.lib.workload;
  const built = {};
  for (const rel of BUILT) {
    await builtUrl(job.binding, rel);
    built[rel] = job.binding.artifacts.outputFiles[rel];
  }
  const MR = await import(await builtUrl(job.binding, 'apps/api/dist/windows-log/managed-root.js'));
  const G = await import(await builtUrl(job.binding, 'apps/api/dist/windows-log/guard.js'));

  async function control(ctx, name, fields) {
    const file = join(ctx.evidence, name + '.control.jsonl');
    const release = join(ctx.evidence, name + '.release');
    const spec = { schema: 'gg438-guard-child/v1', checkout: job.binding.checkout, built, control: file, release,
      absentModule: join(ctx.evidence, 'qa438-absent-application.js'), expiryMs: 90_000, holdMs: 5000, ...fields };
    if (spec.load === 'missing') await assert.rejects(lstat(spec.absentModule), { code: 'ENOENT' });
    const specPath = join(ctx.evidence, name + '.spec.json');
    await save(specPath, spec);
    const digest = sha(await readFile(specPath));
    const events = async () => {
      try { return (await readFile(file, 'utf8')).split('\n').filter(Boolean).map((row) => JSON.parse(row)); } catch (error) {
        if (error.code === 'ENOENT') return [];
        throw error;
      }
    };
    const waitFor = (label, type, ms = 30_000) => observe(label, async () => (await events()).find((e) => e.type === type), ms);
    return { spec, specPath, digest, file, release, events, waitFor, argv: [self, '--child', specPath, digest] };
  }

  async function gatewayRecords(root) {
    // A concurrent read can end inside the batch being written; parse complete records only.
    const bytes = await readFile(join(root, 'gateway.log'));
    return completeRecords(bytes.subarray(0, bytes.lastIndexOf(10) + 1), RECORD).map((row) => row.value);
  }

  async function outcomeCase(ctx, variant) {
    const out = {};
    for (const [stall, expected] of variant.codes) {
      const name = variant.name + (stall ? '-held' : '-free');
      const root = await ctx.privateDir(name);
      const config = variant.load === 'serve' ? ctx.config({ dataDir: await ctx.store(name), port: await ctx.port(),
        environment: { GG_DB_URL: 'file:' + variant.corrupt.replaceAll('\\', '/') } }) : null;
      const c = await control(ctx, name, { root, load: variant.load, stall: stall ? 'from-start' : 'none', holdMs: 15_000 });
      const childEnv = config ? ctx.gatewayEnv(config) : ctx.env;
      const call = await ctx.direct(name, c.argv[0], c.argv.slice(1), childEnv, { expect: expected });
      const events = await c.events();
      await ctx.put(name + '-events.json', events);
      const delay = events.find((e) => e.type === 'delay');
      const outcome = events.find((e) => e.type === 'outcome');
      assert.equal(delay?.ms, 250, 'acknowledgement wait is not the exact 250 ms flush');
      assert.equal(outcome.code, expected);
      const waited = outcome.t - delay.t;
      if (stall) {
        assert(waited >= 220 && waited <= 500, 'held acknowledgement decided after ' + waited + ' ms');
        assert(events.some((e) => e.type === 'write-stalled'));
      } else assert(waited < 250, 'unheld acknowledgement took ' + waited + ' ms');
      const records = await gatewayRecords(root);
      const closed = records.filter((r) => r.msg === variant.msg && r.pid === call.pid);
      if (!stall) {
        assert.equal(closed.length, 1, 'acknowledged closed record missing');
        assert.deepEqual(Object.keys(closed[0]).sort(), CLOSED_KEYS);
        assert.deepEqual([closed[0].stage, closed[0].cause], variant.closed);
      }
      const after = events.find((e) => e.type === 'after-outcome');
      out[name] = { exit: call.exit.code, waitedMs: waited, closedRecordsAfterExit: closed.length,
        settledAfterOutcome: after?.settled, maxInFlight: after?.maxInFlight };
      if (config) assert.deepEqual((await readdir(config.DataDir)).filter((n) => n.endsWith('.lock')), []);
    }
    return out;
  }

  async function c4Import(ctx) {
    return { level: 'controlled composition: real missing-module import, production guard and writer',
      ...await outcomeCase(ctx, { name: 'import', load: 'missing', codes: [[false, 72], [true, 73]],
        msg: 'GraphGoblin application import failed', closed: ['import', 'module-not-found'] }) };
  }

  async function c4Startup(ctx) {
    const directory = await ctx.dir('corrupt-qa438-dbpath-canary');
    const corrupt = join(directory, 'qa438-not-sqlite.db');
    await writeFile(corrupt, 'qa438-db-bytes-canary deliberately not SQLite\n', { flag: 'wx' });
    const out = await outcomeCase(ctx, { name: 'startup', load: 'serve', corrupt, codes: [[false, 74], [true, 75]],
      msg: 'GraphGoblin startup failed', closed: ['store', 'store-unavailable'] });
    return { level: 'controlled composition: real built serve() store failure', ...out };
  }

  async function serveChild(ctx, name, fields) {
    const root = await ctx.privateDir(name);
    const config = ctx.config({ dataDir: await ctx.store(name), port: await ctx.port() });
    const c = await control(ctx, name, { root, load: 'serve', ...fields });
    const childEnv = ctx.gatewayEnv(config);
    const current = { label: name, port: config.Port, store: config.DataDir, entry: self, extraArgv: c.argv.slice(1),
      expected: await ctx.fingerprint(job.binding.checkout, childEnv, name) };
    ctx.serveDirect(name, c.argv, childEnv, current);
    await c.waitFor(name + ' ready', 'ready');
    current.proof = await ctx.proof(current);
    return { root, config, c, current };
  }

  async function c4Graceful(ctx) {
    const { c, current } = await serveChild(ctx, 'graceful', { stall: 'after-ready', holdMs: 20_000 });
    await c.waitFor('stall armed', 'armed');
    await healthy(current.port);
    await c.waitFor('access record write held', 'write-stalled', 5000);
    await ctx.drain(current);
    const events = await c.events();
    await ctx.put('graceful-events.json', events);
    const before = events.find((e) => e.type === 'beforeExit');
    const exit = events.find((e) => e.type === 'exit');
    const settle = events.filter((e) => e.type === 'schedule' && e.t >= before.t);
    assert(before.stalled, 'the write must still be held when beforeExit is entered');
    assert.deepEqual(settle.map((e) => e.ms), [250]);
    assert.equal(events.find((e) => e.type === 'settled').value, false);
    assert(!events.some((e) => e.type === 'write-resumed'), 'held write completed before exit');
    const window = exit.t - before.t;
    assert(window >= 220 && window <= 500, 'exit flush window was ' + window + ' ms');
    assert.equal(exit.code, 0);
    return { level: 'controlled composition: real serve drain with a held writer operation', windowMs: window,
      drainExit: current.stopped.exit };
  }

  async function c6(ctx) {
    const { c, current } = await serveChild(ctx, 'liveness', { stall: 'after-ready', holdMs: 60_000, expiryMs: 120_000, pendingProbe: true });
    await c.waitFor('stall armed', 'armed');
    const first = await healthy(current.port);
    const second = await healthy(current.port);
    const stalled = await c.waitFor('access write held', 'write-stalled', 5000);
    let held;
    const work = await startWork({ port: current.port, directory: await ctx.dir('work'), node: projectNode,
      definitionFormat: 4, observe }, (state) => { held = state; current.work = state; });
    await releaseWork(work);
    const done = await observe('provider-free Script run terminal', async () => {
      const run = await workState(current.port, work);
      return run.status === 'succeeded' ? run : false;
    }, 20_000);
    const during = await c.events();
    assert(!during.some((e) => e.type === 'write-resumed'), 'the write was released before work completed');
    const pending = during.filter((e) => e.type === 'pending' && e.held).map((e) => e.pending);
    assert(pending.length > 0 && Math.max(...pending) <= 262144);
    assert(Math.max(...pending) > (stalled.pending ?? 0), 'pending bytes did not grow while I/O was held');
    await writeFile(c.release, 'release\n', { flag: 'wx' });
    await c.waitFor('held write resumed', 'write-resumed', 5000);
    await observe('writer drained', async () => (await c.events()).some((e) => e.type === 'pending' && !e.held && e.pending === 0), 10_000);
    await ctx.drain(current);
    await ctx.put('liveness-events.json', await c.events());
    return { level: 'controlled composition: real HTTP and Script work while the writer operation is held',
      health: [first, second], run: { id: done.id, status: done.status }, maxPending: Math.max(...pending), scriptPid: held?.scriptPid };
  }

  async function c8(ctx) {
    const root = await ctx.privateDir('c8-root');
    await writeFile(join(root, 'gateway.log'), '{"msg":"qa438-c8-existing"}\n', { flag: 'wx' });
    const names = ['gateway.log', 'gateway.log.1'];
    // The unchanged production metadataScript with production's executable and argv, run by the
    // bounded native runner in the case-isolated ctx.env (never the supervisor profile or TEMP).
    let queries = 0;
    const metadata = async (script) => {
      const call = await ctx.native.run('c8 production metadata query ' + ++queries,
        join(ctx.native.env.SystemRoot, 'System32/WindowsPowerShell/v1.0/powershell.exe'),
        ['-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(script, 'utf16le').toString('base64')],
        ctx.evidence, { childEnv: ctx.env, timeout: 20_000, reapReadOnly: true });
      assert.equal(call.exit.code, 0, 'metadata query failed: ' + call.stderr);
      return call.stdout;
    };
    const genuine = await metadata(MR.metadataScript(root, names));
    await ctx.raw('c8-genuine-metadata.json', Buffer.from(genuine, 'utf8'));
    MR.assertPrivateLogRoot(MR.parseMetadata(genuine, names), names);
    const foreign = 'S-1-5-21-1111111111-2222222222-3333333333-1001';
    const list = (value) => Array.isArray(value) ? value : value == null ? [] : [value];
    const variants = [
      ['root-owner', (m) => { m.rootOwner = foreign; }, 'not-private'],
      ['root-users-allow', (m) => { m.rootRules = [...list(m.rootRules), { sid: USERS, allow: true }]; }, 'not-private'],
      ['entry-owner', (m) => { m.entries['gateway.log'].owner = foreign; }, 'unsafe-entry'],
      ['entry-users-allow', (m) => { m.entries['gateway.log'].rules = [...list(m.entries['gateway.log'].rules), { sid: USERS, allow: true }]; }, 'unsafe-entry'],
    ];
    const rows = [];
    for (const [name, mutate, reason] of variants) {
      const value = JSON.parse(genuine);
      mutate(value);
      const text = JSON.stringify(value);
      assert.throws(() => MR.assertPrivateLogRoot(MR.parseMetadata(text, names), names),
        (error) => error.name === 'LogRootRefusedError' && error.reason === reason);
      rows.push({ name, reason, sha256: sha(text) });
    }
    const before = await Promise.all(names.map((n) => fileState(join(root, n))));
    let opened = false;
    let loaded = false;
    let served = false;
    const code = await G.runManagedGateway(root, {
      ...G.productionDependencies(async () => { loaded = true; throw new Error('application must not load'); }),
      inspect: (r, n) => MR.inspectLogRoot(r, n, async (script) => {
        const value = JSON.parse(await metadata(script));
        value.rootOwner = foreign;
        served = true;
        return JSON.stringify(value);
      }),
      openLog: async () => { opened = true; throw new Error('writer must not open'); },
    });
    // `served` shows the 71 came from the mutated genuine metadata, not a failed query.
    assert.deepEqual([code, opened, loaded, served, queries], [71, false, false, true, 2]);
    assert.deepEqual(await Promise.all(names.map((n) => fileState(join(root, n)))), before);
    const admitted = await MR.resolveLogRoot(root);
    const reservation = await MR.reserveLogRoot(admitted.pipeName);
    await reservation.release();
    return { level: 'controlled: genuine NTFS metadata varied only at owner SID or Allow ACE (no native foreign-owner coverage)',
      variants: rows, guardExit: code };
  }

  async function c9(ctx) {
    const { root, c, current } = await serveChild(ctx, 'serializers', { stall: 'none', serializers: true });
    const canary = { query: 'qa438c9-query-5b1f', auth: 'qa438c9-auth-77e2', segment: 'qa438c9-segment-c3d0',
      version: '123.45.67', body: 'qa438c9-body-9a41' };
    const stimuli = [
      { name: 'query', path: '/runs/qa438-run-id?qa=' + canary.query, field: 'url' },
      { name: 'auth', path: '/healthz?qa438c9=auth', headers: { authorization: 'Bearer ' + canary.auth }, field: 'authorization', status: 401 },
      { name: 'version', path: '/' + canary.segment, headers: { 'accept-version': canary.version }, field: 'acceptVersion', status: 404 },
      { name: 'body', path: '/loops', method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ definition: { schemaVersion: 4, name: 'qa438 c9', nodes: [], edges: [] }, qa438BodyCanary: canary.body }), field: 'body' },
    ];
    for (const item of stimuli) {
      const response = await request(current.port, item.path, { method: item.method ?? 'GET', headers: item.headers, body: item.body });
      item.observedStatus = response.status;
      await response.arrayBuffer();
      if (item.status) assert.equal(response.status, item.status);
    }
    // Each stimulus maps to its own serializer receipts (one reqId by exact URL, completion with the
    // observed status) and to that reqId's incoming/completed pair on the target log. Readiness and
    // proof requests carry other reqIds, so they cannot satisfy this wait.
    const { receipts, records } = await observe('exact stimulus access pairs written', async () => {
      const seen = (await c.events()).filter((e) => e.type === 'serializer');
      const written = await gatewayRecords(root);
      for (const item of stimuli) {
        const ids = new Set(seen.filter((e) => e.kind === 'req' && e.input.url === item.path).map((e) => e.input.id));
        if (ids.size !== 1) return false;
        const [id] = ids;
        if (!seen.some((e) => e.kind === 'res' && e.input.id === id && e.output.statusCode === item.observedStatus)) return false;
        const pair = written.filter((r) => r.reqId === id).map((r) => r.msg);
        if (!pair.includes('incoming request') || !pair.includes('request completed')) return false;
      }
      return { receipts: seen, records: written };
    }, 5000);
    const values = Object.values(canary);
    const rows = [];
    const skippedVariants = [];
    for (const item of stimuli) {
      const req = receipts.find((e) => e.kind === 'req' && e.input.url === item.path);
      assert(req, 'no reached request serializer input for ' + item.name);
      const res = receipts.find((e) => e.kind === 'res' && e.input.id === req.input.id && e.output.statusCode === item.observedStatus);
      assert(res, 'no reached completion serializer input for ' + item.name);
      const reached = item.field === 'body' ? JSON.stringify(res.input.body ?? null) : String(req.input[item.field] ?? '');
      const reachedCanary = item.field === 'body' ? reached.includes(canary.body) : values.some((value) => reached.includes(value));
      if (item.field !== 'body') assert(reachedCanary, item.name + ' canary did not reach the serializer input');
      // A body canary absent from the reached completion-side input is recorded as not exercised.
      else if (!reachedCanary) skippedVariants.push(item.name);
      assert(Object.keys(req.output).every((k) => ['method', 'route'].includes(k)));
      assert(Object.keys(res.output).every((k) => ['method', 'route', 'statusCode'].includes(k)));
      assert.equal(res.output.statusCode, item.observedStatus);
      assert.equal(req.output.route, req.input.route);
      const access = records.filter((r) => r.reqId === req.input.id && ['incoming request', 'request completed'].includes(r.msg));
      assert.equal(access.length, 2, 'access pair missing for ' + item.name);
      assert.deepEqual(access.find((r) => r.msg === 'incoming request').req, req.output);
      assert.deepEqual(access.find((r) => r.msg === 'request completed').res, res.output);
      for (const record of access) for (const value of values) assert(!JSON.stringify(record).includes(value), 'canary in access record');
      rows.push({ name: item.name, reqId: req.input.id, status: item.observedStatus, route: req.output.route ?? null,
        reachedCanary, bodyAtIncoming: req.input.body !== undefined, bodyAtCompletion: res.input.body !== undefined,
        ...(skippedVariants.includes(item.name)
          ? { notExercised: 'POST body canary absent from the reached completion-side serializer input; no claim' } : {}) });
    }
    const elsewhere = records.filter((r) => !['incoming request', 'request completed'].includes(r.msg) &&
      values.some((value) => JSON.stringify(r).includes(value)));
    await ctx.drain(current);
    await ctx.put('c9-receipts.json', { receipts, rows, nonAccessRecordsWithCanary: elsewhere, skippedVariants });
    return { level: 'controlled read-only receipt of the reached production serializer input; real Fastify/Pino/writer',
      rows, nonAccessRecordsWithCanary: elsewhere.length,
      exercised: rows.filter((row) => !row.notExercised).map((row) => row.name), skippedVariants };
  }

  await runCases(job, [
    { id: 'c4-import-flush', level: 'controlled', criteria: ['C-4'], run: c4Import },
    { id: 'c4-startup-flush', level: 'controlled', criteria: ['C-4'], run: c4Startup },
    { id: 'c4-graceful-flush', level: 'controlled', criteria: ['C-4'], run: c4Graceful },
    { id: 'c6-stall-liveness', level: 'controlled', criteria: ['C-6'], run: c6 },
    { id: 'c8-privacy-metadata', level: 'controlled', criteria: ['C-8'], run: c8 },
    { id: 'c9-serializer-input', level: 'controlled', criteria: ['C-9', 'N-3'], run: c9 },
  ]);
}
