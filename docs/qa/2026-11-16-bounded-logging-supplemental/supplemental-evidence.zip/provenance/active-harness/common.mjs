// #438 supplemental QA: one bounded fixture lifetime shared by the supplemental modules.
// It reuses the sealed V4/V3 helpers by digest and adds only admission, case lifetime, holder,
// drain, snapshot, cleanup-readback and production-writer seam utilities. Nothing here runs a
// case by itself; a module calls admitSupplement() and runCases().
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { lstat, mkdir, readFile, realpath, symlink, writeFile } from 'node:fs/promises';
import { dirname, isAbsolute, join, relative, resolve, sep } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

export const suite = await realpath(fileURLToPath(new URL('.', import.meta.url)));
export const batch = await realpath(join(suite, '..'));
const profileRoot = await realpath(join(batch, '..', '..'));
export const projectNode = await realpath(join(profileRoot,
  '.claude/codex-runs/GraphGoblin/runtime/node-v22.23.4-win-x64/node.exe'));
export const HEX = /^[a-f0-9]{64}$/u;
export const COMMIT = /^[a-f0-9]{40}$/u;
export const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
export const CONTRACT_SHA256 = 'a1a02313635d959a16dbfa26b770722c72bbe3e11bbc390ecd0e76d28a4cf474';
export const BASELINE = {
  bindingSha256: '85a77468ebe1bacfed414081261287809febf793785e9d28e2223939ff9820de',
  head: 'e21c24be9cef109ef438fd2df4c1583bc570b1cb',
  tree: 'd064706fb48def7bacac5e434f96825c5850d214',
  launcherSha256: '57b4fad9fea910ddcd3bef0193f9fb0018072afa54442f6c706a214a1a3923aa',
};
export const SYSTEM = 'S-1-5-18';
export const ADMINISTRATORS = 'S-1-5-32-544';
export const USERS = 'S-1-5-32-545';
// Sealed, root-reviewed helper bytes reused unchanged. Their digests are fixed here and again in
// the admission so a changed helper refuses before any fixture exists.
export const REUSED = {
  'launcher-438-candidate-qa-preparation/binding.mjs': 'e8b3109fd487da958b09aff98a2942c270505a56885bdff844a926d62676955a',
  'launcher-438-candidate-qa-preparation/native.mjs': '19bf2a8a953eea6538f6515704aaace45ed832773528cca53862440e20bde837',
  'launcher-438-candidate-qa-preparation/controls.mjs': '07b4670201aa225ed787fcfc549c4a6bc18f6498691317df66f212dff533b69e',
  'launcher-438-native-preparation-v3/binding.mjs': 'd807d1f993f126684362f3764fd38987822ea793b0d735af47fb01beb38dd3fb',
  'launcher-438-native-preparation-v3/inventory.mjs': '8dcb53f991b13d815bd97bcae7046aa73a8d90efae20c491ec84b35935bb03d1',
  'launcher-438-native-preparation-v3/workload.mjs': '4419c0577ac7c0bc2a2d94986ca018c8c162065e8e0036c3b86520ede17acb8d',
  'launcher-438-native-preparation-v3/windows.mjs': 'f9cfdf993c15f7e53db1caf6837b29b3073c533804623fa08c77c6f5e3a20cd5',
  'runtime-410-build-preparation/artifacts.mjs': '479b4a723e12f7d11da926d99c83ced2ab9e26e5eedffc7dd74000c65a806226',
  'runtime-410-build-preparation/common.mjs': '54f0a901a702eb78de69a6f0df7f9293e358689cb9a7af1016f906317da03ae4',
};
export const MODULE_FILES = ['common.mjs', 'writer-controls.mjs', 'guard-controls.mjs',
  'native-startup.mjs', 'native-sharing.mjs', 'native-predecessor.mjs', 'LauncherLogControl.cs',
  'compile-helper.mjs', 'source-checks.mjs', 'launch.ps1'];
export const MODULES = ['writer-controls', 'guard-controls', 'native-startup', 'native-sharing',
  'native-predecessor'];
export const SLOT = 4 * 1024 * 1024;
export const RECORD = 64 * 1024;
export const PENDING = 256 * 1024;
export const LAUNCHER_SLOT = 256 * 1024;
export const LAUNCHER_RECORD = 4096;

export const describe = (error) => error instanceof Error
  ? { name: error.name, message: error.message, stack: error.stack, code: error.code,
    actual: error.actual, expected: error.expected }
  : { value: String(error) };
const json = (value) => JSON.stringify(value, (_key, item) =>
  typeof item === 'bigint' ? item.toString() : item instanceof Error ? describe(item) : item, 2) + '\n';
export const save = (file, value) => writeFile(file, json(value), { flag: 'wx' });

export function within(root, child) {
  const tail = relative(root, child);
  return tail !== '' && tail !== '..' && !tail.startsWith('..' + sep) && !isAbsolute(tail);
}
export function under(root, suffix) {
  assert.match(suffix, /^(?:[a-zA-Z0-9_.][a-zA-Z0-9 ._-]*\/)*[a-zA-Z0-9_.][a-zA-Z0-9 ._-]*$/u);
  assert(suffix.split('/').every((piece) => !/[. ]$/u.test(piece) &&
    !/^(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:[.]|$)/iu.test(piece)), suffix);
  const path = resolve(root, suffix);
  assert(within(root, path), suffix);
  return path;
}
export async function readBound(ref, root) {
  assert(ref && HEX.test(ref.sha256), 'Unadmitted digest: ' + JSON.stringify(ref));
  assert(isAbsolute(ref.path), 'Unadmitted path: ' + ref.path);
  if (root) assert(within(root, ref.path), ref.path);
  assert.equal(await realpath(ref.path), resolve(ref.path));
  const stat = await lstat(ref.path);
  assert(stat.isFile() && stat.nlink === 1, ref.path);
  const bytes = await readFile(ref.path);
  assert.equal(sha(bytes), ref.sha256, ref.path);
  return bytes;
}
async function reusedImport(rel) {
  const path = under(batch, rel);
  await readBound({ path, sha256: REUSED[rel] }, batch);
  return import(pathToFileURL(path).href);
}

/** Admit one supplemental module invocation. Refuses placeholders, drift and reused state. */
export async function admitSupplement(moduleName, argv) {
  assert(MODULES.includes(moduleName));
  assert.equal(process.platform, 'win32');
  assert.equal(process.version, 'v22.23.4');
  assert.equal(await realpath(process.execPath), projectNode);
  assert.deepEqual(process.execArgv, []);
  assert(!Object.keys(process.env).some((key) => key.toUpperCase() === 'NODE_OPTIONS'));
  assert(!Object.keys(process.env).some((key) => key.toUpperCase() === 'GG_WINDOWS_LAUNCHER_LOG_DIR'));
  const [admissionPath, digest, ...extra] = argv;
  assert.deepEqual(extra, []);
  const raw = await readBound({ path: admissionPath, sha256: digest }, batch);
  const admission = JSON.parse(raw.toString('utf8'));
  assert.equal(admission.schema, 'gg438-supplemental-admission/v1');
  assert.match(admission.attempt, /^supplemental-attempt-[1-9][0-9]*$/u);
  assert(Array.isArray(admission.enabledModules) && admission.enabledModules.includes(moduleName),
    'Module not admitted: ' + moduleName);
  assert.deepEqual(admission.contract, { path: under(batch, 'launcher-438-final-contract.md'), sha256: CONTRACT_SHA256 });
  await readBound(admission.contract, batch);
  assert.deepEqual(Object.keys(admission.modules).sort(), [...MODULE_FILES].sort());
  const dependencies = [admission.contract];
  for (const [file, value] of Object.entries(admission.modules)) {
    dependencies.push({ path: under(suite, file), sha256: value });
  }
  assert.deepEqual(admission.reused, REUSED, 'Reused helper digests changed');
  for (const [rel, value] of Object.entries(REUSED)) dependencies.push({ path: under(batch, rel), sha256: value });
  for (const dependency of dependencies) await readBound(dependency, batch);
  const lib = {
    v4binding: await reusedImport('launcher-438-candidate-qa-preparation/binding.mjs'),
    native: await reusedImport('launcher-438-candidate-qa-preparation/native.mjs'),
    controls: await reusedImport('launcher-438-candidate-qa-preparation/controls.mjs'),
    inventory: await reusedImport('launcher-438-native-preparation-v3/inventory.mjs'),
    workload: await reusedImport('launcher-438-native-preparation-v3/workload.mjs'),
    windows: await reusedImport('launcher-438-native-preparation-v3/windows.mjs'),
    artifacts: await reusedImport('runtime-410-build-preparation/artifacts.mjs'),
  };
  const binding = JSON.parse((await readBound(admission.candidateBinding, batch)).toString('utf8'));
  assert.equal(binding.schema, 'gg438-native-source-build/v1');
  assert.equal(binding.mode, 'candidate');
  assert.equal(binding.node.path, projectNode);
  assert(COMMIT.test(binding.head) && binding.head !== binding.actualMain && COMMIT.test(binding.tree));
  const worktrees = await realpath(join(profileRoot, '.codex', 'worktrees'));
  assert.equal(binding.checkout, under(worktrees, 'gg-20261116-bounded-logs/GraphGoblin'));
  assert.deepEqual(admission.baselineBinding, {
    path: under(batch, 'launcher-438-baseline-binding-02.json'), sha256: BASELINE.bindingSha256,
  });
  const baseline = JSON.parse((await readBound(admission.baselineBinding, batch)).toString('utf8'));
  assert.deepEqual([baseline.mode, baseline.head, baseline.tree, baseline.launcher.sha256],
    ['baseline', BASELINE.head, BASELINE.tree, BASELINE.launcherSha256]);
  const helper = admission.helper;
  assert.equal(helper.source.path, under(suite, 'LauncherLogControl.cs'));
  assert.equal(helper.source.sha256, admission.modules['LauncherLogControl.cs']);
  const receipt = JSON.parse((await readBound(helper.compileReceipt, batch)).toString('utf8'));
  assert.equal(receipt.schema, 'gg438-supplemental-helper-compile/v1');
  assert.equal(receipt.exitCode, 0);
  assert.equal(receipt.purpose, 'frozen', 'A compile-check helper is never admissible');
  assert.deepEqual([receipt.checkout, receipt.head, receipt.tree], [binding.checkout, binding.head, binding.tree]);
  assert.equal(receipt.inputs.launcher.sha256, binding.sourceFiles['apps/windows-launcher/Launcher.cs']);
  assert.equal(receipt.inputs.control.sha256, helper.source.sha256);
  assert.deepEqual(receipt.output, helper.executable);
  await readBound(helper.executable, batch);
  for (const ref of [admission.candidateBinding, admission.baselineBinding, helper.compileReceipt, helper.executable]) {
    dependencies.push(ref);
  }
  const fixtureParent = admission.fixtureParent;
  assert.equal(fixtureParent.path, under(suite, 'attempts'));
  assert.equal(await realpath(fixtureParent.path), fixtureParent.path);
  assert(!(await lstat(fixtureParent.path)).isSymbolicLink());
  for (const field of ['ownerSid', 'sddl']) assert(typeof fixtureParent[field] === 'string' && fixtureParent[field].length > 0);
  assert.equal(fixtureParent.protected, true);
  const limits = admission.limits;
  assert.deepEqual(limits.pressure, { requests: 100000, batch: 256, workers: 12, milliseconds: 180000 });
  assert.deepEqual(limits.excludedPorts, [4747, 4748]);
  const attemptDir = under(fixtureParent.path, admission.attempt);
  await mkdir(attemptDir, { recursive: true });
  assert.equal(await realpath(attemptDir), attemptDir);
  const moduleDir = under(attemptDir, moduleName);
  await mkdir(moduleDir); // Refuses an already-used module attempt.
  const evidence = under(moduleDir, 'evidence');
  await mkdir(evidence);
  await mkdir(under(moduleDir, 'cases'));
  const processRecords = [];
  const native = lib.native.createNative(evidence, processRecords);
  const parent = await parentReadback(native, fixtureParent.path);
  assert.equal(parent.owner, fixtureParent.ownerSid);
  assert.equal(parent.sddl, fixtureParent.sddl, 'Fixture parent DACL differs from the root admission');
  assert.equal(parent.protected, true);
  assert.deepEqual(parent.allowed.sort(), [parent.user, SYSTEM, ADMINISTRATORS].sort());
  const job = {
    moduleName, admission, admissionPath, digest, raw, binding, baseline, helper, lib, moduleDir, evidence,
    native, processRecords, dependencies, ports: new Set(), parent,
    put: (name, value) => save(under(evidence, name), value),
    cfg: { mode: 'candidate', binding: admission.candidateBinding, gatewayEntry: 'apps/api/dist/main.js',
      artifactModuleSha256: REUSED['runtime-410-build-preparation/artifacts.mjs'],
      nativeModuleSha256: REUSED['launcher-438-candidate-qa-preparation/native.mjs'] },
    collectArtifacts: lib.artifacts.collectArtifacts,
    common: { path: under(batch, 'runtime-410-build-preparation/common.mjs'),
      sha256: REUSED['runtime-410-build-preparation/common.mjs'] },
    path: admissionPath,
  };
  await writeFile(under(evidence, 'admission.json'), raw, { flag: 'wx' });
  job.opening = await lib.v4binding.verify(job);
  await job.put('opening-binding.json', { opening: job.opening, parent });
  return job;
}

/** Verified URL of one frozen built file of the candidate (or baseline) checkout. */
export async function builtUrl(binding, rel) {
  const path = join(binding.checkout, ...rel.split('/'));
  const expected = binding.artifacts.outputFiles[rel];
  assert(HEX.test(expected ?? ''), 'Not a frozen built file: ' + rel);
  assert.equal(sha(await readFile(path)), expected, rel);
  return pathToFileURL(path).href;
}

async function parentReadback(native, path) {
  const reply = await native.runPowerShell('fixture parent owner, protection and DACL', String.raw`
$ErrorActionPreference = 'Stop'
$acl = Get-Acl -LiteralPath $env:QA438_FIXTURE_PARENT
$user = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
$allowed = @($acl.GetAccessRules($true, $true, [Security.Principal.SecurityIdentifier]) |
  Where-Object AccessControlType -eq Allow | ForEach-Object { $_.IdentityReference.Value } | Sort-Object -Unique)
$attributes = [int][IO.File]::GetAttributes($env:QA438_FIXTURE_PARENT)
[Console]::WriteLine(([ordered]@{ user = $user; owner = $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value
  allowed = $allowed; protected = $acl.AreAccessRulesProtected; sddl = $acl.Sddl; attributes = $attributes } | ConvertTo-Json -Compress))
`, { extraEnv: { QA438_FIXTURE_PARENT: path } });
  const observed = JSON.parse(reply.stdout);
  assert.equal(observed.attributes & 0x410, 0x10, 'Fixture parent must be a plain directory');
  return observed;
}

/** Sequential cases. The first failure stops the module; later cases are recorded as skipped. */
export async function runCases(job, cases) {
  const rows = [];
  const result = { module: job.moduleName, attempt: job.admission.attempt, startedAt: new Date().toISOString(), rows };
  let stopped = false;
  for (const item of cases) {
    const row = { id: item.id, level: item.level, criteria: item.criteria };
    rows.push(row);
    if (stopped) { row.status = 'skipped-after-first-failure'; continue; }
    const ctx = await openCase(job, item.id);
    const started = performance.now();
    row.startedAt = new Date().toISOString();
    try {
      row.observed = await item.run(ctx);
      row.status = row.observed?.notExercised ? 'not-exercised' : 'passed';
      // Skipped variants are listed apart; only the exercised variants carry this row's status.
      if (row.observed?.skippedVariants?.length) row.skippedVariants = row.observed.skippedVariants;
    } catch (error) {
      row.status = 'failed';
      row.failure = describe(error);
      result.firstFailure = { case: item.id, ...row.failure };
      stopped = true;
      await ctx.put('first-failure.json', row.failure).catch(() => undefined);
    } finally {
      row.cleanup = await ctx.cleanup();
      row.elapsedMs = Math.round(performance.now() - started);
      row.endedAt = new Date().toISOString();
      if (row.cleanup.errors.length > 0) {
        stopped = true;
        if (row.status !== 'failed') row.status = 'cleanup-failed';
        result.firstFailure ??= { case: item.id, cleanup: row.cleanup.errors };
      }
      await ctx.put('case-result.json', row).catch(() => undefined);
    }
  }
  try {
    const closing = await job.lib.v4binding.verify(job);
    assert.deepEqual(closing, job.opening);
    result.closing = closing;
  } catch (error) { result.bindingError = describe(error); }
  result.completedAt = new Date().toISOString();
  result.status = result.firstFailure || result.bindingError ? 'incomplete' : 'observed';
  await job.put('result.json', result);
  process.exitCode = result.status === 'observed' ? 0 : 1;
  return result;
}

const lockNames = ['graphgoblin.lock', 'graphgoblin.db.graphgoblin.lock'];

/** One case: owned directories, process receipts, product environment and scoped cleanup. */
export async function openCase(job, id) {
  assert.match(id, /^[a-z0-9][a-z0-9-]*$/u);
  const { lib, binding } = job;
  const { observe, refused, selectPort } = lib.native;
  const root = under(job.moduleDir, 'cases/' + id);
  await mkdir(root);
  const evidence = under(root, 'evidence');
  const fixture = under(root, 'fixture');
  await mkdir(evidence);
  await mkdir(fixture);
  const records = [];
  const native = lib.native.createNative(evidence, records);
  const ensure = async (path) => {
    assert(path === fixture || within(fixture, path), path);
    await mkdir(path, { recursive: true });
    assert.equal(await realpath(path), path);
    return path;
  };
  const temp = await ensure(under(fixture, 'temp'));
  const profile = await ensure(under(fixture, 'profile'));
  const storesDir = await ensure(under(fixture, 'stores'));
  const env = { ...native.env, PATH: dirname(projectNode) + ';' + native.env.PATH, TEMP: temp, TMP: temp,
    USERPROFILE: profile, APPDATA: await ensure(under(profile, 'Roaming')),
    LOCALAPPDATA: await ensure(under(profile, 'Local')) };
  const ctx = {
    id, job, root, evidence, fixture, temp, storesDir, native, records, env, binding,
    gateways: [], holders: [], links: [], stores: [], launcherPids: [], ports: [], aclRestores: [],
    put: (name, value) => save(under(evidence, name), value),
    raw: (name, bytes) => writeFile(under(evidence, name), bytes, { flag: 'wx' }),
    dir: (rel) => ensure(under(fixture, rel)),
    async privateDir(rel) {
      const path = await ensure(under(fixture, rel));
      await ctx.put('privacy-' + rel.replaceAll('/', '-') + '.json',
        await lib.controls.privateRootReadback(native, path));
      return path;
    },
    async store(name) {
      const path = under(storesDir, name);
      await mkdir(path);
      ctx.stores.push(path);
      return path;
    },
    async port() {
      for (let count = 0; count < 4; count++) {
        const port = await selectPort();
        if (job.ports.has(port)) continue;
        assert(await refused(port));
        job.ports.add(port);
        ctx.ports.push(port);
        return port;
      }
      throw new Error('Could not obtain a distinct fixture loopback port');
    },
    config({ repo = binding.checkout, dataDir, port, environment = {}, startup = 25 }) {
      return { Repo: repo, Node: projectNode, DataDir: dataDir, Port: port,
        LauncherAppUserModelId: 'GraphGoblin.QA438.Supplement', StartupTimeoutSeconds: startup,
        WindowTimeoutSeconds: 2,
        Environment: { GG_LOG_LEVEL: 'info', GG_REQUIRE_API_KEY: 'false', GG_OLLAMA_ENABLED: 'false',
          GG_SWAGGER_UI: 'false', ...environment } };
    },
    async writeConfig(directory, name, value) {
      const path = under(directory, name + '.json');
      await writeFile(path, typeof value === 'string' ? value : JSON.stringify(value, null, 2), { flag: 'wx' });
      return path;
    },
    /** Gateway environment as the launcher would compose it, for direct guarded/shell runs. */
    gatewayEnv(config, extra = {}) {
      return { ...env, ...config.Environment, GG_HOST: '127.0.0.1', GG_PORT: String(config.Port),
        GG_DATA_DIR: config.DataDir, GG_WEB_DIST: join(config.Repo, 'apps/web/dist'), ...extra };
    },
    async launch(label, exe, args, { expect, cwd = binding.checkout, timeout = 90_000 } = {}) {
      const call = await native.run(label, exe, args, cwd, { childEnv: env, timeout });
      ctx.launcherPids.push(call.pid);
      assert.equal(call.stdoutEnd?.bytes, call.stdoutBytes, label + ' stdout EOF missing');
      assert.equal(call.stderrEnd?.bytes, call.stderrBytes, label + ' stderr EOF missing');
      if (expect !== undefined) assert.equal(call.exit.code, expect, label + ': ' + call.stderr);
      if (expect === 0) assert.deepEqual([call.stdoutBytes, call.stderrBytes], [0, 0]);
      return call;
    },
    /** A direct child that is expected to exit by itself (refusal or startup failure). */
    async direct(label, entry, args, childEnv, { expect, timeout = 60_000, cwd = binding.checkout } = {}) {
      const call = await native.run(label, projectNode, [entry, ...args], cwd, { childEnv, timeout });
      assert.equal(call.stdoutEnd?.bytes, call.stdoutBytes);
      assert.equal(call.stderrEnd?.bytes, call.stderrBytes);
      if (expect !== undefined) assert.equal(call.exit.code, expect, label + ': ' + call.stderr);
      return call;
    },
    /** A direct long-lived gateway. It is drained by API during the case or in cleanup. */
    serveDirect(label, argv, childEnv, current, { timeout = 150_000, cwd = binding.checkout } = {}) {
      assert(Array.isArray(argv) && argv.length > 0);
      current.direct = true;
      current.nativeLabel = label;
      current.closed = native.run(label, projectNode, argv, cwd, { childEnv, timeout })
        .then((call) => ({ call }), (error) => ({ error }));
      ctx.gateways.push(current);
      return current;
    },
    async fingerprint(repo, childEnv, label) {
      const output = await native.run('identity ' + label, projectNode,
        [join(repo, 'apps/api/dist/instance-identity.js')], repo, { childEnv, timeout: 18_000, reapReadOnly: true });
      assert.equal(output.exit.code, 0, output.stderr);
      assert.match(output.stdout.trim(), /^[a-f0-9]{64}$/u);
      return output.stdout.trim();
    },
    /** Exact identity of an owned gateway: health, Win32 birth, argv, leases and SQLite header. */
    async proof(current) {
      const health = await lib.workload.healthy(current.port);
      assert.equal(health.identity, current.expected);
      assert.equal(health.phase, 'running');
      const proc = await native.cim(health.pid);
      const owner = records.find(({ label }) => label === current.nativeLabel);
      assert(owner?.pid);
      assert.equal(proc.parentPid, current.direct ? process.pid : owner.pid);
      if (current.direct) assert.equal(proc.pid, owner.pid);
      assert.equal(await realpath(proc.executable), projectNode);
      const argv = [...proc.commandLine.matchAll(/"([^"]*)"|([^"\s]+)/gu)].map((m) => m[1] ?? m[2]);
      assert.equal(await realpath(argv[0]), projectNode);
      assert.equal(await realpath(argv[1]), current.entry);
      assert.deepEqual(argv.slice(2), current.extraArgv ?? []);
      const leases = [];
      for (const name of lockNames) {
        const file = join(current.store, name);
        const raw = await readFile(file);
        const lease = JSON.parse(raw);
        assert.equal(lease.pid, health.pid);
        assert.equal(lease.windowsCreationTime, proc.creationFileTime);
        leases.push({ path: file, sha256: sha(raw) });
      }
      return { health, proc, leases };
    },
    /** Launch through a launcher and bind the exact serving gateway. */
    async boot(label, exe, configPath, config, { expected, entry, cwd } = {}) {
      const current = { label, port: config.Port, store: config.DataDir, nativeLabel: label,
        expected: expected ?? await ctx.fingerprint(config.Repo, ctx.gatewayEnv(config), label),
        entry: entry ?? await realpath(join(config.Repo, 'apps/api/dist/main.js')) };
      ctx.gateways.push(current);
      await ctx.launch(label, exe, ['--config', configPath, '--ensure-gateway'], { expect: 0, cwd: cwd ?? config.Repo });
      current.proof = await ctx.proof(current);
      await ctx.put(label + '-gateway.json', current.proof);
      return current;
    },
    /** Drain an exact owned gateway by its own API; never signal it. */
    async drain(current) {
      if (current.stopped) return current.stopped;
      if (!current.proof && await refused(current.port)) {
        // Nothing listens on the owned port, so there is no API to drain. A direct child is awaited
        // only through its own bounded receipt; it is never signalled.
        const ended = current.closed ? await current.closed : undefined;
        current.stopped = { label: current.label, notListening: true, exit: ended?.call?.exit ?? null,
          error: ended?.error ? describe(ended.error) : undefined };
        await ctx.put(current.label + '-not-listening.json', current.stopped);
        return current.stopped;
      }
      const proof = current.proof ?? await ctx.proof(current);
      const { request } = lib.workload;
      assert.deepEqual(await ctx.proof(current), proof);
      const response = await request(current.port, '/system/shutdown');
      assert.equal(response.status, 200);
      const { controlToken } = await response.json();
      assert(typeof controlToken === 'string' && controlToken.length > 0);
      assert.deepEqual(await ctx.proof(current), proof);
      const drain = await request(current.port, '/system/shutdown', {
        method: 'POST', headers: { 'content-type': 'application/json', 'x-graphgoblin-shutdown-token': controlToken },
        body: '{"action":"drain"}',
      });
      assert.equal(drain.status, 202);
      await drain.arrayBuffer();
      await observe('gateway listener closed', () => refused(current.port), 25_000);
      const after = await observe('exact gateway birth absent', async () => {
        const row = await native.cim(proof.health.pid);
        return row.creationFileTime !== proof.proc.creationFileTime ? row : false;
      }, 12_000);
      for (const name of lockNames) {
        await assert.rejects(lstat(join(current.store, name)), { code: 'ENOENT' });
        await assert.rejects(lstat(join(current.store, name + '.reclaim')), { code: 'ENOENT' });
      }
      if (current.closed) {
        const ended = await current.closed;
        if (ended.error) throw ended.error;
        current.exit = ended.call.exit;
        assert.equal(ended.call.exit.code, 0, ended.call.stderr);
      }
      current.stopped = { label: current.label, pid: proof.health.pid, birth: proof.proc.creationFileTime,
        after, exit: current.exit ?? null };
      await ctx.put(current.label + '-drained.json', current.stopped);
      return current.stopped;
    },
    hold: (spec, work) => hold(ctx, spec, work),
    async link(path, target, type) {
      await symlink(target, path, type);
      ctx.links.push({ path, target, type });
      return path;
    },
    windowsMeta: (paths) => windowsMeta(ctx, paths),
    async helper(label, args, { timeout = 30_000, expect = 0 } = {}) {
      const call = await native.run(label, job.helper.executable.path, args, evidence, { timeout, reapReadOnly: true });
      assert.equal(call.exit.code, expect, label + ': ' + call.stderr);
      return call;
    },
    cleanup: () => cleanupCase(ctx),
  };
  await ctx.put('privacy-fixture.json', await lib.controls.privateRootReadback(native, fixture));
  return ctx;
}

const holderScript = String.raw`
$ErrorActionPreference = 'Stop'
function ReadLine { $l = [Console]::In.ReadLine(); if ($null -eq $l) { throw 'missing holder input' }
  [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($l)) }
$ready = ReadLine; $release = ReadLine; $seconds = [int](ReadLine)
$access = [IO.FileAccess](ReadLine); $share = [IO.FileShare](ReadLine); $count = [int](ReadLine)
$handles = [Collections.Generic.List[IO.FileStream]]::new()
try {
  for ($i = 0; $i -lt $count; $i++) {
    $handles.Add([IO.File]::Open((ReadLine), [IO.FileMode]::Open, $access, $share))
  }
  [IO.File]::WriteAllText($ready, 'held ' + $handles.Count)
  $expiry = [DateTime]::UtcNow.AddSeconds($seconds)
  while (-not [IO.File]::Exists($release)) {
    if ([DateTime]::UtcNow -ge $expiry) { throw 'holder reached its natural expiry before release' }
    Start-Sleep -Milliseconds 50
  }
} finally { foreach ($h in $handles) { $h.Dispose() } }
[Console]::WriteLine('released ' + $handles.Count)
`;
const pipeHolder = [
  "const net = require('node:net'); const fs = require('node:fs');",
  'const [pipe, ready, release, seconds] = process.argv.slice(1);',
  'let poll; const server = net.createServer({ pauseOnConnect: true }, (socket) => socket.destroy());',
  "const expiry = setTimeout(() => { clearInterval(poll); server.close(); process.exitCode = 3; }, Number(seconds) * 1000);",
  "server.once('error', (error) => { clearTimeout(expiry); process.stderr.write(String(error.code)); process.exitCode = 4; });",
  "server.listen(pipe, () => { fs.writeFileSync(ready, 'listening', { flag: 'wx' });",
  '  poll = setInterval(() => { if (fs.existsSync(release)) { clearInterval(poll); clearTimeout(expiry);',
  "    server.close(() => process.stdout.write('released')); } }, 50); });",
].join('\n');

/**
 * Finite holder lifetime: spawn, then readiness, identity and the caller's work all happen inside
 * one try whose finally writes the release marker and awaits the exact holder's own close.
 */
async function hold(ctx, spec, work) {
  const { native, records, evidence } = ctx;
  const { observe } = ctx.job.lib.native;
  assert.match(spec.name, /^[a-z0-9-]+$/u);
  const label = 'holder ' + spec.name;
  assert(!records.some((row) => row.label === label));
  const ready = under(evidence, spec.name + '.ready');
  const release = under(evidence, spec.name + '.release');
  const seconds = spec.seconds ?? 90;
  assert(seconds > 0 && seconds <= 240);
  const timeout = (seconds + 15) * 1000;
  const encode = (value) => Buffer.from(String(value), 'utf8').toString('base64');
  let call;
  if (spec.kind === 'file') {
    assert(Array.isArray(spec.paths) && spec.paths.length > 0);
    call = native.run(label, join(native.env.SystemRoot, 'System32/WindowsPowerShell/v1.0/powershell.exe'),
      ['-NoLogo', '-NoProfile', '-NonInteractive', '-EncodedCommand',
        Buffer.from("$ProgressPreference = 'SilentlyContinue';\n" + holderScript, 'utf16le').toString('base64')],
      evidence, { timeout, reapReadOnly: true,
        input: [ready, release, seconds, spec.access, spec.share, spec.paths.length, ...spec.paths].map(encode).join('\n') + '\n' });
  } else if (spec.kind === 'pipe') {
    call = native.run(label, projectNode, ['-e', pipeHolder, spec.pipe, ready, release, String(seconds)], evidence,
      { timeout, reapReadOnly: true });
  } else if (spec.kind === 'mutex') {
    call = native.run(label, ctx.job.helper.executable.path, ['--hold-mutex', spec.root, ready, release, String(seconds)],
      evidence, { timeout, reapReadOnly: true });
  } else throw new Error('Unknown holder kind');
  const settled = call.then((value) => ({ value }), (error) => ({ error }));
  const row = { label, spec, ready, release };
  let failure;
  let result;
  try {
    await observe(label + ' ready', async () => {
      try { return (await lstat(ready)).isFile(); } catch (error) {
        if (error.code === 'ENOENT') return false;
        throw error;
      }
    }, spec.readyMs ?? 20_000);
    row.pid = records.find((item) => item.label === label)?.pid;
    assert(Number.isSafeInteger(row.pid));
    row.readyText = await readFile(ready, 'utf8');
    row.identity = await native.cim(row.pid);
    assert.equal(row.identity.pid, row.pid);
    row.readyAt = new Date().toISOString();
    result = await work(row);
  } catch (error) { failure = error; } finally {
    try { await writeFile(release, 'release\n', { flag: 'wx' }); } catch (error) { row.releaseError = describe(error); }
    const final = await settled;
    row.releasedAt = new Date().toISOString();
    if (final.error) row.error = describe(final.error);
    else row.exit = { code: final.value.exit.code, stdout: final.value.stdout.trim(), stderr: final.value.stderr };
    if (row.identity) {
      try {
        const after = await native.cim(row.pid);
        row.goneAfterRelease = after.creationFileTime !== row.identity.creationFileTime;
      } catch (error) { row.afterError = describe(error); }
    }
    ctx.holders.push(row);
    await ctx.put(spec.name + '-holder.json', row).catch(() => undefined);
    if (!failure) {
      if (final.error) failure = final.error;
      else if (final.value.exit.code !== 0) failure = new Error(label + ' exited ' + final.value.exit.code);
      else if (row.goneAfterRelease !== true) failure = new Error(label + ' birth still present after release');
    }
  }
  if (failure) throw failure;
  return result;
}

/** Node no-follow state of exact fixture names, with content digests for regular files. */
export async function fileState(path) {
  let stat;
  try { stat = await lstat(path, { bigint: true }); } catch (error) {
    if (error.code === 'ENOENT') return { path, exists: false };
    throw error;
  }
  const row = { path, exists: true, id: stat.dev + ':' + stat.ino, size: Number(stat.size), nlink: Number(stat.nlink),
    kind: stat.isSymbolicLink() ? 'link' : stat.isDirectory() ? 'directory' : stat.isFile() ? 'file' : 'other' };
  if (row.kind === 'file' && stat.size <= 16n * 1024n * 1024n) row.sha256 = sha(await readFile(path));
  return row;
}

async function windowsMeta(ctx, paths) {
  const encode = (value) => Buffer.from(value, 'utf8').toString('base64');
  const reply = await ctx.native.run('Windows no-follow metadata', join(ctx.native.env.SystemRoot,
    'System32/WindowsPowerShell/v1.0/powershell.exe'), ['-NoLogo', '-NoProfile', '-NonInteractive', '-EncodedCommand',
    Buffer.from(String.raw`
$ErrorActionPreference = 'Stop'
while ($null -ne ($line = [Console]::In.ReadLine())) {
  $path = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($line))
  $row = [ordered]@{ path = $path; exists = $false }
  try { $attributes = [IO.File]::GetAttributes($path) } catch [IO.FileNotFoundException] { $attributes = $null } catch [IO.DirectoryNotFoundException] { $attributes = $null }
  if ($null -ne $attributes) {
    $row.exists = $true; $row.attributes = [int]$attributes
    try { $item = Get-Item -LiteralPath $path -Force; $row.linkType = [string]$item.LinkType
      $row.target = @($item.Target | ForEach-Object { [string]$_ }) } catch { $row.itemError = $_.Exception.GetType().FullName }
    try { $acl = Get-Acl -LiteralPath $path; $row.owner = $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value
      $row.sddl = $acl.Sddl } catch { $row.aclError = $_.Exception.GetType().FullName }
  }
  [Console]::WriteLine([Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(($row | ConvertTo-Json -Compress))))
}
`, 'utf16le').toString('base64')], ctx.evidence,
  { timeout: 20_000, reapReadOnly: true, input: paths.map(encode).join('\n') + '\n' });
  assert.equal(reply.exit.code, 0, reply.stderr);
  return reply.stdout.trim().split(/\r?\n/u).filter(Boolean)
    .map((line) => JSON.parse(Buffer.from(line, 'base64').toString('utf8')));
}

/** Read, apply or remove one explicit Users read ACE on an exact owned fixture directory. */
export async function usersAce(ctx, path, action) {
  assert(within(ctx.fixture, path) && ['read', 'add', 'remove'].includes(action));
  assert.equal(await realpath(path), path);
  const stat = await lstat(path);
  assert(stat.isDirectory() && !stat.isSymbolicLink(), 'Users ACE scope must be a plain owned fixture directory');
  const reply = await ctx.native.runPowerShell('fixture-only Users ACE ' + action, String.raw`
$ErrorActionPreference = 'Stop'
$path = $env:QA438_ACL_PATH
if (([IO.File]::GetAttributes($path) -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'reparse point refused' }
$acl = [IO.Directory]::GetAccessControl($path)
$before = $acl.GetSecurityDescriptorSddlForm('All')
$rule = New-Object Security.AccessControl.FileSystemAccessRule((New-Object Security.Principal.SecurityIdentifier 'S-1-5-32-545'), 'Read', 'Allow')
if ($env:QA438_ACL_ACTION -eq 'add') { $acl.AddAccessRule($rule) } elseif ($env:QA438_ACL_ACTION -eq 'remove') { [void]$acl.RemoveAccessRule($rule) }
if ($env:QA438_ACL_ACTION -ne 'read') { [IO.Directory]::SetAccessControl($path, $acl) }
$after = [IO.Directory]::GetAccessControl($path).GetSecurityDescriptorSddlForm('All')
[Console]::WriteLine(([ordered]@{ before = $before; after = $after } | ConvertTo-Json -Compress))
`, { extraEnv: { QA438_ACL_PATH: path, QA438_ACL_ACTION: action } });
  return JSON.parse(reply.stdout);
}

async function scanFixture(ctx) {
  const call = await ctx.helper('read-only no-follow fixture inventory', ['--cleanup-scan', ctx.fixture], { timeout: 20_000 });
  assert.equal(call.stdoutEnd?.bytes, call.stdoutBytes, 'fixture inventory stdout EOF missing');
  assert.equal(call.stderrEnd?.bytes, 0, 'fixture inventory stderr missing clean EOF');
  const scan = JSON.parse(call.stdout);
  const exactLink = under(ctx.fixture, 'profile/AppData/Local/Microsoft/Windows/INetCache/Content.IE5');
  if (scan.profileJunction) {
    const retained = scan.profileJunction;
    assert.equal(retained.disposition, 'retained-known-windows-cache-junction');
    assert.equal(retained.link.path.toLowerCase(), exactLink.toLowerCase());
    assert.equal(retained.target.path.toLowerCase(), join(dirname(exactLink), 'IE').toLowerCase());
    assert(scan.reparse.includes(retained.link.path));
  }
  return scan;
}

async function cleanupCase(ctx) {
  const { lib } = ctx.job;
  const report = { gateways: [], work: [], ports: [], holders: ctx.holders.map((row) => ({ label: row.label,
    pid: row.pid, exit: row.exit, gone: row.goneAfterRelease })), links: ctx.links, errors: [] };
  // Held Script work registered on an owned gateway (startWork callback): release its exact fixture
  // marker before any verified drain, also after a body failure, which stays the first failure.
  for (const current of ctx.gateways) {
    if (!current.work) continue;
    try {
      assert(within(ctx.fixture, current.work.release), current.work.release);
      await lib.workload.releaseWork(current.work);
      report.work.push({ label: current.label, runId: current.work.runId, release: current.work.release });
    } catch (error) {
      report.errors.push({ step: 'work-release', label: current.label, runId: current.work?.runId, ...describe(error) });
    }
  }
  for (const current of ctx.gateways) {
    try { report.gateways.push(await ctx.drain(current)); } catch (error) {
      report.errors.push({ step: 'drain', label: current.label, pid: current.proof?.health.pid,
        birth: current.proof?.proc.creationFileTime, retained: true, ...describe(error) });
    }
  }
  for (const restore of ctx.aclRestores.splice(0)) {
    try { report.acl = await restore(); } catch (error) { report.errors.push({ step: 'acl-restore', ...describe(error) }); }
  }
  for (const port of ctx.ports) {
    try {
      const free = await lib.native.refused(port);
      report.ports.push({ port, free });
      if (!free) report.errors.push({ step: 'port', port, issue: 'Retained listener' });
    } catch (error) { report.errors.push({ step: 'port', port, ...describe(error) }); }
  }
  for (const record of ctx.records) {
    if (!record.exit || !record.close || record.exit.code !== record.close.code) {
      report.errors.push({ step: 'process', label: record.label, pid: record.pid, issue: 'Child exit or close ambiguous' });
    }
  }
  if (report.errors.length === 0) {
    try {
      report.childCensus = await lib.windows.confirmLauncherChildrenAbsent(ctx.native, ctx.evidence, ctx.launcherPids);
      if (report.childCensus.rows.length) report.errors.push({ step: 'children', rows: report.childCensus.rows });
      if (ctx.stores.length) {
        report.stores = await lib.windows.confirmOwnedCleanup(ctx.native, ctx.storesDir, ctx.stores, ctx.evidence);
      }
      if (report.errors.length) return report;
      const scan = await scanFixture(ctx);
      report.reparse = scan.reparse;
      const known = new Set(ctx.links.map((item) => item.path));
      if (scan.profileJunction) {
        report.profileJunction = scan.profileJunction;
        known.add(scan.profileJunction.link.path);
      }
      const unexpected = scan.reparse.filter((path) => !known.has(path));
      if (unexpected.length) report.errors.push({ step: 'reparse', unexpected });
      if (scan.tempHits.length) report.errors.push({ step: 'temp-witness', names: scan.tempHits });
      report.retained = ctx.fixture;
    } catch (error) { report.errors.push({ step: 'readback', ...describe(error) }); }
  }
  return report;
}

// ----- Production gateway writer seam (wraps the exported nodeLogFileSystem only) -----

/** A finite gate. Its ref'd timer keeps the loop alive exactly as an in-flight fs request would. */
export function gate(ms) {
  let open;
  const promise = new Promise((resolve) => { open = resolve; });
  const state = { promise, released: false, expired: false, reachedAt: undefined };
  const timer = setTimeout(() => { state.expired = true; state.released = true; open(); }, ms);
  state.open = () => {
    if (state.released) return;
    state.released = true;
    clearTimeout(timer);
    open();
  };
  return state;
}

/**
 * Wrap the production `nodeLogFileSystem`. Every reached operation is recorded with its path,
 * opened identity, offsets, lengths and timing; plan hooks may delay or fault one operation.
 * Ordinary opens, stats, writes, truncates, renames and closes stay real.
 */
export function createSeam(real, slotBytes, plan = {}) {
  const ops = [];
  const events = [];
  let inFlight = 0;
  let maxInFlight = 0;
  let writes = 0;
  const id = (stat) => stat.dev + ':' + stat.ino;
  const start = (op, path, extra = {}) => {
    const row = { seq: ops.length + 1, op, path, ...extra, startMs: performance.now() };
    ops.push(row);
    inFlight++;
    maxInFlight = Math.max(maxInFlight, inFlight);
    return row;
  };
  const step = async (row, work) => {
    try {
      const value = await work();
      row.ok = true;
      return value;
    } catch (error) {
      row.ok = false;
      row.code = error.code;
      throw error;
    } finally {
      inFlight--;
      row.endMs = performance.now();
    }
  };
  const wrap = (handle, path, openedId) => ({
    stat: () => { const row = start('handle.stat', path, { openedId });
      return step(row, async () => { const stat = await handle.stat(); row.size = Number(stat.size); return stat; }); },
    read: (buffer, offset, length, position) => { const row = start('handle.read', path, { openedId, length, position });
      return step(row, async () => { const r = await handle.read(buffer, offset, length, position); row.bytesRead = r.bytesRead; return r; }); },
    write: (buffer, offset, length, position) => {
      const n = ++writes;
      const row = start('handle.write', path, { openedId, n, length, position, preWriteFits: position + length <= slotBytes });
      return step(row, async () => {
        const r = plan.write ? await plan.write({ handle, buffer, offset, length, position, n, row })
          : await handle.write(buffer, offset, length, position);
        row.bytesWritten = r.bytesWritten;
        return r;
      });
    },
    truncate: (length) => { const row = start('handle.truncate', path, { openedId, length });
      return step(row, async () => { await plan.truncate?.({ length, row }); await handle.truncate(length); }); },
    close: () => { const row = start('handle.close', path, { openedId }); return step(row, () => handle.close()); },
  });
  const fs = {
    lstat: (path) => { const row = start('lstat', path);
      return step(row, async () => { await plan.lstat?.({ path, row }); const stat = await real.lstat(path);
        row.id = id(stat); row.size = Number(stat.size); row.nlink = Number(stat.nlink); return stat; }); },
    open: (path, mode) => { const row = start('open', path, { mode });
      return step(row, async () => { await plan.open?.({ path, mode, row }); const handle = await real.open(path, mode);
        const stat = await handle.stat(); row.id = id(stat); return wrap(handle, path, row.id); }); },
    rename: (from, to) => { const row = start('rename', from, { to });
      return step(row, async () => { await plan.rename?.({ from, to, row }); await real.rename(from, to); }); },
  };
  return {
    fs, ops, events,
    observe: (event) => { events.push({ ...event, atMs: performance.now() }); plan.event?.(event); },
    get inFlight() { return inFlight; },
    get maxInFlight() { return maxInFlight; },
    preWriteViolations: () => ops.filter((row) => row.op === 'handle.write' && !row.preWriteFits),
  };
}

export const injected = (code) => Object.assign(new Error('qa438 injected ' + code + ' at the production seam'), { code });

/** Complete JSON lines totalling exactly `total` bytes; each line at most `width` bytes. */
export function seedBytes(total, tag, width = 1024) {
  const fill = (length, index) => {
    const head = '{"msg":"' + tag + '","i":' + index + ',"p":"';
    const tail = '"}\n';
    const count = length - head.length - tail.length;
    assert(count >= 0, 'seed line too short');
    return head + 's'.repeat(count) + tail;
  };
  const parts = [];
  let size = 0;
  let index = 0;
  while (total - size > 2 * width) { parts.push(fill(width, index++)); size += width; }
  const rest = total - size;
  if (rest > width) {
    const half = Math.floor(rest / 2);
    parts.push(fill(half, index++), fill(rest - half, index++));
  } else if (rest > 0) parts.push(fill(rest, index++));
  const bytes = Buffer.from(parts.join(''), 'utf8');
  assert.equal(bytes.length, total);
  return bytes;
}

/** One JSON record whose UTF-8 encoding is exactly `total` bytes including LF. */
export function exactRecord(total, tag, tail = '') {
  const prefix = '{"level":30,"msg":"' + tag + '","pad":"';
  const suffix = '"}\n';
  const count = total - Buffer.byteLength(prefix + tail + suffix);
  assert(count >= 0, 'record too short for ' + tag);
  const text = prefix + 'a'.repeat(count) + tail + suffix;
  assert.equal(Buffer.byteLength(text), total);
  return text;
}

/** Complete lines of `bytes`; fatal UTF-8 and JSON for every line; record-size ceiling checked. */
export function completeRecords(bytes, cap) {
  assert(bytes.length === 0 || bytes.at(-1) === 10, 'incomplete trailing record');
  const rows = [];
  let offset = 0;
  while (offset < bytes.length) {
    const end = bytes.indexOf(10, offset);
    const line = bytes.subarray(offset, end + 1);
    assert(line.length <= cap, 'record exceeds ' + cap);
    const text = new TextDecoder('utf-8', { fatal: true }).decode(line);
    rows.push({ offset, length: line.length, bytes: line, value: JSON.parse(text) });
    offset = end + 1;
  }
  return rows;
}

/** Git-free check that `checkout` still has the bound head/tree/index (read-only, no locks). */
export function gitReadback(binding, checkout = binding.checkout) {
  const git = (...args) => execFileSync(binding.git.path,
    ['--no-optional-locks', '-c', 'core.fsmonitor=false', '-c', 'core.untrackedCache=false', ...args], {
      encoding: 'utf8', cwd: checkout, windowsHide: true, shell: false, timeout: 30_000, maxBuffer: 32 * 1024 * 1024,
      env: { SystemRoot: process.env.SystemRoot, WINDIR: process.env.WINDIR } });
  return { git, status: git('status', '--porcelain=v1', '--untracked-files=all').trim(),
    head: git('rev-parse', 'HEAD').trim(), tree: git('rev-parse', 'HEAD^{tree}').trim(),
    index: git('rev-parse', '--path-format=absolute', '--git-path', 'index').trim() };
}

/** Complete records of a managed log (a concurrent read may end inside a batch being written). */
export async function logRecords(path) {
  let bytes;
  try { bytes = await readFile(path); } catch (error) {
    if (error.code === 'ENOENT') return [];
    throw error;
  }
  return completeRecords(bytes.subarray(0, bytes.lastIndexOf(10) + 1), Number.MAX_SAFE_INTEGER).map((row) => row.value);
}

/** Every listed fixture file opens with no sharing at all: no live handle remains. */
export async function exclusiveOpen(ctx, paths) {
  const encode = (value) => Buffer.from(value, 'utf8').toString('base64');
  const reply = await ctx.native.run('exclusive open of fixture files', join(ctx.native.env.SystemRoot,
    'System32/WindowsPowerShell/v1.0/powershell.exe'), ['-NoLogo', '-NoProfile', '-NonInteractive', '-EncodedCommand',
    Buffer.from(String.raw`
$ErrorActionPreference = 'Stop'
$handles = [Collections.Generic.List[IO.FileStream]]::new()
try {
  while ($null -ne ($line = [Console]::In.ReadLine())) {
    $path = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($line))
    $handles.Add([IO.File]::Open($path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::None))
  }
} finally { foreach ($h in $handles) { $h.Dispose() } }
[Console]::WriteLine('qa438-exclusive ' + $handles.Count)
`, 'utf16le').toString('base64')], ctx.evidence,
  { timeout: 15_000, reapReadOnly: true, input: paths.map(encode).join('\n') + '\n' });
  assert.equal(reply.exit.code, 0, reply.stderr);
  assert.equal(reply.stdout.trim(), 'qa438-exclusive ' + paths.length);
  return { paths, probePid: reply.pid };
}
