// #438 independent QA control. Compiled only after root freezes the candidate, together with the
// exact frozen apps/windows-launcher/Launcher.cs (see compile-helper.mjs); never installed.
//   --keys <dir>                                  production LogRoot.Admit keys for one root
//   --hold-mutex <dir> <ready> <release> <secs>  hold the root's launcher-log mutex on one thread
//   --record-edges                                C-1 native: LauncherLog.Build 4 KiB edges, RenderPath
//   --slot-edges <dir>                            C-2 native: LauncherLog.Append slot edges -1/0/+1
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using GraphGoblin.Desktop;
using Microsoft.Win32.SafeHandles;

public static class LauncherLogControl
{
    static readonly JavaScriptSerializer Json = new JavaScriptSerializer();
    static readonly DateTime Time = new DateTime(2026, 11, 16, 12, 0, 0, DateTimeKind.Utc).AddTicks(1234567);
    const int Pid = 4380;
    const string Config = @"C:\qa438\config\GraphGoblin.exe.json";
    const string Folder = @"C:\qa438\logs";
    const string LockPath = @"C:\qa438\store\graphgoblin.lock";

    static void Check(bool valid, string what) { if (!valid) throw new InvalidOperationException("check failed: " + what); }

    public static int Main(string[] args)
    {
        Console.SetOut(new StreamWriter(Console.OpenStandardOutput(), new UTF8Encoding(false)) { AutoFlush = true });
        Console.SetError(new StreamWriter(Console.OpenStandardError(), new UTF8Encoding(false)) { AutoFlush = true });
        try
        {
            if (args.Length == 2 && args[0] == "--cleanup-scan") return ScanCleanup(args[1]);
            if (args.Length == 2 && args[0] == "--keys") return Keys(args[1]);
            if (args.Length == 5 && args[0] == "--hold-mutex") return HoldMutex(args[1], args[2], args[3], int.Parse(args[4]));
            if (args.Length == 1 && args[0] == "--record-edges") return RecordEdges();
            if (args.Length == 2 && args[0] == "--slot-edges") return SlotEdges(args[1]);
            Console.Error.WriteLine("usage: --cleanup-scan <fixture> | --keys <dir> | --hold-mutex <dir> <ready> <release> <seconds> | --record-edges | --slot-edges <dir>");
            return 2;
        }
        catch (Exception error)
        {
            Console.Error.WriteLine(error.GetType().FullName + ": " + error.Message);
            return 1;
        }
    }

    // The cleanup scan opens directories before descending and reads this junction's link data
    // directly from the no-follow handle. Every other reparse name stays an inventory leaf.
    const uint DirectoryBit = 0x10, DeviceBit = 0x40, ReparseBit = 0x400;
    const uint MountPointTag = 0xA0000003, GetReparsePoint = 0x000900A8;

    [DllImport("kernel32.dll", SetLastError = true)]
    static extern bool DeviceIoControl(SafeFileHandle file, uint code, IntPtr input, uint inputBytes,
        [Out] byte[] output, uint outputBytes, out uint returnedBytes, IntPtr overlapped);

    static bool SamePath(string left, string right)
    {
        return string.Equals(left, right, StringComparison.OrdinalIgnoreCase);
    }

    static SafeFileHandle OpenCleanupName(string path, bool hold = true)
    {
        uint share = NativeFiles.ShareRead | NativeFiles.ShareWrite | (hold ? 0u : NativeFiles.ShareDelete);
        var handle = NativeFiles.Open(@"\\?\" + path, NativeFiles.ReadAttributes, share,
            NativeFiles.OpenExisting, NativeFiles.BackupSemantics | NativeFiles.OpenReparsePoint);
        if (!handle.IsInvalid) return handle;
        int error = Marshal.GetLastWin32Error();
        handle.Dispose();
        throw new Win32Exception(error, "no-follow inventory open: " + path);
    }

    static object CleanupIdentity(string path, NativeFiles.Identity id)
    {
        Check(id.Index != 0, "missing identity for " + path);
        return new { path = path, volume = id.Volume.ToString("x8"), fileIndex = id.Index.ToString("x16"),
            attributes = id.Attributes };
    }

    static object PhysicalDirectory(string path, SafeFileHandle handle)
    {
        var id = NativeFiles.Describe(handle);
        Check((id.Attributes & (DirectoryBit | DeviceBit | ReparseBit)) == DirectoryBit &&
            SamePath(NativeFiles.FinalPath(handle), path), "nonphysical directory " + path);
        return CleanupIdentity(path, id);
    }

    static string MountPointName(byte[] data, int total, int offsetField)
    {
        int offset = BitConverter.ToUInt16(data, offsetField);
        int length = BitConverter.ToUInt16(data, offsetField + 2);
        Check((offset % 2 == 0) && (length % 2 == 0) && (16 + offset + length <= total), "malformed mount-point name");
        return new UnicodeEncoding(false, false, true).GetString(data, 16 + offset, length);
    }

    static object ProfileJunction(string link, string target, List<object> ancestry)
    {
        using (var linkHandle = OpenCleanupName(link))
        using (var targetHandle = OpenCleanupName(target))
        {
            var linkId = NativeFiles.Describe(linkHandle);
            Check((linkId.Attributes & (DirectoryBit | DeviceBit | ReparseBit)) == (DirectoryBit | ReparseBit),
                "expected exact profile directory junction");
            object targetId = PhysicalDirectory(target, targetHandle);
            Check(!linkId.Same(NativeFiles.Describe(targetHandle)), "link and physical target share an ID");
            byte[] data = new byte[16384];
            uint bytes;
            if (!DeviceIoControl(linkHandle, GetReparsePoint, IntPtr.Zero, 0, data, (uint)data.Length, out bytes, IntPtr.Zero))
                throw new Win32Exception(Marshal.GetLastWin32Error(), "read exact profile junction tag and target");
            Check(bytes >= 16 && bytes <= data.Length && BitConverter.ToUInt32(data, 0) == MountPointTag &&
                BitConverter.ToUInt16(data, 4) + 8 == bytes, "invalid or unexpected mount-point payload");
            string substitute = MountPointName(data, (int)bytes, 8);
            string print = MountPointName(data, (int)bytes, 12);
            Check(SamePath(substitute, @"\??\" + target) && (print.Length == 0 || SamePath(print, target)),
                "profile junction target differs from exact physical IE sibling");
            return new { disposition = "retained-known-windows-cache-junction", tag = "0xa0000003",
                link = CleanupIdentity(link, linkId), target = targetId, substituteName = substitute,
                printName = print, physicalAncestry = ancestry.ToArray() };
        }
    }

    static int ScanCleanup(string fixture)
    {
        string drive = Path.GetPathRoot(fixture);
        Check(drive != null && drive.Length == 3 && drive[1] == ':' && drive[2] == '\\' &&
            fixture.Length > drive.Length && SamePath(Path.GetFullPath(fixture), fixture), "nonlocal or ambiguous fixture path");
        string link = Path.Combine(fixture, @"profile\AppData\Local\Microsoft\Windows\INetCache\Content.IE5");
        string target = Path.Combine(Path.GetDirectoryName(link), "IE");
        string tempPrefix = Path.Combine(fixture, "temp") + "\\";
        var reparse = new List<string>();
        var tempHits = new List<string>();
        var ancestry = new List<object>();
        var handles = new List<SafeFileHandle>();
        object profileJunction = null;
        try
        {
            // Above the fixture inspect only exact ancestor metadata with all sharing allowed.
            // Hold the validated chain during the scan and prevent replacement inside the fixture.
            string path = drive;
            foreach (string part in fixture.Substring(drive.Length).Split('\\'))
            {
                var handle = OpenCleanupName(path, false);
                handles.Add(handle);
                ancestry.Add(PhysicalDirectory(path, handle));
                path = Path.Combine(path, part);
            }
            WalkCleanup(path, link, target, tempPrefix, ancestry, reparse, tempHits, ref profileJunction);
        }
        finally
        {
            for (int i = handles.Count - 1; i >= 0; i--) handles[i].Dispose();
        }
        Console.WriteLine(Json.Serialize(new { reparse = reparse, tempHits = tempHits, profileJunction = profileJunction }));
        return 0;
    }

    static void WalkCleanup(string dir, string link, string target, string tempPrefix, List<object> ancestry,
        List<string> reparse, List<string> tempHits, ref object profileJunction)
    {
        using (var handle = OpenCleanupName(dir))
        {
            ancestry.Add(PhysicalDirectory(dir, handle));
            try
            {
                foreach (string path in Directory.GetFileSystemEntries(dir))
                {
                    if (SamePath(path, link))
                    {
                        Check(profileJunction == null, "ambiguous profile junction name");
                        profileJunction = ProfileJunction(path, target, ancestry);
                        reparse.Add(path);
                        continue;
                    }
                    uint? attributes = NativeFiles.NameAttributes(@"\\?\" + path);
                    Check(attributes.HasValue, "inventory name disappeared: " + path);
                    if ((attributes.Value & ReparseBit) != 0)
                    {
                        reparse.Add(path);
                        continue;
                    }
                    string name = Path.GetFileName(path);
                    if (path.StartsWith(tempPrefix, StringComparison.OrdinalIgnoreCase) &&
                        (name.IndexOf("gateway.log", StringComparison.OrdinalIgnoreCase) >= 0 ||
                         name.IndexOf("launcher.log", StringComparison.OrdinalIgnoreCase) >= 0))
                        tempHits.Add(path);
                    if ((attributes.Value & DirectoryBit) != 0)
                        WalkCleanup(path, link, target, tempPrefix, ancestry, reparse, tempHits, ref profileJunction);
                }
            }
            finally { ancestry.RemoveAt(ancestry.Count - 1); }
        }
    }

    static int Keys(string directory)
    {
        LogRoot root;
        try { root = LogRoot.Admit(directory); }
        catch (IOException error)
        {
            Console.WriteLine(Json.Serialize(new Dictionary<string, object> { { "admitted", false }, { "refusal", error.Message } }));
            return 3;
        }
        Console.WriteLine(Json.Serialize(new Dictionary<string, object> {
            { "admitted", true }, { "path", root.Path }, { "volume", root.Volume.ToString() }, { "index", root.Index.ToString() },
            { "gatewayPipe", root.GatewayPipe }, { "launcherMutex", root.LauncherMutex } }));
        return 0;
    }

    static int HoldMutex(string directory, string ready, string release, int seconds)
    {
        Check(seconds > 0 && seconds <= 240, "finite holder lifetime");
        var root = LogRoot.Admit(directory);
        using (var mutex = new Mutex(false, root.LauncherMutex))
        {
            bool owned = false;
            try
            {
                try { owned = mutex.WaitOne(TimeSpan.FromSeconds(5)); } catch (AbandonedMutexException) { owned = true; }
                Check(owned, "launcher-log mutex acquired by the holder");
                File.WriteAllText(ready, root.LauncherMutex);
                var expiry = DateTime.UtcNow.AddSeconds(seconds);
                while (!File.Exists(release))
                {
                    if (DateTime.UtcNow >= expiry) throw new TimeoutException("mutex holder reached its natural expiry before release");
                    Thread.Sleep(50);
                }
            }
            finally { if (owned) mutex.ReleaseMutex(); }
        }
        Console.WriteLine("released");
        return 0;
    }

    static bool Has(byte[] bytes, string text) { return Encoding.UTF8.GetString(bytes).Contains(text); }

    static Dictionary<string, object> Verify(byte[] bytes, string message)
    {
        Check(bytes[bytes.Length - 1] == (byte)'\n', "record ends with LF");
        string text = new UTF8Encoding(false, true).GetString(bytes);
        var parsed = (Dictionary<string, object>)Json.DeserializeObject(text);
        Check((string)parsed["message"] == message, "message survived intact");
        return parsed;
    }

    static byte[] Synthetic(string message, string folder = Folder, string lockPath = LockPath, string config = Config)
    {
        // Synthetic closed failure: not reachable product text; it only sizes the record exactly.
        return LauncherLog.Build(Time, Pid, new LauncherFailure("qa438-synthetic", message, folder, lockPath, 74), "gateway", config);
    }

    static int RecordEdges()
    {
        var rows = new List<Dictionary<string, object>>();
        foreach (string ch in new[] { "\u00e9", "\u20ac", "\uD83D\uDE00" })
        {
            byte[] baseline = Synthetic(ch);
            Check(baseline != null && Has(baseline, "\"config\":"), "short record keeps locations");
            int a = baseline.Length;
            int charBytes = a - Synthetic("").Length;
            foreach (int target in new[] { 4095, 4096 })
            {
                string message = new string('m', target - a) + ch;
                byte[] bytes = Synthetic(message);
                Check(bytes != null && bytes.Length == target && Has(bytes, "\"config\":") && Has(bytes, "\"logFolder\":") && Has(bytes, "\"lock\":"), "detail record of " + target);
                Verify(bytes, message);
                rows.Add(new Dictionary<string, object> { { "char", ch }, { "case", "with-locations-" + target }, { "bytes", bytes.Length } });
            }
            string over = new string('m', 4097 - a) + ch;
            byte[] dropped = Synthetic(over);
            Check(dropped != null && !Has(dropped, "\"config\":") && !Has(dropped, "\"logFolder\":") && !Has(dropped, "\"lock\":") && dropped.Length < 4097, "locations dropped at 4097");
            Verify(dropped, over);
            int locations = 4097 - dropped.Length;
            string exact = new string('m', 4096 + locations - a) + ch;
            byte[] full = Synthetic(exact);
            Check(full != null && full.Length == 4096 && !Has(full, "\"config\":"), "location-free record of exactly 4096");
            Verify(full, exact);
            Check(Synthetic(new string('m', 4097 + locations - a) + ch) == null, "4097-byte location-free record omitted whole");
            // The character's encoded bytes would cross byte 4096: the whole record is omitted, never sliced.
            int k = 4100 + charBytes - (a - locations) - 2;
            string straddle = new string('m', k) + ch + "zz";
            Check(Synthetic(straddle) == null, "straddling record omitted whole");
            rows.Add(new Dictionary<string, object> { { "char", ch }, { "charSerializedBytes", charBytes }, { "locationBytes", locations },
                { "droppedLocationsBytes", dropped.Length }, { "exactWithoutLocations", full.Length }, { "rawCharacterSerialized", Has(baseline, ch) } });
        }
        // Reachable product text with long and unsafe locations stays bounded and closed.
        byte[] product = LauncherLog.Build(Time, Pid, StartupOutcome.ForChildExit(75, @"C:\" + new string('l', 5000)), "gateway", @"C:\" + new string('c', 5000));
        Check(product != null && product.Length <= LauncherLog.RecordBytes, "product record bounded");
        var productRecord = Verify(product, StartupOutcome.ForChildExit(75, null).Message);
        Check((string)productRecord["code"] == "startup-failed-unlogged" && (int)productRecord["childExit"] == 75, "product closed outcome kept");
        Check(((string)productRecord["config"]).Length <= Program.MaxRenderedPath && ((string)productRecord["logFolder"]).Length <= Program.MaxRenderedPath, "rendered fields capped");
        byte[] unsafeRecord = Synthetic("unsafe", "C:\\logs\u202Etxt", "C:\\lock\r\nx", "C:\\cfg\u2028.json");
        var unsafeParsed = Verify(unsafeRecord, "unsafe");
        foreach (string field in new[] { "config", "logFolder", "lock" })
            Check((string)unsafeParsed[field] == "[location not shown]", "unsafe " + field + " suppressed");
        // RenderPath: at most 260 UTF-16 code units, keeps the end, never splits a surrogate pair.
        string longPath = @"C:\" + new string('p', 300) + @"\end.json";
        string rendered = Program.RenderPath(longPath);
        Check(rendered.Length == Program.MaxRenderedPath && rendered[0] == '\u2026' && longPath.EndsWith(rendered.Substring(1), StringComparison.Ordinal), "long path capped");
        string pair = @"C:\" + new string('q', 300) + "\uD83D\uDE00" + new string('r', 258);
        string pairRendered = Program.RenderPath(pair);
        Check(pairRendered.Length <= Program.MaxRenderedPath && !char.IsLowSurrogate(pairRendered[1]), "surrogate pair not split");
        foreach (string bad in new[] { "C:\\a\u0085b", "C:\\a\u202Eb", "C:\\a\u2028b", "C:\\a\u2029b", "C:\\a\tb", "C:\\a\u200Bb", "C:\\a\u001Fb", "relative\\path", "" })
            Check(Program.RenderPath(bad) == "[location not shown]", "unsafe location rendered: " + Escape(bad));
        Console.WriteLine(Json.Serialize(new Dictionary<string, object> { { "schema", "gg438-launcher-record-edges/v1" }, { "rows", rows },
            { "productBytes", product.Length }, { "longRenderedLength", rendered.Length }, { "pairRenderedLength", pairRendered.Length } }));
        return 0;
    }

    static string Escape(string value)
    {
        var result = new StringBuilder();
        foreach (char ch in value) result.Append(ch < 0x20 || ch > 0x7e ? "\\u" + ((int)ch).ToString("x4") : ch.ToString());
        return result.ToString();
    }

    static byte[] JsonLines(int total)
    {
        Check(total >= 9, "seed size");
        var text = new StringBuilder();
        int left = total;
        while (left > 0)
        {
            int width = left >= 200 ? 100 : left > 100 ? left / 2 : left;
            text.Append("{\"s\":\"").Append('s', width - 9).Append("\"}\n");
            left -= width;
        }
        byte[] bytes = Encoding.ASCII.GetBytes(text.ToString());
        Check(bytes.Length == total, "seed length");
        return bytes;
    }

    static NativeFiles.Identity Id(string path)
    {
        using (var handle = NativeFiles.Open(path, NativeFiles.ReadAttributes, 7, NativeFiles.OpenExisting, NativeFiles.OpenReparsePoint))
        {
            Check(!handle.IsInvalid, "identity of " + path);
            return NativeFiles.Describe(handle);
        }
    }

    static string Sha(byte[] bytes) { using (var sha = SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant(); }

    static Dictionary<string, object> Row(NativeFiles.Identity id, string path)
    {
        return new Dictionary<string, object> { { "volume", id.Volume.ToString() }, { "index", id.Index.ToString() }, { "size", id.Size },
            { "links", (long)id.Links }, { "sha256", Sha(File.ReadAllBytes(path)) } };
    }

    static int SlotEdges(string directory)
    {
        var rows = new List<Dictionary<string, object>>();
        foreach (int d in new[] { -1, 0, 1 })
        {
            string sub = Path.Combine(directory, "slot-" + (d < 0 ? "m1" : d == 0 ? "0" : "p1"));
            Check(!Directory.Exists(sub), "fresh slot root");
            Directory.CreateDirectory(sub);
            var root = LogRoot.Admit(sub);
            // A fixed reachable closed issue with bounded locations; its measured length sets the edge.
            byte[] record = LauncherLog.Build(Time, Pid, StartupOutcome.ForChildExit(74, root.Path), "gateway", Path.Combine(root.Path, "qa438.json"));
            int length = record.Length;
            string active = Path.Combine(root.Path, LauncherLog.Active), previous = Path.Combine(root.Path, LauncherLog.Previous);
            byte[] seed = JsonLines(LauncherLog.SlotBytes - length + d);
            byte[] prior = Encoding.ASCII.GetBytes("{\"s\":\"qa438 previous sentinel\"}\n");
            File.WriteAllBytes(active, seed);
            File.WriteAllBytes(previous, prior);
            var a0 = Id(active); var p0 = Id(previous);
            var before = new Dictionary<string, object> { { "active", Row(a0, active) }, { "previous", Row(p0, previous) } };
            bool appended = LauncherLog.Append(root, record);
            var a1 = Id(active); var p1 = Id(previous);
            var after = new Dictionary<string, object> { { "active", Row(a1, active) }, { "previous", Row(p1, previous) } };
            string[] names = Directory.GetFileSystemEntries(root.Path).Select(Path.GetFileName).OrderBy(n => n, StringComparer.Ordinal).ToArray();
            Check(appended, "append at offset " + d);
            Check(names.SequenceEqual(new[] { "launcher.log", "launcher.log.1" }), "no other managed names");
            byte[] activeBytes = File.ReadAllBytes(active);
            if (d <= 0)
            {
                Check(a1.Index == a0.Index && a1.Size == seed.Length + length && activeBytes.Skip(seed.Length).SequenceEqual(record), "fit appended in place");
                Check(p1.Index == p0.Index && File.ReadAllBytes(previous).SequenceEqual(prior), "previous untouched");
            }
            else
            {
                Check(p1.Index == a0.Index && p1.Size == seed.Length && Sha(File.ReadAllBytes(previous)) == Sha(seed), "active identity moved to previous");
                Check(a1.Index != a0.Index && activeBytes.SequenceEqual(record), "active recreated with the record");
            }
            foreach (string slot in new[] { active, previous })
                foreach (string line in Encoding.UTF8.GetString(File.ReadAllBytes(slot)).Split(new[] { '\n' }, StringSplitOptions.RemoveEmptyEntries))
                    Check(Encoding.UTF8.GetByteCount(line) + 1 <= LauncherLog.RecordBytes, "bounded record");
            rows.Add(new Dictionary<string, object> { { "offset", d }, { "recordBytes", length }, { "before", before }, { "after", after }, { "names", names } });
        }
        Console.WriteLine(Json.Serialize(new Dictionary<string, object> { { "schema", "gg438-launcher-slot-edges/v1" }, { "rows", rows } }));
        return 0;
    }
}
