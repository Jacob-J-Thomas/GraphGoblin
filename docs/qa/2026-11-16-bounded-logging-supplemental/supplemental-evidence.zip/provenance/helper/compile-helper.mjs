// Compile LauncherLogControl.cs together with an exact apps/windows-launcher/Launcher.cs and write a
// receipt. Only a `--frozen` receipt is admissible; a `--compile-check` receipt records a syntax and
// type check against unfrozen source and can never satisfy the admission.
//   node compile-helper.mjs --frozen <absolute candidate binding> <sha256> <output-name>
//   node compile-helper.mjs --compile-check <absolute checkout> <output-name>
import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { lstat, mkdir, readFile, realpath } from 'node:fs/promises';
import { join } from 'node:path';
import { batch, gitReadback, readBound, save, sha, suite, under } from './common.mjs';

const [mode, ...rest] = process.argv.slice(2);
let checkout;
let outName;
let binding;
if (mode === '--frozen') {
  assert.equal(rest.length, 3);
  binding = JSON.parse((await readBound({ path: rest[0], sha256: rest[1] }, batch)).toString('utf8'));
  assert.equal(binding.mode, 'candidate');
  checkout = binding.checkout;
  outName = rest[2];
  const git = gitReadback(binding);
  assert.deepEqual([git.status, git.head, git.tree], ['', binding.head, binding.tree], 'candidate is not the clean frozen head');
} else if (mode === '--compile-check') {
  assert.equal(rest.length, 2);
  checkout = await realpath(rest[0]);
  outName = rest[1];
} else throw new Error('usage: --frozen <binding> <sha256> <name> | --compile-check <checkout> <name>');
assert.match(outName, /^[a-z0-9-]+$/u);
const outDir = under(suite, outName);
await mkdir(outDir); // Never reuses an earlier output.
const launcherCs = join(checkout, 'apps', 'windows-launcher', 'Launcher.cs');
const controlCs = under(suite, 'LauncherLogControl.cs');
const digests = async () => ({ launcher: sha(await readFile(launcherCs)), control: sha(await readFile(controlCs)) });
const before = await digests();
if (binding) assert.equal(before.launcher, binding.sourceFiles['apps/windows-launcher/Launcher.cs']);
const systemRoot = process.env.SystemRoot ?? 'C:\\Windows';
const compiler = join(systemRoot, 'Microsoft.NET', 'Framework64', 'v4.0.30319', 'csc.exe');
const exe = join(outDir, 'LauncherLogControl.exe');
const args = ['/nologo', '/target:exe', '/platform:x64', '/main:LauncherLogControl',
  '/reference:System.Windows.Forms.dll', '/reference:System.Web.Extensions.dll', '/out:' + exe, launcherCs, controlCs];
const startedAt = new Date().toISOString();
const result = await new Promise((resolve) => execFile(compiler, args, {
  cwd: outDir, windowsHide: true, timeout: 120_000, maxBuffer: 4 * 1024 * 1024,
  env: { SystemRoot: systemRoot, WINDIR: systemRoot, PATH: join(systemRoot, 'System32') },
}, (error, stdout, stderr) => resolve({ code: error ? (typeof error.code === 'number' ? error.code : String(error.code)) : 0, stdout, stderr })));
assert.deepEqual(await digests(), before, 'compile inputs changed during compilation');
let output = null;
try {
  if ((await lstat(exe)).isFile()) output = { path: exe, sha256: sha(await readFile(exe)) };
} catch (error) { if (error.code !== 'ENOENT') throw error; }
const receipt = {
  schema: 'gg438-supplemental-helper-compile/v1',
  purpose: binding ? 'frozen' : 'compile-check: unfrozen source, never admissible for execution',
  checkout, head: binding?.head ?? null, tree: binding?.tree ?? null,
  compiler: { path: compiler, sha256: sha(await readFile(compiler)) }, args, startedAt, completedAt: new Date().toISOString(),
  exitCode: result.code, stdout: result.stdout, stderr: result.stderr,
  inputs: { launcher: { path: launcherCs, sha256: before.launcher }, control: { path: controlCs, sha256: before.control } },
  output,
};
const receiptPath = join(outDir, 'receipt.json');
await save(receiptPath, receipt);
console.log(JSON.stringify({ receipt: receiptPath, sha256: sha(await readFile(receiptPath)), exitCode: result.code, output }));
process.exitCode = result.code === 0 ? 0 : 1;
