// Bounded evidence inventory for launcher-438 supplemental-attempt-1 (read-only, no-follow).
// Hashes: invoker outer receipts, wrapper receipts and every attempt `evidence/` file (receipts the
// driver wrote). Fixture trees: no-follow metadata summary only (counts, bytes, reparse names); no
// fixture file is opened, so disposable master.key and SQLite contents are never read or copied.
import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { lstat, readdir, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

const batch = 'C:\\Users\\98jak\\graphgoblin-qa\\2026-11-13-aidlc-batch';
const suite = join(batch, 'launcher-438-supplemental-qa-preparation');
const attempt = join(suite, 'attempts', 'supplemental-attempt-1');
const invocation = join(batch, 'launcher-438-supplemental-invocation-01');
const out = join(batch, 'launcher-438-supplemental-opus-execution-01', 'evidence-inventory.json');
const rel = (path) => path.slice(batch.length + 1).replaceAll('\\', '/');
const digest = (path) => new Promise((resolve, reject) => {
  const hash = createHash('sha256');
  createReadStream(path).on('data', (chunk) => hash.update(chunk)).on('error', reject).on('end', () => resolve(hash.digest('hex')));
});

async function hashTree(root, rows) {
  for (const entry of (await readdir(root, { withFileTypes: true })).sort((a, b) => a.name.localeCompare(b.name))) {
    const path = join(root, entry.name);
    const stat = await lstat(path);
    if (stat.isSymbolicLink()) { rows.push({ path: rel(path), kind: 'reparse-not-followed' }); continue; }
    if (stat.isDirectory()) { await hashTree(path, rows); continue; }
    if (stat.isFile()) rows.push({ path: rel(path), bytes: stat.size, sha256: await digest(path) });
    else rows.push({ path: rel(path), kind: 'other' });
  }
  return rows;
}

/** No-follow metadata walk: counts and bytes only; reparse names are leaves and listed. */
async function fixtureSummary(root) {
  const summary = { root: rel(root), directories: 0, files: 0, bytes: 0, reparse: [], other: 0 };
  async function walk(dir) {
    for (const entry of await readdir(dir, { withFileTypes: true })) {
      const path = join(dir, entry.name);
      const stat = await lstat(path);
      if (stat.isSymbolicLink()) { summary.reparse.push(rel(path)); continue; }
      if (stat.isDirectory()) { summary.directories++; await walk(path); continue; }
      if (stat.isFile()) { summary.files++; summary.bytes += stat.size; continue; }
      summary.other++;
    }
  }
  await walk(root);
  return summary;
}

const inventory = {
  schema: 'gg438-supplemental-opus-evidence-inventory/v1', at: new Date().toISOString(),
  scope: 'Outer invoker receipts, PowerShell wrapper receipts and every driver-written attempt evidence file are hashed. Fixture trees are summarized by no-follow metadata only (no file contents read). Private Claude session streams in the worker directory are excluded.',
  invocation: await hashTree(invocation, []),
  wrapperReceipts: {},
  modules: {},
};
for (const module of ['writer-controls', 'guard-controls', 'native-startup', 'native-sharing', 'native-predecessor']) {
  inventory.wrapperReceipts[module] = await hashTree(join(suite, 'receipts', 'supplemental-attempt-1-' + module), []);
  const moduleDir = join(attempt, module);
  const cases = {};
  for (const id of (await readdir(join(moduleDir, 'cases'))).sort()) {
    const caseDir = join(moduleDir, 'cases', id);
    cases[id] = { evidence: await hashTree(join(caseDir, 'evidence'), []), fixture: await fixtureSummary(join(caseDir, 'fixture')) };
  }
  inventory.modules[module] = { evidence: await hashTree(join(moduleDir, 'evidence'), []), cases };
}
const evidenceRows = Object.values(inventory.modules).flatMap((m) => [...m.evidence, ...Object.values(m.cases).flatMap((c) => c.evidence)]);
inventory.totals = {
  invocationFiles: inventory.invocation.length,
  wrapperReceiptFiles: Object.values(inventory.wrapperReceipts).flat().length,
  evidenceFiles: evidenceRows.length,
  evidenceBytes: evidenceRows.reduce((n, r) => n + (r.bytes ?? 0), 0),
  evidenceReparse: evidenceRows.filter((r) => r.kind).length,
  fixtureDirectories: Object.values(inventory.modules).flatMap((m) => Object.values(m.cases)).reduce((n, c) => n + c.fixture.directories, 0),
  fixtureFiles: Object.values(inventory.modules).flatMap((m) => Object.values(m.cases)).reduce((n, c) => n + c.fixture.files, 0),
  fixtureBytes: Object.values(inventory.modules).flatMap((m) => Object.values(m.cases)).reduce((n, c) => n + c.fixture.bytes, 0),
  fixtureReparse: Object.values(inventory.modules).flatMap((m) => Object.values(m.cases)).flatMap((c) => c.fixture.reparse),
};
await writeFile(out, JSON.stringify(inventory, null, 1) + '\n', { flag: 'wx' });
console.log(JSON.stringify(inventory.totals, null, 1));
