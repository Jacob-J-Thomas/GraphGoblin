// Read-only post-run analysis of launcher-438 supplemental-attempt-1 receipts.
// Reads JSON receipts only; never opens fixture stores, keys or databases. Writes analysis.json
// into this worker's output directory (create-new).
import { readFile, readdir, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

const batch = 'C:\\Users\\98jak\\graphgoblin-qa\\2026-11-13-aidlc-batch';
const suite = join(batch, 'launcher-438-supplemental-qa-preparation');
const attempt = join(suite, 'attempts', 'supplemental-attempt-1');
const invocation = join(batch, 'launcher-438-supplemental-invocation-01');
const out = join(batch, 'launcher-438-supplemental-opus-execution-01', 'analysis.json');
const modules = ['writer-controls', 'guard-controls', 'native-startup', 'native-sharing', 'native-predecessor'];
const json = async (path) => JSON.parse(await readFile(path, 'utf8'));
const rel = (path) => path.startsWith(batch) ? path.slice(batch.length + 1) : path;

async function processes(dir) {
  const names = (await readdir(dir)).filter((n) => /^process-\d+-outcome\.json$/u.test(n)).sort();
  const rows = [];
  for (const name of names) {
    const o = await json(join(dir, name));
    rows.push({
      n: name.slice(8, 11), label: o.label, exe: String(o.executable).split('\\').pop(), pid: o.pid,
      exit: o.exit?.code ?? null, signal: o.exit?.signal ?? null, close: o.close?.code ?? null,
      exitEqualsClose: o.exit?.code === o.close?.code && o.exit?.signal === o.close?.signal,
      stdoutBytes: o.stdoutBytes, stderrBytes: o.stderrBytes,
      stdoutEof: o.stdoutEnd?.bytes ?? null, stderrEof: o.stderrEnd?.bytes ?? null,
      eofMatches: o.stdoutEnd?.bytes === o.stdoutBytes && o.stderrEnd?.bytes === o.stderrBytes,
      timeout: o.timeout ?? null, terminationRequested: o.terminationRequested ?? null,
      requestedUtc: o.requestedUtc, exitAt: o.exitAt, closeAt: o.closeAt,
    });
  }
  return rows;
}

const summary = { schema: 'gg438-supplemental-opus-analysis/v1', at: new Date().toISOString(), modules: [] };
for (const module of modules) {
  const moduleDir = join(attempt, module);
  const result = await json(join(moduleDir, 'evidence', 'result.json'));
  const opening = await json(join(moduleDir, 'evidence', 'opening-binding.json'));
  const close = await json(join(invocation, module, 'close.json'));
  const receipts = join(suite, 'receipts', 'supplemental-attempt-1-' + module);
  const wrapper = {
    launch: await json(join(receipts, 'launch.json')), exit: await json(join(receipts, 'exit.json')),
    capture: await json(join(receipts, 'capture.json')),
  };
  const moduleProcesses = await processes(join(moduleDir, 'evidence'));
  const cases = [];
  for (const row of result.rows) {
    const evidence = join(moduleDir, 'cases', row.id, 'evidence');
    const procs = await processes(evidence);
    const c = row.cleanup ?? {};
    cases.push({
      id: row.id, level: row.level, criteria: row.criteria, status: row.status, elapsedMs: row.elapsedMs,
      startedAt: row.startedAt, endedAt: row.endedAt, skippedVariants: row.skippedVariants ?? [],
      failure: row.failure ?? null, observed: row.observed,
      cleanup: {
        errors: c.errors ?? null,
        ports: c.ports ?? [],
        gateways: (c.gateways ?? []).map((g) => ({ label: g.label, pid: g.pid ?? null, birth: g.birth ?? null,
          birthAbsentAfter: g.after !== undefined ? true : null, exit: g.exit ?? null, notListening: g.notListening ?? false })),
        work: (c.work ?? []).map((w) => ({ label: w.label, runId: w.runId })),
        holders: (c.holders ?? []).map((h) => ({ label: h.label, pid: h.pid, exit: h.exit?.code ?? null,
          stdout: h.exit?.stdout ?? null, goneAfterRelease: h.gone ?? null })),
        links: (c.links ?? []).map((l) => ({ path: rel(l.path), target: rel(l.target), type: l.type })),
        reparse: (c.reparse ?? []).map(rel),
        profileJunction: c.profileJunction ? { disposition: c.profileJunction.disposition,
          link: rel(c.profileJunction.link?.path ?? ''), target: rel(c.profileJunction.target?.path ?? '') } : null,
        aclRestore: c.acl ? { removedUsersAce: true, beforeLength: c.acl.before?.length, afterLength: c.acl.after?.length } : null,
        childCensusRows: c.childCensus ? c.childCensus.rows.length : null,
        storesChecked: c.stores ? { entries: c.stores.entries, exclusiveStoreFiles: (c.stores.exclusiveStoreFiles ?? []).length,
          probePid: c.stores.probePid } : null,
        retained: c.retained ? rel(c.retained) : null,
      },
      processes: {
        count: procs.length,
        allExitEqualsClose: procs.every((p) => p.exitEqualsClose),
        allEofMatch: procs.every((p) => p.eofMatches),
        timeouts: procs.filter((p) => p.timeout || p.terminationRequested).map((p) => ({ n: p.n, label: p.label, timeout: p.timeout, terminationRequested: p.terminationRequested })),
        nonZero: procs.filter((p) => p.exit !== 0).map((p) => ({ n: p.n, label: p.label, pid: p.pid, exit: p.exit, stdoutBytes: p.stdoutBytes, stderrBytes: p.stderrBytes })),
        rows: procs,
      },
    });
  }
  summary.modules.push({
    module, status: result.status, firstFailure: result.firstFailure ?? null, bindingError: result.bindingError ?? null,
    startedAt: result.startedAt, completedAt: result.completedAt,
    openingEqualsClosing: JSON.stringify(opening.opening) === JSON.stringify(result.closing),
    binding: result.closing, fixtureParent: { owner: opening.parent.owner, protected: opening.parent.protected,
      allowed: opening.parent.allowed, sddl: opening.parent.sddl },
    invokerClose: { pid: close.pid, launch: close.launch, exit: close.exit, close: close.close,
      stdout: { eof: close.stdout.eof, writeClosed: close.stdout.writeClosed, bytes: close.stdout.bytes, sha256: close.stdout.sha256 },
      stderr: { eof: close.stderr.eof, writeClosed: close.stderr.writeClosed, bytes: close.stderr.bytes, sha256: close.stderr.sha256 },
      complete: close.complete },
    wrapper,
    moduleProcesses: { count: moduleProcesses.length, allExitEqualsClose: moduleProcesses.every((p) => p.exitEqualsClose),
      allEofMatch: moduleProcesses.every((p) => p.eofMatches), rows: moduleProcesses },
    cases,
  });
}
const all = summary.modules.flatMap((m) => m.cases);
const procs = all.flatMap((c) => c.processes.rows).concat(summary.modules.flatMap((m) => m.moduleProcesses.rows));
summary.totals = {
  cases: all.length, passed: all.filter((c) => c.status === 'passed').length,
  otherStatuses: all.filter((c) => c.status !== 'passed').map((c) => [c.id, c.status]),
  skippedVariants: all.filter((c) => c.skippedVariants.length).map((c) => ({ id: c.id, skipped: c.skippedVariants })),
  cleanupErrors: all.reduce((n, c) => n + (c.cleanup.errors?.length ?? 0), 0),
  processes: procs.length,
  processesExitEqualsClose: procs.filter((p) => p.exitEqualsClose).length,
  processesEofMatch: procs.filter((p) => p.eofMatches).length,
  processTimeoutsOrTerminations: procs.filter((p) => p.timeout || p.terminationRequested).length,
  gatewaysDrainedOrNotListening: all.flatMap((c) => c.cleanup.gateways).length,
  portsChecked: all.flatMap((c) => c.cleanup.ports).length,
  portsFree: all.flatMap((c) => c.cleanup.ports).filter((p) => p.free).length,
  holders: all.flatMap((c) => c.cleanup.holders).length,
  holdersCleanExitAndGone: all.flatMap((c) => c.cleanup.holders).filter((h) => h.exit === 0 && h.goneAfterRelease === true).length,
  profileJunctionsRetained: all.filter((c) => c.cleanup.profileJunction).map((c) => c.id),
  intentionalLinks: all.flatMap((c) => c.cleanup.links.map((l) => ({ case: c.id, ...l }))),
  reparseNotKnown: all.map((c) => ({ id: c.id, extra: c.cleanup.reparse.filter((p) =>
    !c.cleanup.links.some((l) => l.path === p) && c.cleanup.profileJunction?.link !== p) })).filter((r) => r.extra.length),
};
await writeFile(out, JSON.stringify(summary, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(summary.totals, null, 1));
