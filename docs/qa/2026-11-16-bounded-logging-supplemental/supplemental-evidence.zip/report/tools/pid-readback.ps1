$ErrorActionPreference = 'Stop'
$list = Get-Content -LiteralPath $args[0] -Raw | ConvertFrom-Json
$rows = foreach ($item in $list) {
  $p = Get-CimInstance Win32_Process -Filter ("ProcessId = " + [int]$item.pid)
  if ($null -eq $p) { [ordered]@{ kind = $item.kind; label = $item.label; pid = $item.pid; recordedBirth = $item.birth; present = $false } }
  else { [ordered]@{ kind = $item.kind; label = $item.label; pid = $item.pid; recordedBirth = $item.birth; present = $true; name = $p.Name; creationFileTime = [string]$p.CreationDate.ToFileTimeUtc(); sameBirth = ([string]$p.CreationDate.ToFileTimeUtc() -eq [string]$item.birth) } }
}
[ordered]@{ at = [DateTime]::UtcNow.ToString('o'); rows = @($rows) } | ConvertTo-Json -Depth 4
