# #436 independent behavior QA harness (Opus worker). Exercises only the candidate launcher's
# private installer CLI: --validate-install --config <stagedJSON> and
# --stage-shortcut <stagedLNK> <stagedJSON> <finalEXE>. Windows PowerShell 5.1 only.
# This file is QA tooling, not product code. ASCII only; non-ASCII names are built from code points.
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$RunRoot,
    [Parameter(Mandatory = $true)][string]$Checkout,
    [Parameter(Mandatory = $true)][string]$HelperSource,
    [Parameter(Mandatory = $true)][string]$CanarySource,
    [Parameter(Mandatory = $true)][int]$Port
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$Utf8 = New-Object Text.UTF8Encoding($false)
$script:FirstFailure = $null
$script:ChildIndex = 0
$script:Checks = New-Object 'System.Collections.Generic.List[object]'
$script:Children = New-Object 'System.Collections.Generic.List[object]'
$script:CaseResults = New-Object 'System.Collections.Generic.List[object]'
$HarnessStart = [DateTime]::UtcNow
$script:Deadline = $HarnessStart.AddSeconds(360)
$WorkRoot = 'C:\Users\98jak\graphgoblin-qa\2026-11-13-aidlc-batch\launcher-436-opus-behavior-qa\work'
$ChildWaitMs = 20000
$StreamCloseMs = 5000

# ---------------------------------------------------------------- exclusive run root
$RunRoot = [IO.Path]::GetFullPath($RunRoot)
if (-not $RunRoot.StartsWith($WorkRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'RunRoot must be beneath the owned work directory.' }
if ([IO.Directory]::Exists($RunRoot) -or [IO.File]::Exists($RunRoot)) { throw 'RunRoot already exists; refusing to reuse an existing directory.' }
[void][IO.Directory]::CreateDirectory($RunRoot)
$Tools = [IO.Path]::Combine($RunRoot, 'tools')
$Fx = [IO.Path]::Combine($RunRoot, 'fx')
$Receipts = [IO.Path]::Combine($RunRoot, 'receipts')
foreach ($d in @($Tools, $Fx, $Receipts)) { [void][IO.Directory]::CreateDirectory($d) }
$ProgressPath = [IO.Path]::Combine($RunRoot, 'harness-progress.log')

function Add-Log([string]$Text) {
    [IO.File]::AppendAllText($ProgressPath, [DateTime]::UtcNow.ToString('o') + ' ' + $Text + "`r`n", $Utf8)
    [Console]::Out.WriteLine($Text)
}

function Get-BytesSha256([byte[]]$Bytes) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { ([BitConverter]::ToString($sha.ComputeHash($Bytes))).Replace('-', '').ToLowerInvariant() } finally { $sha.Dispose() }
}

function Get-FileSha256([string]$Path) {
    $stream = [IO.File]::Open($Path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
    try {
        $sha = [Security.Cryptography.SHA256]::Create()
        try { ([BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-', '').ToLowerInvariant() } finally { $sha.Dispose() }
    } finally { $stream.Dispose() }
}

function Write-JsonFile([string]$Path, $Value) {
    [IO.File]::WriteAllText($Path, ($Value | ConvertTo-Json -Depth 10), $Utf8)
}

# Exact quoting expression of the candidate installer's Invoke-InstallerProcess.
function ConvertTo-InstallerArgument([string]$Value) {
    '"' + (($Value -creplace '(\\*)"', '$1$1\"') -creplace '(\\+)$', '$1$1') + '"'
}

function Test-BytesContain([byte[]]$Haystack, [byte[]]$Needle) {
    if ($Needle.Length -eq 0 -or $Haystack.Length -lt $Needle.Length) { return $false }
    for ($i = 0; $i -le $Haystack.Length - $Needle.Length; $i++) {
        $match = $true
        for ($j = 0; $j -lt $Needle.Length; $j++) { if ($Haystack[$i + $j] -ne $Needle[$j]) { $match = $false; break } }
        if ($match) { return $true }
    }
    return $false
}

function Add-Check([string]$Case, [string]$Name, [bool]$Pass, [string]$Detail) {
    $script:Checks.Add([pscustomobject][ordered]@{ case = $Case; check = $Name; pass = $Pass; detail = $Detail })
    if (-not $Pass -and $null -eq $script:FirstFailure) {
        $script:FirstFailure = [pscustomobject][ordered]@{ case = $Case; check = $Name; detail = $Detail; atUtc = [DateTime]::UtcNow.ToString('o') }
        Add-Log ('FIRST FAILURE ' + $Case + ' / ' + $Name + ' : ' + $Detail)
    }
}

# ---------------------------------------------------------------- owned child with receipts
function Invoke-OwnedChild {
    param([string]$Name, [string]$Exe, [string[]]$Argv, [string]$Cwd, [switch]$SkipArgvCheck)
    if ([DateTime]::UtcNow -gt $script:Deadline) { throw [InvalidOperationException]::new('Harness deadline reached before ' + $Name) }
    $script:ChildIndex++
    $stem = [IO.Path]::Combine($Receipts, ('{0:D2}-{1}' -f $script:ChildIndex, $Name))
    $commandLine = (@($Argv | ForEach-Object { ConvertTo-InstallerArgument $_ })) -join ' '
    $receipt = [ordered]@{}
    $receipt.index = $script:ChildIndex
    $receipt.name = $Name
    $receipt.exe = $Exe
    $receipt.exeSha256 = Get-FileSha256 $Exe
    $receipt.argv = $Argv
    $receipt.commandLine = $commandLine
    $receipt.cwd = $Cwd
    $receipt.harnessPid = $PID
    $receipt.waitLimitMs = $ChildWaitMs
    $receipt.streamCloseLimitMs = $StreamCloseMs
    if (-not $SkipArgvCheck) {
        $parsed = [InstallerQa.Windows]::SplitArguments($commandLine)
        $same = ($parsed.Length -eq $Argv.Length)
        if ($same) { for ($i = 0; $i -lt $Argv.Length; $i++) { if ($parsed[$i] -cne $Argv[$i]) { $same = $false } } }
        $receipt.argvRoundTripCommandLineToArgvW = $same
        if (-not $same) { throw [InvalidOperationException]::new('Harness argv quoting did not round-trip for ' + $Name) }
    }
    $info = New-Object Diagnostics.ProcessStartInfo
    $info.FileName = $Exe
    $info.Arguments = $commandLine
    $info.WorkingDirectory = $Cwd
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardInput = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    $receipt.spawnRequestedUtc = [DateTime]::UtcNow.ToString('o')
    $process = [Diagnostics.Process]::Start($info)
    try {
        $receipt.pid = $process.Id
        $birth = $process.StartTime
        $receipt.birthUtc = $birth.ToUniversalTime().ToString('o')
        $receipt.birthFileTimeUtc = $birth.ToFileTimeUtc()
        $process.StandardInput.Close()
        $out = New-Object IO.MemoryStream
        $err = New-Object IO.MemoryStream
        $outTask = $process.StandardOutput.BaseStream.CopyToAsync($out)
        $errTask = $process.StandardError.BaseStream.CopyToAsync($err)
        $clock = [Diagnostics.Stopwatch]::StartNew()
        $exited = $process.WaitForExit($ChildWaitMs)
        $receipt.waitElapsedMs = $clock.ElapsedMilliseconds
        $receipt.exitedWithinLimit = $exited
        $receipt.killedOwnedPid = $null
        if (-not $exited) {
            # Terminate only this exact owned process (our own handle; PID and birth re-verified).
            $verified = ($process.Id -eq $receipt.pid) -and ($process.StartTime.ToFileTimeUtc() -eq $receipt.birthFileTimeUtc) -and (-not $process.HasExited)
            $receipt.hangIdentityVerified = $verified
            if ($verified) { $process.Kill(); $receipt.killedOwnedPid = $receipt.pid; [void]$process.WaitForExit(5000) }
        }
        $closeClock = [Diagnostics.Stopwatch]::StartNew()
        $closed = [Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($outTask, $errTask), $StreamCloseMs)
        $receipt.streamCloseElapsedMs = $closeClock.ElapsedMilliseconds
        $receipt.streamsClosedWithinLimit = $closed
        $receipt.hasExitedAtRelease = $process.HasExited
        if ($process.HasExited) {
            $receipt.exitCode = $process.ExitCode
            $receipt.exitTimeUtc = $process.ExitTime.ToUniversalTime().ToString('o')
        } else { $receipt.exitCode = $null; $receipt.exitTimeUtc = $null }
        $outBytes = $out.ToArray()
        $errBytes = $err.ToArray()
    } finally { $process.Dispose() }
    [IO.File]::WriteAllBytes($stem + '.stdout.bin', $outBytes)
    [IO.File]::WriteAllBytes($stem + '.stderr.bin', $errBytes)
    $receipt.stdoutBytes = $outBytes.Length
    $receipt.stderrBytes = $errBytes.Length
    $receipt.stdoutSha256 = Get-BytesSha256 $outBytes
    $receipt.stderrSha256 = Get-BytesSha256 $errBytes
    $receipt.stdoutUtf8 = $Utf8.GetString($outBytes)
    $receipt.stderrUtf8 = $Utf8.GetString($errBytes)
    Write-JsonFile ($stem + '.receipt.json') $receipt
    $script:Children.Add([pscustomobject]$receipt)
    Add-Log ('child ' + $receipt.index + ' ' + $Name + ' pid=' + $receipt.pid + ' exit=' + $receipt.exitCode + ' waitMs=' + $receipt.waitElapsedMs + ' out=' + $outBytes.Length + 'B err=' + $errBytes.Length + 'B')
    return @{ Receipt = $receipt; Stdout = $outBytes; Stderr = $errBytes }
}

# ---------------------------------------------------------------- fixture tree snapshots
function Get-TreeSnapshot([string]$Root) {
    $result = [System.Collections.Generic.SortedDictionary[string, string]]::new([StringComparer]::Ordinal)
    $rootInfo = [IO.DirectoryInfo]::new($Root)
    $result['.'] = 'dir|' + [int]$rootInfo.Attributes + '|' + $rootInfo.LastWriteTimeUtc.Ticks
    foreach ($entry in [IO.Directory]::EnumerateFileSystemEntries($Root, '*', [IO.SearchOption]::AllDirectories)) {
        $rel = $entry.Substring($Root.Length)
        $attributes = [IO.File]::GetAttributes($entry)
        if (($attributes -band [IO.FileAttributes]::Directory) -ne 0) {
            $result[$rel] = 'dir|' + [int]$attributes + '|' + ([IO.DirectoryInfo]::new($entry)).LastWriteTimeUtc.Ticks
        } else {
            $file = [IO.FileInfo]::new($entry)
            $result[$rel] = 'file|' + [int]$attributes + '|' + $file.Length + '|' + $file.LastWriteTimeUtc.Ticks + '|' + (Get-FileSha256 $entry)
        }
    }
    return , $result
}

function Compare-TreeSnapshot($Before, $After) {
    $keys = New-Object 'System.Collections.Generic.List[string]'
    $detail = New-Object 'System.Collections.Generic.List[string]'
    foreach ($k in $Before.Keys) {
        if (-not $After.ContainsKey($k)) { $keys.Add('removed:' + $k); $detail.Add('removed:' + $k + ' was ' + $Before[$k]) }
        elseif ($After[$k] -cne $Before[$k]) { $keys.Add('changed:' + $k); $detail.Add('changed:' + $k + ' ' + $Before[$k] + ' -> ' + $After[$k]) }
    }
    foreach ($k in $After.Keys) { if (-not $Before.ContainsKey($k)) { $keys.Add('added:' + $k); $detail.Add('added:' + $k + ' ' + $After[$k]) } }
    return @{ Changes = $keys.ToArray(); Detail = $detail.ToArray() }
}

function ConvertTo-SnapshotList($Snapshot) {
    $list = New-Object 'System.Collections.Generic.List[string]'
    foreach ($k in $Snapshot.Keys) { $list.Add($k + ' => ' + $Snapshot[$k]) }
    return , $list.ToArray()
}

# ---------------------------------------------------------------- environment and manifest
$Manifest = @(
    @('scripts/install-windows-launcher.ps1', '2f5874d33465f8a614f08c79e2a5433e0980aad6f9674a226daeaf584f06af1b', 23983),
    @('apps/windows-launcher/Launcher.cs', 'e1171d840ff332e22826194edbef251e5d46688c2af3ff6bc3dc0f76c6e60091', 38775),
    @('tooling/scripts/windows-launcher.acceptance.mjs', '9e8572882ebbb602bf3af153edf6f9685ffdc1dc372a7f209292ad69e8aa39ba', 48575),
    @('docs/09-frontend-and-pwa.md', 'd5db487253b51e1c199bbfb008495ceeff1d857f09e9419a57d1375f95c89ef8', 322767),
    @('docs/guide/01-install-and-first-run.md', '7aeae3810784e0eb569985dac63d2a6c14c90fc4a74ea03ed66d7d2ddbab2a9c', 22130),
    @('CHANGELOG.md', '014cd3de87d8ec64f5e4a7be5ba01d62cf6d47d1a9250b1a533289c20d2f9114', 162920)
)
$HelperExpectedSha256 = '28455c8a6eb9b793f17c58014060085052156a9175dd2c670a91f4d8f33f0222'

function Test-Manifest([string]$Phase) {
    $rows = New-Object 'System.Collections.Generic.List[object]'
    $allOk = $true
    foreach ($m in $Manifest) {
        $path = [IO.Path]::Combine($Checkout, $m[0].Replace('/', '\'))
        $hash = Get-FileSha256 $path
        $bytes = ([IO.FileInfo]::new($path)).Length
        $ok = ($hash -ceq $m[1]) -and ($bytes -eq $m[2])
        if (-not $ok) { $allOk = $false }
        $rows.Add([pscustomobject][ordered]@{ path = $m[0]; sha256 = $hash; bytes = $bytes; expectedSha256 = $m[1]; expectedBytes = $m[2]; match = $ok })
    }
    Add-Check 'manifest' ('six-path manifest ' + $Phase) $allOk ('all six candidate paths match: ' + $allOk)
    return @{ Ok = $allOk; Rows = $rows.ToArray() }
}

$Outcome = [ordered]@{}
$exitCode = 2
try {
    $self = [Diagnostics.Process]::GetCurrentProcess()
    $SystemPowerShell = [IO.Path]::Combine($env:SystemRoot, 'System32\WindowsPowerShell\v1.0\powershell.exe')
    $Csc = [IO.Path]::Combine($env:WINDIR, 'Microsoft.NET\Framework64\v4.0.30319\csc.exe')
    $Outcome.harness = [ordered]@{
        pid = $PID; birthUtc = $self.StartTime.ToUniversalTime().ToString('o'); image = $self.MainModule.FileName
        psVersion = $PSVersionTable.PSVersion.ToString(); psEdition = $PSVersionTable.PSEdition
        is64BitProcess = [Environment]::Is64BitProcess; apartment = [Threading.Thread]::CurrentThread.GetApartmentState().ToString()
        clr = [Environment]::Version.ToString(); os = [Environment]::OSVersion.VersionString
        psModulePath = $env:PSModulePath; startedUtc = $HarnessStart.ToString('o'); runRoot = $RunRoot
        cscPath = $Csc; cscFileVersion = $null; port = $Port
        harnessSha256 = Get-FileSha256 $PSCommandPath; canarySourceSha256 = Get-FileSha256 $CanarySource
    }
    Add-Check 'environment' 'system Windows PowerShell 5.1 Desktop x64' (($PSVersionTable.PSVersion.Major -eq 5) -and ($PSVersionTable.PSVersion.Minor -eq 1) -and ($PSVersionTable.PSEdition -eq 'Desktop') -and [Environment]::Is64BitProcess -and [string]::Equals($self.MainModule.FileName, $SystemPowerShell, [StringComparison]::OrdinalIgnoreCase)) ($self.MainModule.FileName + ' ' + $PSVersionTable.PSVersion)
    Add-Check 'environment' 'Framework64 csc.exe present' ([IO.File]::Exists($Csc)) $Csc
    if ($null -ne $script:FirstFailure) { throw [InvalidOperationException]::new('environment precondition failed') }
    $Outcome.harness.cscFileVersion = [Diagnostics.FileVersionInfo]::GetVersionInfo($Csc).FileVersion
    Add-Log ('harness pid=' + $PID + ' ps=' + $PSVersionTable.PSVersion + ' csc=' + $Outcome.harness.cscFileVersion)

    $before = Test-Manifest 'before execution'
    $Outcome.manifestBefore = $before.Rows
    if (-not $before.Ok) { throw [InvalidOperationException]::new('candidate manifest differs; dependent execution stopped') }
    $helperHashBefore = Get-FileSha256 $HelperSource
    Add-Check 'environment' 'independent IShellLinkW helper source hash' ($helperHashBefore -ceq $HelperExpectedSha256) $helperHashBefore
    if ($null -ne $script:FirstFailure) { throw [InvalidOperationException]::new('helper hash differs') }

    # ------------------------------------------------------------ compile canary, helper, candidate
    $CanaryExe = [IO.Path]::Combine($Tools, 'inert-canary.exe')
    $r = Invoke-OwnedChild 'S1-compile-inert-canary' $Csc @('/nologo', '/target:winexe', '/platform:x64', '/optimize+', "/out:$CanaryExe", $CanarySource) $Tools -SkipArgvCheck
    Add-Check 'S1' 'canary compiled' (($r.Receipt.exitCode -eq 0) -and [IO.File]::Exists($CanaryExe)) ('exit=' + $r.Receipt.exitCode + ' stdout=' + $r.Receipt.stdoutUtf8)
    if ($null -ne $script:FirstFailure) { throw [InvalidOperationException]::new('setup failed') }

    $HelperDll = [IO.Path]::Combine($Tools, 'InstallerQa.Windows.dll')
    $r = Invoke-OwnedChild 'S2-compile-independent-shelllink-helper' $Csc @('/nologo', '/target:library', '/platform:x64', '/optimize+', "/out:$HelperDll", $HelperSource) $Tools -SkipArgvCheck
    Add-Check 'S2' 'helper compiled' (($r.Receipt.exitCode -eq 0) -and [IO.File]::Exists($HelperDll)) ('exit=' + $r.Receipt.exitCode + ' stdout=' + $r.Receipt.stdoutUtf8)
    if ($null -ne $script:FirstFailure) { throw [InvalidOperationException]::new('setup failed') }
    [void][Reflection.Assembly]::LoadFile($HelperDll)

    $LauncherSource = [IO.Path]::Combine($Checkout, 'apps\windows-launcher\Launcher.cs')
    $StageExeDir = [IO.Path]::Combine($Fx, 'stage-exe')
    [void][IO.Directory]::CreateDirectory($StageExeDir)
    $Launcher = [IO.Path]::Combine($StageExeDir, 'GraphGoblin.exe')
    $sourceBefore = Get-FileSha256 $LauncherSource
    # Exact compiler argument list of the candidate installer.
    $r = Invoke-OwnedChild 'S3-compile-candidate-launcher' $Csc @('/nologo', '/target:winexe', '/optimize+', '/platform:x64', '/reference:System.Windows.Forms.dll', '/reference:System.Web.Extensions.dll', "/out:$Launcher", $LauncherSource) $Tools
    $sourceAfter = Get-FileSha256 $LauncherSource
    Add-Check 'S3' 'candidate Launcher.cs compiled with installer flags' (($r.Receipt.exitCode -eq 0) -and [IO.File]::Exists($Launcher) -and ($sourceBefore -ceq 'e1171d840ff332e22826194edbef251e5d46688c2af3ff6bc3dc0f76c6e60091') -and ($sourceAfter -ceq $sourceBefore)) ('exit=' + $r.Receipt.exitCode + ' source=' + $sourceBefore + ' stdout=' + $r.Receipt.stdoutUtf8)
    if ($null -ne $script:FirstFailure) { throw [InvalidOperationException]::new('setup failed') }
    Add-Check 'S3' 'candidate launcher is an x64 PE image' ([InstallerQa.Windows]::IsX64WindowsImage($Launcher)) $Launcher
    if ($null -ne $script:FirstFailure) { throw [InvalidOperationException]::new('setup failed') }
    $Outcome.binaries = [ordered]@{
        canary = [ordered]@{ path = $CanaryExe; sha256 = Get-FileSha256 $CanaryExe }
        helper = [ordered]@{ path = $HelperDll; sha256 = Get-FileSha256 $HelperDll; source = $HelperSource; sourceSha256 = $helperHashBefore }
        launcher = [ordered]@{ path = $Launcher; sha256 = Get-FileSha256 $Launcher; source = $LauncherSource; sourceSha256 = $sourceBefore }
    }

    # ------------------------------------------------------------ fixture (all inert, labelled)
    $alpha = [string][char]0x03B1
    $Repo = [IO.Path]::Combine($Fx, 'repo-inert')
    foreach ($f in @('apps\api\dist\main.js', 'apps\api\dist\instance-identity.js', 'apps\web\dist\index.html')) {
        $p = [IO.Path]::Combine($Repo, $f)
        [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($p))
        [IO.File]::WriteAllText($p, "// #436 QA inert placeholder satisfying Configuration.Validate path checks. Not GraphGoblin; never executed.`n", $Utf8)
    }
    $NodeExe = [IO.Path]::Combine($Fx, 'node-canary\node.exe')
    $ChromeProxy = [IO.Path]::Combine($Fx, 'chrome-canary\chrome_proxy.exe')
    foreach ($p in @($NodeExe, $ChromeProxy)) { [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($p)); [IO.File]::Copy($CanaryExe, $p) }
    $DataDir = [IO.Path]::Combine($Fx, 'store-must-stay-absent')
    $AppId = & {
        $sha = [Security.Cryptography.SHA256]::Create()
        try {
            $b = $sha.ComputeHash($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes('http://127.0.0.1:' + $Port + '/app/')))
            $sb = New-Object Text.StringBuilder
            for ($i = 0; $i -lt 16; $i++) { [void]$sb.Append([char](97 + ($b[$i] -shr 4))); [void]$sb.Append([char](97 + ($b[$i] -band 15))) }
            $sb.ToString()
        } finally { $sha.Dispose() }
    }
    function Get-LauncherAumid([string]$FinalExe) { 'GraphGoblin.' + (Get-BytesSha256 ([Text.Encoding]::UTF8.GetBytes($FinalExe.ToUpperInvariant()))).Substring(0, 24) }

    $FinalA = [IO.Path]::Combine($Fx, 'final-first-install\GraphGoblin.exe')   # directory intentionally absent
    $AumidA = Get-LauncherAumid $FinalA
    $IconA = [IO.Path]::Combine($Fx, 'pwa-icons\GraphGoblin.ico') + ',0'
    $FinalBDir = [IO.Path]::Combine($Fx, 'final ' + $alpha + ' x')
    $FinalB = [IO.Path]::Combine($FinalBDir, 'GraphGoblin.exe')
    $FinalBArg = [IO.Path]::Combine($FinalBDir, 'sub\..\GraphGoblin.exe')      # non-normalized argv form
    $AumidB = Get-LauncherAumid $FinalB
    $IconB = [IO.Path]::Combine($Fx, 'icons, ' + $alpha + ' set\GraphGoblin.ico') + ',2'
    [void][IO.Directory]::CreateDirectory($FinalBDir)
    [IO.File]::Copy($CanaryExe, $FinalB)    # inert canary standing in for a previously published launcher
    [IO.File]::WriteAllText($FinalB + '.json', '{"QA436":"inert previously published config placeholder"}', $Utf8)

    $Configs = [IO.Path]::Combine($Fx, 'configs')
    [void][IO.Directory]::CreateDirectory($Configs)
    function New-ConfigJson($Override) {
        $c = [ordered]@{
            Repo = $Repo; Node = $NodeExe; DataDir = $DataDir; Port = $Port
            ChromeProxy = $ChromeProxy; ChromeProfile = 'QA436 Inert Profile'; ChromeAppId = $AppId
            IconLocation = $IconA
            PwaAppUserModelId = 'QA436.InertPwaFixture'; LauncherAppUserModelId = $AumidA
            Environment = @{}; StartupTimeoutSeconds = 60; WindowTimeoutSeconds = 30
        }
        foreach ($k in @($Override.Keys)) { $c[$k] = $Override[$k] }
        ($c | ConvertTo-Json -Depth 10)
    }
    function Write-Config([string]$Path, [string]$Json) {
        [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($Path))
        [IO.File]::WriteAllText($Path, $Json, $Utf8)
    }
    $Token = ([Guid]::NewGuid().ToString('N')).Substring(0, 12)
    $Canary = 'GG436QA_CANARY_' + $Token
    $ConfigA = $Launcher + '.json'
    Write-Config $ConfigA (New-ConfigJson @{})
    $ConfigB = [IO.Path]::Combine($Configs, 'valid-b.json')
    Write-Config $ConfigB (New-ConfigJson @{ IconLocation = $IconB; LauncherAppUserModelId = $AumidB })
    $ConfigMalformed = [IO.Path]::Combine($Configs, 'malformed.json')
    Write-Config $ConfigMalformed ('{"Repo": "' + $Canary + '_JSON", "Port": ')
    $ConfigType = [IO.Path]::Combine($Configs, 'type-mismatch.json')
    Write-Config $ConfigType ((New-ConfigJson @{}) -creplace ('"Port":\s+' + $Port), ('"Port":  "' + $Canary + '_TYPE"'))
    $ConfigReserved = [IO.Path]::Combine($Configs, 'reserved-override.json')
    Write-Config $ConfigReserved (New-ConfigJson @{ Environment = @{ GG_PORT = ($Canary + '_ENVVALUE') } })
    $ConfigBadPath = [IO.Path]::Combine($Configs, ($Canary + '_CFGDIR\GraphGoblin.exe.json'))
    Write-Config $ConfigBadPath (New-ConfigJson @{ Repo = [IO.Path]::Combine($Fx, ($Canary + '_MISSINGREPO')) })
    $ConfigMissing = [IO.Path]::Combine($Configs, ($Canary + '_ABSENTDIR\GraphGoblin.exe.json'))
    $ConfigOrigin = [IO.Path]::Combine($Configs, 'origin-mismatch.json')
    Write-Config $ConfigOrigin (New-ConfigJson @{ Port = ($Port + 1); ChromeProfile = ($Canary + '_PROFILE') })
    $Cwd = [IO.Path]::Combine($Fx, 'child-cwd')
    $RelConfigRel = 'rel-config\GraphGoblin.exe.json'
    Write-Config ([IO.Path]::Combine($Cwd, $RelConfigRel)) ([IO.File]::ReadAllText($ConfigA))
    # Setup guards: a fixture-generation mistake must stop as a harness error, never as a product result.
    $typeText = [IO.File]::ReadAllText($ConfigType)
    if (-not $typeText.Contains($Canary + '_TYPE') -or $typeText.Contains('"Port":  ' + $Port)) { throw [InvalidOperationException]::new('setup: type-mismatch config was not generated') }
    if (-not ([IO.File]::ReadAllText($ConfigReserved)).Contains('"GG_PORT"')) { throw [InvalidOperationException]::new('setup: reserved override config was not generated') }
    $aText = [IO.File]::ReadAllText($ConfigA)
    if (-not $aText.Contains('"ChromeAppId":  "' + $AppId + '"') -or -not $aText.Contains('"Environment":  {') -or -not $aText.Contains($AumidA)) { throw [InvalidOperationException]::new('setup: valid config A shape unexpected') }
    if ([IO.Directory]::Exists([IO.Path]::GetDirectoryName($ConfigMissing)) -or [IO.Directory]::Exists($DataDir) -or [IO.Directory]::Exists([IO.Path]::GetDirectoryName($FinalA))) { throw [InvalidOperationException]::new('setup: an absent-path precondition does not hold') }

    $StageA = [IO.Path]::Combine($Fx, 'stage-a'); $LinkA = [IO.Path]::Combine($StageA, 'GraphGoblin.lnk')
    $StageB = [IO.Path]::Combine($Fx, 'stage ' + $alpha + ' b'); $LinkB = [IO.Path]::Combine($StageB, 'GraphGoblin.lnk')
    $StageC = [IO.Path]::Combine($Fx, 'stage-c'); $LinkC = [IO.Path]::Combine($StageC, 'GraphGoblin.lnk')
    $StageF = [IO.Path]::Combine($Fx, 'stage-f'); $LinkF = [IO.Path]::Combine($StageF, 'GraphGoblin.lnk')
    $StageMissing = [IO.Path]::Combine($Fx, ($Canary + '_ABSENTSTAGE')); $LinkMissing = [IO.Path]::Combine($StageMissing, 'GraphGoblin.lnk')
    foreach ($d in @($StageA, $StageB, $StageC, $StageF)) { [void][IO.Directory]::CreateDirectory($d) }

    # A previously installed output shortcut, written by the independent helper (not the candidate).
    $ExistingLink = [IO.Path]::Combine($Fx, 'existing-outputs\Desktop\GraphGoblin.lnk')
    [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($ExistingLink))
    [InstallerQa.Windows]::SaveLink($ExistingLink, $FinalB, ('--config "' + $FinalB + '.json"'), $FinalBDir, $FinalB)
    [InstallerQa.Windows]::WriteAppId($ExistingLink, $AumidB)

    $CanaryLogs = @(($NodeExe + '.invoked.txt'), ($ChromeProxy + '.invoked.txt'), ($FinalB + '.invoked.txt'))
    $FixtureInitial = Get-TreeSnapshot $Fx
    $Outcome.fixture = [ordered]@{
        root = $Fx; port = $Port; chromeAppId = $AppId; canaryToken = $Canary; dataDir = $DataDir
        nodeCanary = $NodeExe; chromeProxyCanary = $ChromeProxy; finalBExistingCanary = $FinalB
        launcher = $Launcher; configA = $ConfigA; configB = $ConfigB; finalA = $FinalA; finalB = $FinalB; finalBArgv = $FinalBArg
        aumidA = $AumidA; aumidB = $AumidB; iconA = $IconA; iconB = $IconB; childCwd = $Cwd
        labels = 'node.exe, chrome_proxy.exe and the pre-existing final GraphGoblin.exe are copies of the compiled inert canary (record invocation, exit 86); repo-inert holds placeholder text files; no real Node, Chrome, gateway or browser is present.'
        initialSnapshot = ConvertTo-SnapshotList $FixtureInitial
    }
    if (-not $Cwd.StartsWith($Fx.Substring(0, 2), [StringComparison]::OrdinalIgnoreCase)) { throw [InvalidOperationException]::new('cwd drive mismatch') }

    # ------------------------------------------------------------ frozen matrix (expectations fixed before execution)
    $M_ARGS = 'Invalid staged launcher arguments.'
    $M_CFGPATH = 'Invalid staged launcher configuration path.'
    $M_LNKPATH = 'Invalid staged shortcut or final launcher path.'
    $M_FALLBACK = 'The staged launcher configuration or shortcut could not be prepared.'
    $M_PATHS = 'Invalid launcher paths, port or timeouts. Re-run install-windows-launcher.ps1.'
    $M_RESERVED = "GG_PORT is owned by the launcher's explicit configuration fields."
    $M_ORIGIN = 'The installed Chrome PWA belongs to another origin. Install GraphGoblin from http://127.0.0.1:' + ($Port + 1) + '/app/ and configure its shortcut.'
    $relA = $StageA.Substring($Fx.Length); $relB = $StageB.Substring($Fx.Length)
    $drive = $Fx.Substring(0, 2)

    function New-Case($Id, $Title, $Argv, $Exit, $Stderr, $Required, $Allowed, $Decode) {
        [pscustomobject][ordered]@{ Id = $Id; Title = $Title; Argv = [string[]]$Argv; Exit = $Exit; Stderr = $Stderr; Required = [string[]]$Required; Allowed = [string[]]$Allowed; Decode = $Decode }
    }
    $none = [string[]]@()
    $Cases = @(
        (New-Case 'C01' 'validate: valid staged config succeeds silently with no side effects' @('--validate-install', '--config', $ConfigA) 0 '' $none $none $null),
        (New-Case 'C02a' 'validate: malformed JSON carrying canary -> fixed fallback, no echo' @('--validate-install', '--config', $ConfigMalformed) 1 $M_FALLBACK $none $none $null),
        (New-Case 'C02b' 'validate: JSON type mismatch carrying canary -> fixed fallback, no echo' @('--validate-install', '--config', $ConfigType) 1 $M_FALLBACK $none $none $null),
        (New-Case 'C03' 'validate: reserved GG_PORT override with canary value -> fixed refusal' @('--validate-install', '--config', $ConfigReserved) 1 $M_RESERVED $none $none $null),
        (New-Case 'C04' 'validate: invalid Repo, config under canary-named dir -> fixed refusal, no path echo, no launcher.log' @('--validate-install', '--config', $ConfigBadPath) 1 $M_PATHS $none $none $null),
        (New-Case 'C05' 'validate: absent config under canary-named absent dir -> fixed fallback, nothing created' @('--validate-install', '--config', $ConfigMissing) 1 $M_FALLBACK $none $none $null),
        (New-Case 'C06a' 'argv: validate missing config value' @('--validate-install', '--config') 1 $M_ARGS $none $none $null),
        (New-Case 'C06b' 'argv: validate with canary token in place of --config' @('--validate-install', ($Canary + '_ARGV'), $ConfigA) 1 $M_ARGS $none $none $null),
        (New-Case 'C06c' 'argv: validate plus trailing --ensure-gateway' @('--validate-install', '--config', $ConfigA, '--ensure-gateway') 1 $M_ARGS $none $none $null),
        (New-Case 'C06d' 'argv: leading --ensure-gateway before validate' @('--ensure-gateway', '--validate-install', '--config', $ConfigA) 1 $M_ARGS $none $none $null),
        (New-Case 'C06e' 'argv: --config before --validate-install' @('--config', $ConfigA, '--validate-install') 1 $M_ARGS $none $none $null),
        (New-Case 'C06f' 'argv: relative config path with canary' @('--validate-install', '--config', ($Canary + '_REL\GraphGoblin.exe.json')) 1 $M_CFGPATH $none $none $null),
        (New-Case 'C06g' 'argv: stage with three arguments' @('--stage-shortcut', $LinkF, $ConfigA) 1 $M_ARGS $none $none $null),
        (New-Case 'C06h' 'argv: stage plus trailing --ensure-gateway' @('--stage-shortcut', $LinkF, $ConfigA, $FinalA, '--ensure-gateway') 1 $M_ARGS $none $none $null),
        (New-Case 'C06i' 'argv: stage relative link path with canary' @('--stage-shortcut', ($Canary + '_RELLNK.lnk'), $ConfigA, $FinalA) 1 $M_LNKPATH $none $none $null),
        (New-Case 'C06j' 'argv: stage link path without .lnk extension' @('--stage-shortcut', [IO.Path]::Combine($StageF, ($Canary + '_EXT.txt')), $ConfigA, $FinalA) 1 $M_LNKPATH $none $none $null),
        (New-Case 'C06k' 'argv: stage relative final executable with canary' @('--stage-shortcut', $LinkF, $ConfigA, ($Canary + '_RELEXE\GraphGoblin.exe')) 1 $M_LNKPATH $none $none $null),
        (New-Case 'C07' 'stage: first install writes only the staged link, embedding final target/config/dir/icon/AUMID' @('--stage-shortcut', $LinkA, $ConfigA, $FinalA) 0 '' @(('added:' + $LinkA.Substring($Fx.Length))) @(('added:' + $LinkA.Substring($Fx.Length)), ('changed:' + $relA)) 'A'),
        (New-Case 'C08' 'stage: Unicode/space staging + non-normalized final path over existing final files' @('--stage-shortcut', $LinkB, $ConfigB, $FinalBArg) 0 '' @(('added:' + $LinkB.Substring($Fx.Length))) @(('added:' + $LinkB.Substring($Fx.Length)), ('changed:' + $relB)) 'B'),
        (New-Case 'C09' 'stage: invalid (origin-mismatch) config refuses before any link write' @('--stage-shortcut', $LinkC, $ConfigOrigin, $FinalA) 1 $M_ORIGIN $none $none $null),
        (New-Case 'C10' 'stage: absent canary-named staging parent -> fixed fallback, nothing created' @('--stage-shortcut', $LinkMissing, $ConfigA, $FinalA) 1 $M_FALLBACK $none $none $null),
        (New-Case 'C11a' 'strictness probe: drive-relative (not fully qualified) config path' @('--validate-install', '--config', ($drive + $RelConfigRel)) 1 $M_CFGPATH $none $none $null),
        (New-Case 'C11b' 'strictness probe: drive-relative (not fully qualified) final executable' @('--stage-shortcut', $LinkF, $ConfigA, ($drive + 'rel-final\GraphGoblin.exe')) 1 $M_LNKPATH $none $none $null)
    )
    $Outcome.plan = $Cases
    Write-JsonFile ([IO.Path]::Combine($RunRoot, 'matrix-plan.json')) ([ordered]@{ frozenUtc = [DateTime]::UtcNow.ToString('o'); fixture = $Outcome.fixture; cases = $Cases })
    Add-Log ('matrix frozen: ' + $Cases.Count + ' children, canary ' + $Canary)

    $CanaryUtf8 = $Utf8.GetBytes('GG436QA_CANARY')
    $CanaryUtf16 = [Text.Encoding]::Unicode.GetBytes('GG436QA_CANARY')
    $PathFragUtf8 = $Utf8.GetBytes('opus-behavior-qa')
    $PathFragUtf16 = [Text.Encoding]::Unicode.GetBytes('opus-behavior-qa')

    function Test-StagedLink([string]$CaseId, [string]$LinkPath, [string]$ExpectedTarget, [string]$ExpectedIcon, [string]$ExpectedAumid) {
        $bytes = [IO.File]::ReadAllBytes($LinkPath)
        $header = [byte[]](0x4C, 0, 0, 0, 0x01, 0x14, 0x02, 0, 0, 0, 0, 0, 0xC0, 0, 0, 0, 0, 0, 0, 0x46)
        $headerOk = $bytes.Length -ge 20
        if ($headerOk) { for ($i = 0; $i -lt 20; $i++) { if ($bytes[$i] -ne $header[$i]) { $headerOk = $false } } }
        Add-Check $CaseId 'raw MS-SHLLINK header and ShellLink CLSID' $headerOk ('bytes=' + $bytes.Length + ' sha256=' + (Get-BytesSha256 $bytes))
        $identity = [InstallerQa.Windows]::Identify($LinkPath)
        Add-Check $CaseId 'link exists at exactly the requested staging path' ([string]::Equals($identity.Path, $LinkPath, [StringComparison]::OrdinalIgnoreCase)) ('final path=' + $identity.Path + ' fileId=' + $identity.FileId + ' exactCase=' + ($identity.Path -ceq $LinkPath))
        $link = [InstallerQa.Windows]::LoadLink($LinkPath)
        $expectedConfig = $ExpectedTarget + '.json'
        $expectedArgs = '--config "' + $expectedConfig + '"'
        $expectedDir = [IO.Path]::GetDirectoryName($ExpectedTarget)
        Add-Check $CaseId 'decoded target is the final executable' ($link.Target -ceq $ExpectedTarget) ('decoded=' + $link.Target + ' expected=' + $ExpectedTarget)
        Add-Check $CaseId 'decoded arguments are --config "<final>.json"' ($link.Arguments -ceq $expectedArgs) ('decoded=' + $link.Arguments + ' expected=' + $expectedArgs)
        $split = [InstallerQa.Windows]::SplitArguments($link.Arguments)
        Add-Check $CaseId 'CommandLineToArgvW yields exactly [--config, <final>.json]' (($split.Length -eq 2) -and ($split[0] -ceq '--config') -and ($split[1] -ceq $expectedConfig)) ('argv=' + ($split -join ' | '))
        Add-Check $CaseId 'decoded working directory is the final executable directory' ($link.WorkingDirectory -ceq $expectedDir) ('decoded=' + $link.WorkingDirectory + ' expected=' + $expectedDir)
        Add-Check $CaseId 'decoded icon location equals config IconLocation' ($link.Icon -ceq $ExpectedIcon) ('decoded=' + $link.Icon + ' expected=' + $ExpectedIcon)
        $aumid = [InstallerQa.Windows]::ReadAppId($LinkPath)
        Add-Check $CaseId 'property-store AppUserModelID equals final-path launcher identity' ($aumid -ceq $ExpectedAumid) ('decoded=' + $aumid + ' expected=' + $ExpectedAumid)
        Add-Check $CaseId 'raw link bytes contain UTF-16LE AppUserModelID' (Test-BytesContain $bytes ([Text.Encoding]::Unicode.GetBytes($ExpectedAumid))) $ExpectedAumid
        Add-Check $CaseId 'raw link bytes do not reference the staged config path' (-not (Test-BytesContain $bytes ([Text.Encoding]::Unicode.GetBytes('valid-b.json'))) -and -not (Test-BytesContain $bytes ([Text.Encoding]::Unicode.GetBytes('stage-exe')))) 'no stage-exe / valid-b.json UTF-16LE in link'
        return [ordered]@{ path = $LinkPath; bytes = $bytes.Length; sha256 = Get-BytesSha256 $bytes; identity = $identity; target = $link.Target; arguments = $link.Arguments; argv = $split; workingDirectory = $link.WorkingDirectory; icon = $link.Icon; appUserModelId = $aumid }
    }

    # ------------------------------------------------------------ execute once, stop at first unexpected result
    $Outcome.decoded = [ordered]@{}
    foreach ($case in $Cases) {
        if ($null -ne $script:FirstFailure) { break }
        $snapBefore = Get-TreeSnapshot $Fx
        $r = Invoke-OwnedChild $case.Id $Launcher $case.Argv $Cwd
        $snapAfter = Get-TreeSnapshot $Fx
        $diff = Compare-TreeSnapshot $snapBefore $snapAfter
        $rc = $r.Receipt
        $id = $case.Id
        Add-Check $id 'exited within 20 s' ([bool]$rc.exitedWithinLimit) ('waitMs=' + $rc.waitElapsedMs)
        Add-Check $id 'stdout/stderr closed within 5 s' ([bool]$rc.streamsClosedWithinLimit) ('closeMs=' + $rc.streamCloseElapsedMs)
        Add-Check $id ('exit code ' + $case.Exit) ($rc.exitCode -eq $case.Exit) ('actual=' + $rc.exitCode)
        Add-Check $id 'stdout is empty (0 bytes)' ($r.Stdout.Length -eq 0) ('bytes=' + $r.Stdout.Length + ' text=' + $rc.stdoutUtf8)
        [byte[]]$expectedErr = [byte[]]@()
        if ($case.Stderr -ne '') { $expectedErr = $Utf8.GetBytes($case.Stderr + "`r`n") }
        Add-Check $id 'stderr bytes exactly equal expected fixed text' ([BitConverter]::ToString($r.Stderr) -ceq [BitConverter]::ToString($expectedErr)) ('actual=' + $rc.stderrUtf8 + ' expected=' + $case.Stderr)
        Add-Check $id 'stderr bounded (<= 512 bytes)' ($r.Stderr.Length -le 512) ('bytes=' + $r.Stderr.Length)
        $echo = (Test-BytesContain $r.Stdout $CanaryUtf8) -or (Test-BytesContain $r.Stderr $CanaryUtf8) -or (Test-BytesContain $r.Stdout $CanaryUtf16) -or (Test-BytesContain $r.Stderr $CanaryUtf16)
        Add-Check $id 'no canary token echoed (UTF-8/UTF-16LE)' (-not $echo) 'GG436QA_CANARY'
        $pathEcho = (Test-BytesContain $r.Stdout $PathFragUtf8) -or (Test-BytesContain $r.Stderr $PathFragUtf8) -or (Test-BytesContain $r.Stdout $PathFragUtf16) -or (Test-BytesContain $r.Stderr $PathFragUtf16)
        Add-Check $id 'no fixture path echoed' (-not $pathEcho) 'opus-behavior-qa'
        $invoked = @($CanaryLogs | Where-Object { [IO.File]::Exists($_) })
        Add-Check $id 'no inert node/chrome/final-exe canary invocation recorded' ($invoked.Count -eq 0) ('records=' + ($invoked -join ';'))
        Add-Check $id 'DataDir store still absent' (-not [IO.Directory]::Exists($DataDir) -and -not [IO.File]::Exists($DataDir)) $DataDir
        $logs = @([IO.Directory]::EnumerateFiles($Fx, '*.log', [IO.SearchOption]::AllDirectories))
        Add-Check $id 'no launcher.log / gateway.log anywhere in fixture' ($logs.Count -eq 0) ($logs -join ';')
        $unexpected = @($diff.Changes | Where-Object { $case.Allowed -notcontains $_ })
        $missing = @($case.Required | Where-Object { $diff.Changes -notcontains $_ })
        Add-Check $id 'fixture tree changes are exactly the permitted set' (($unexpected.Count -eq 0) -and ($missing.Count -eq 0)) ('diff=' + ($diff.Detail -join ' ; ') + ' unexpected=' + ($unexpected -join ';') + ' missingRequired=' + ($missing -join ';'))
        $decoded = $null
        if ($null -eq $script:FirstFailure -and $null -ne $case.Decode) {
            if ($case.Decode -eq 'A') {
                $decoded = Test-StagedLink $id $LinkA $FinalA $IconA $AumidA
                Add-Check $id 'final directory, executable and config were not created' (-not [IO.Directory]::Exists([IO.Path]::GetDirectoryName($FinalA)) -and -not [IO.File]::Exists($FinalA) -and -not [IO.File]::Exists($FinalA + '.json')) $FinalA
            } else {
                $decoded = Test-StagedLink $id $LinkB $FinalB $IconB $AumidB
                Add-Check $id 'existing final executable/config bytes unchanged (snapshot)' (($snapBefore[$FinalB.Substring($Fx.Length)] -ceq $snapAfter[$FinalB.Substring($Fx.Length)]) -and ($snapBefore[($FinalB + '.json').Substring($Fx.Length)] -ceq $snapAfter[($FinalB + '.json').Substring($Fx.Length)])) $FinalB
                Add-Check $id 'no link or file written at the final paths' (-not [IO.File]::Exists([IO.Path]::Combine($FinalBDir, 'GraphGoblin.lnk')) -and -not [IO.Directory]::Exists([IO.Path]::Combine($FinalBDir, 'sub'))) $FinalBDir
            }
            $snapDecode = Get-TreeSnapshot $Fx
            $decodeDiff = Compare-TreeSnapshot $snapAfter $snapDecode
            Add-Check $id 'independent decoding did not mutate the fixture' ($decodeDiff.Changes.Length -eq 0) ($decodeDiff.Detail -join ' ; ')
            $Outcome.decoded[$id] = $decoded
        }
        $script:CaseResults.Add([pscustomobject][ordered]@{ id = $id; title = $case.Title; pid = $rc.pid; birthUtc = $rc.birthUtc; exitCode = $rc.exitCode; waitMs = $rc.waitElapsedMs; stderr = $rc.stderrUtf8; stdoutBytes = $rc.stdoutBytes; treeDiff = $diff.Detail; passed = ($null -eq $script:FirstFailure) })
        Add-Log ($id + ' ' + $(if ($null -eq $script:FirstFailure) { 'PASS' } else { 'FAIL' }))
    }

    $FixtureFinal = Get-TreeSnapshot $Fx
    $Outcome.fixtureFinalSnapshot = ConvertTo-SnapshotList $FixtureFinal
    $after = Test-Manifest 'after execution'
    $Outcome.manifestAfter = $after.Rows
    $helperHashAfter = Get-FileSha256 $HelperSource
    Add-Check 'environment' 'helper source unchanged after execution' ($helperHashAfter -ceq $HelperExpectedSha256) $helperHashAfter
    Add-Check 'environment' 'candidate Launcher.cs unchanged after execution' ((Get-FileSha256 $LauncherSource) -ceq 'e1171d840ff332e22826194edbef251e5d46688c2af3ff6bc3dc0f76c6e60091') $LauncherSource
    $ran = @($script:CaseResults).Count
    $Outcome.casesPlanned = $Cases.Count
    $Outcome.casesExecuted = $ran
    $exitCode = if ($null -eq $script:FirstFailure) { 0 } else { 1 }
} catch {
    $Outcome.harnessError = [ordered]@{ type = $_.Exception.GetType().FullName; message = $_.Exception.Message; line = $_.InvocationInfo.ScriptLineNumber; position = $_.InvocationInfo.PositionMessage }
    Add-Log ('HARNESS STOP: ' + $_.Exception.GetType().FullName + ': ' + $_.Exception.Message + ' at line ' + $_.InvocationInfo.ScriptLineNumber)
    if ($null -eq $script:FirstFailure) {
        $script:FirstFailure = [pscustomobject][ordered]@{ case = 'harness'; check = 'unhandled'; detail = $_.Exception.Message; atUtc = [DateTime]::UtcNow.ToString('o') }
    }
    $exitCode = 2
} finally {
    $Outcome.firstFailure = $script:FirstFailure
    $Outcome.checks = $script:Checks.ToArray()
    $Outcome.cases = $script:CaseResults.ToArray()
    $Outcome.children = @($script:Children | ForEach-Object { [ordered]@{ index = $_.index; name = $_.name; pid = $_.pid; birthUtc = $_.birthUtc; exitCode = $_.exitCode; waitMs = $_.waitElapsedMs; exitedWithinLimit = $_.exitedWithinLimit; streamsClosedWithinLimit = $_.streamsClosedWithinLimit; killedOwnedPid = $_.killedOwnedPid; hasExitedAtRelease = $_.hasExitedAtRelease } })
    $Outcome.finishedUtc = [DateTime]::UtcNow.ToString('o')
    $Outcome.harnessExitCode = $exitCode
    Write-JsonFile ([IO.Path]::Combine($RunRoot, 'matrix-outcome.json')) $Outcome
    Add-Log ('harness exit ' + $exitCode)
}
exit $exitCode
