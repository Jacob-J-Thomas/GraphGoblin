// #436 Opus behavior QA: INERT CANARY fixture. This is NOT Node, NOT Chrome and NOT a
// GraphGoblin launcher. Copies of this binary are placed where the fixture configuration
// names node.exe, chrome_proxy.exe and a pre-existing final GraphGoblin.exe. Any process
// start of a copy appends one record next to that copy and exits 86 immediately, so an
// accidental gateway, browser or final-launcher start is recorded instead of performed.
using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;

public static class InertCanary
{
    public static int Main(string[] args)
    {
        string self = Assembly.GetEntryAssembly().Location;
        string record = DateTime.UtcNow.ToString("o") + "\tpid=" + Process.GetCurrentProcess().Id +
            "\tcommandLine=" + Environment.CommandLine + "\r\n";
        try { File.AppendAllText(self + ".invoked.txt", record, new UTF8Encoding(false)); }
        catch (Exception) { }
        return 86;
    }
}
